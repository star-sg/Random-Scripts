#### 1 Nov 2021

Starting off code review, I chose some smaller tables to review first, namely the `trak` and `just` table. Didn't find any bugs in there, and tbh they really are quite simple so there is not much room for error.

#### 3 Nov 2021

I think it is better for me to gain a better understanding of text shaping engines, because I am looking at Apple's text shaping engine right now, and I know basically nothing about how they work. Here are some very useful resources:

* https://harfbuzz.github.io/what-is-harfbuzz.html (everything in this manual is good)
* https://docs.google.com/presentation/d/1x97pfbB1gbD53Yhz6-_yBUozQMVJ_5yMqqR_D-R7b7I/present?slide=id.p

#### 8 Nov 2021

I considered reading HarfBuzz's code first because it is open source and should be doing about the same thing as CoreText. Then I decided to also find known bugs in HarfBuzz to see whether they exist in CoreText.

I stumbled upon this [issue](https://github.com/harfbuzz/harfbuzz/issues/1225), and decided to look at the [patch that fixed it](https://github.com/harfbuzz/harfbuzz/commit/4831e615d173be9c7e140be0fa9017e4d9e499af). In the end, it looks like something that is just specific to HarfBuzz, so not very useful. The commit basically says:

> [morx] Fix memory access issue
>
> If buffer was enlarged, info was being outdated.

Moving on, I decided to look at how HarfBuzz processes the morx table, written in **src/hb-aat-layout-morx-table.hh**. Then I just saw this:

```c
template <>
struct LigatureEntry<true>
{
  enum Flags
  {
    SetComponent	= 0x8000,	/* Push this glyph onto the component stack for
					 * eventual processing. */
    DontAdvance		= 0x4000,	/* Leave the glyph pointer at this glyph for the
					   next iteration. */
    PerformAction	= 0x2000,	/* Use the ligActionIndex to process a ligature
					 * group. */
    Reserved		= 0x1FFF,	/* These bits are reserved and should be set to 0. */
  };
```

And thought: ooh what's this *component stack*?

So I decided to read the documentation on morx table one more round (it is sooooo complex, I had to read 2-3 times to properly understand it). After I felt comfortable with the morx table format, I started to read the code in CoreText. Turns out it wasn't too hard to get started once I got familiar with the morx format. I focused on the code processing the **ligature subtable** (`TAATMorphSubtableMorx::DoLigatureSubtable`), as this was the part that has the "component stack" mentioned above.

Then I found a stack-based buffer overflow. Yay :D finally found something 4 weeks before the internship ends.

It is not actually necessary to understand the whole morx table format to understand the vulnerability, but here's the official documentation:
https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6morx.html

For some basic understanding, within the morx table, there are a few subtables.

* Rearrangement subtable
* Contextual subtable
* **Ligature subtable**
* Noncontextual (“swash”) subtable
* Insertion subtable

The **ligature subtable** is the one with a bug. It is responsible for telling the engine how to combine certain characters (or unicode code points) to show a different glyph. For example, it can be configured so that `fi` will show a different glyph instead of 2 separate glyphs `f` and `i`.

To summarize, the 2 most relevant things are `LigatureEntry` and `LigatureAction`, which are a part of the **ligature subtable**. They are both 32-bit values, with flags set on certain bit positions. In terms of bitmasks, these are the flags for `LigatureEntry` and `LigatureAction` (taken from **harfbuzz/src/hb-aat-layout-morx-table.hh**):

```c
struct LigatureEntry<true>
{
  enum Flags
  {
    SetComponent	= 0x8000,	/* Push this glyph onto the component stack for
					 * eventual processing. */
    DontAdvance		= 0x4000,	/* Leave the glyph pointer at this glyph for the
					   next iteration. */
    PerformAction	= 0x2000,	/* Use the ligActionIndex to process a ligature
					 * group. */
    Reserved		= 0x1FFF,	/* These bits are reserved and should be set to 0. */
  };
...
```

```c
enum LigActionFlags
{
    LigActionLast	= 0x80000000,	/* This is the last action in the list. This also
                    * implies storage. */
    LigActionStore	= 0x40000000,	/* Store the ligature at the current cumulated index
                    * in the ligature table in place of the marked
                    * (i.e. currently-popped) glyph. */
    LigActionOffset	= 0x3FFFFFFF,	/* A 30-bit value which is sign-extended to 32-bits
                    * and added to the glyph ID, resulting in an index
                    * into the component table. */
};
```

There are many flags above that look confusing, especially when not knowing any other parts of the ligature subtable, but here is the rough idea, and the only thing we care about, for the sake of the vulnerability:

1. The engine will go through a list of `LigatureEntry`s defined in the morx table, there can be as many as the font decides to have.

    a. The MSB (`SetComponent` flag) can be set, so that the engine pushes a glyph onto the component stack.

    **Basically, push something onto a stack.**

    b. The `PerformAction` flag can be set, so that the engine looks up the **ligature action table** and processes the `LigatureAction`s there, based on some starting index.

    **Basically, let the engine process `LigatureAction`s.**

2. When the engine reaches a `LigatureEntry` that has `PerformAction` flag set, it will go through a list of `LigatureAction`s.

    a. The `LigActionStore` flag can be set, to blah blah blah whatever.

    **Importantly, in CoreText, something will be pushed onto the stack after this.**

    b. After processing one `LigatureAction`, the engine increments the index of the **ligature action table**, and processes the next `LigatureAction`.

    c. The `LigActionLast` flag is to inform the engine to stop processing further `LigatureAction`s.

    **Basically, the engine keeps going down the table, until it sees a `LigatureAction` with `LigActionLast` flag set.**

And here's the rough code of how CoreText does the steps above. First, there's a `MorxLigatureState` struct to keep some info:

```cpp
struct TGlyph   // for now, just know that this struct takes up 16 bytes
{
  void* trunglue;
  int64_t location;
}

struct MorxLigatureState
{
  TGlyph tglyphs[0x80];   // this is the component stack
  int stack_top;          // index of the top of the stack
  int max_stack_size;     // the maximum stack size reached (because there will be popping from the stack too)
  ...
}
```

```cpp
TAATMorphSubtableMorx::DoLigatureSubtable(..., MorxLigatureState state, ...)
{
  ...

  if (flags & 0x8000)      // SetComponent flag is set
  {
    // update stack_top and max_stack_size
    state->stack_top++;
    stack_top = state->stack_top;

    // set stack_top back to 0 if it reaches 0x80, i.e. no overflow here
    if ( stack_top > 0x7E )                  // wrap around
      state->stack_top = 0;
    else
      state->max_stack_size = max(state->stack_top, state->max_stack_size);

    // push a TGlyph into state->tglyphs
    state->tglyphs[stack_top].trunglue = trunglue;
    state->tglyphs[stack_top].location = location;
  }

  if (flags & 0x2000)      // PerformAction flag is set
  {
    TAATMorphSubtableMorx::DoLigatureAction(..., state, ...);
    ...
  }
}
```

```cpp
TAATMorphSubtableMorx::DoLigatureAction(..., MorxLigatureState state, ...)
{
  ...
  TGlyph tglyphs_storage[0x80];
  // end of stack frame (of course there's canary here)

  ...

  while(1)
  {
    // load ligature action from ligature action subtable
    p_ligature_action_entry = &lig_action_table[lig_action_index];
    ...
    // byteswap because font stores values in big endian
    // the -1 doesnt matter too much
    lig_action_entry = _byteswap_ulong(*(p_ligature_action_entry - 1));

    // load a TGlyph from state->tglyphs
    stack_top = state->stack_top;
    trunglue = state->tglyphs[stack_top].trunglue;
    location = state->tglyphs[stack_top].location;

    if (lig_action_entry >= 0x40000000)    // either Store or Last flag is set
    {
      // does some stuff to update the glyphs that will be shown to the user
      ...

      // then it appends the TGlyph to the local tglyphs array
      // no bounds check lol
      // remember tglyphs only has space for 0x80 elements
      tglyphs_storage[storage_index].trunglue = trunglue;
      tglyphs_storage[storage_index].location = location;
    }

    ...

    // update state->stack_top
    state->stack_top--;
    if ( state->stack_top < 0 )    // wrap around to other end of stack
      state->stack_top = *state->max_stack_size;

    if (...)     // Last flag is set
    {
      // does some cleaning up
      ...

      break;
    }
  }
}
```

To sum up what can happen in the code above:

1. There's a `LigatureEntry` that has `PerformAction` flag set - `DoLigatureAction` is called
2. There are more than `0x80` `LigatureAction`s in a row, none of them has the `Last` flag set.
3. GG. Can overflow the stack as much as wanted.
4. `tglyphs_storage` is at the end of the stack, so overflowing it immediately overwrites the stack canary followed by the return address.

However, there are also some big limitations:

1. As seen above, we write 2 `QWORD`s to the stack. One is a pointer, another is a value (which is user-controllable but within a limited range).
2. Since the stack canary and return address are overwritten with the pointer, the program will crash once the `while` loop is done (unless we control RIP).

It is not so straightforward to exploit this, but I managed to use this bug on Safari, turning it into a heap relative write, then overwriting an object's vtable pointer, to control RIP. It is not reliable, but should be exploitable with more skills.

Also the exploit is not usable yet, because:

* Need leak of library addresses - for ROP
* Need leak of heap addresses/or somewhere else - to know address of fake vtable
* Need to groom the heap because half the time the objects don't appear at the expected offset

---

To help with testing, I forked P0's [BrokenType](https://github.com/googleprojectzero/BrokenType) repo which already has a SFNT parser, so I am left with just writing the morx table parser. With this, I wrote some simple tools in the **ttf-reader** folder. It has a CMake setup so just do the standard CMake build process.

There are 5 programs:

* `emorx <input font> <output font>` - Used to expand the morx table by filling it with `\x01` at the end (not `\x00` because back then I think for some reason it wasn't stored in the end).
* `filterer <folder with fonts> <table name>` - Used to filter font files that have the specified table.
* `repack <input font> <output font>` - Loads the fonts then saves it again. Don't remember why I made it. Probably to fix some checksums in the tables.
* `rmorx <input font>` - Dumps information in the morx table.
* `statser <folder with fonts>` - Prints out the total count of each font table found in the font files.

The morx format is quite complex that I didn't want to spend time writing code that generates the morx table, so I just monkey patched the bytes in a hex editor.
