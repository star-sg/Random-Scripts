In the last 2-3 months, I have been focussing my research on the CoreText framework. In particular, the code related to the text shaping engine and code responsible for parsing the AAT tables.

During this research, I found a OOB write in the morx table. This series of writeups is to document my whole process from picking this attack surface, to finding the bug, to writing an exploit for it in Safari. Hope this is helpful for anyone who is interested to start researching in this area, or who wants to help finish the exploit on Safari (because it's not done yet) :D

There are many many internal structs, and I have reversed those that are useful for this vulnerability and exploit. The idb is attached in this folder.

I try to be as detailed as possible in this set of notes, so I split them into parts:

1. Attack Surface
2. Vulnerability
3. Exploit
