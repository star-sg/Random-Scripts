// https://gist.github.com/jjgod/d1c0c116c359091338b7
// systemfont.m

#import <Cocoa/Cocoa.h>

int main(int argc, char const *argv[]) {
    NSString *fname = [NSString stringWithUTF8String:argv[1]];
    NSURL *fontURL = [NSURL fileURLWithPath:fname];
    // NSLog(@"%@", fontURL);
    if (!fontURL)
    {
        return 1;
    }

    CFErrorRef error = NULL;
    if (!CTFontManagerRegisterFontsForURL((__bridge CFURLRef) fontURL, kCTFontManagerScopeProcess, &error))
    {
        CFShow(error);
        return 2;
    }

    CFArrayRef fontDescriptors = CTFontManagerCreateFontDescriptorsFromURL((__bridge CFURLRef)fontURL);
    int fontCount = CFArrayGetCount(fontDescriptors);
    // NSLog(@"%d", fontCount);
    if (fontCount == 0){
        return 3;
    }

    CTFontDescriptorRef fontDescriptor = CFArrayGetValueAtIndex(fontDescriptors, 0);
    // NSLog(@"%@", fontDescriptor);
    if (!fontDescriptor)
    {
        return 4;
    }

    NSFont* font = [NSFont fontWithName:CTFontDescriptorCopyAttribute(fontDescriptor, kCTFontNameAttribute) size:12.0];
    if (!font)
    {
        return 5;
    }
    // NSLog(@"%@", font);
    CTFontRef ctFont = (CTFontRef)font;

    CTFontRef ctFontCopy = CTFontCreateCopyWithAttributes(ctFont, 0.0, NULL, NULL);

    CGFontRef cgFont = CTFontCopyGraphicsFont(ctFont, NULL);
    CGRect fontBBox = CGFontGetFontBBox(cgFont);

    CGAffineTransform matrix = CTFontGetMatrix(ctFont);
    CGFloat ascent = CTFontGetAscent(ctFont);
    CGFloat descent = CTFontGetDescent(ctFont);
    CGFloat leading = CTFontGetLeading(ctFont);
    UInt32 unitsPerEm = CTFontGetUnitsPerEm(ctFont);
    CGRect boundingBox = CTFontGetBoundingBox(ctFont);
    CGFloat underlinePosition = CTFontGetUnderlinePosition(ctFont);
    CGFloat underlineThickness = CTFontGetUnderlineThickness(ctFont);
    CGFloat slantAngle = CTFontGetSlantAngle(ctFont);
    CGFloat capHeight = CTFontGetCapHeight(ctFont);
    CGFloat xHeight = CTFontGetXHeight(ctFont);

    NSString *textPath = [NSString stringWithUTF8String:argv[2]];
    NSString *textContent = [NSString stringWithContentsOfFile:textPath encoding:NSUTF8StringEncoding error:nil];
    // NSLog(@"%@", textContent);
    if (!textContent) return 6;
    int textLen = [textContent length];

    UniChar characters[65536];
    CFStringGetCharacters((__bridge CFStringRef)textContent, CFRangeMake(0, textLen), characters);

    CGGlyph glyphs[65536];
    CTFontGetGlyphsForCharacters(ctFont, characters, glyphs, textLen);

    CGSize advances[65536];
    CTFontGetAdvancesForGlyphs(ctFont, kCTFontOrientationHorizontal, glyphs, advances, textLen);

    
    // for (int i = 0; i < textLen; i++)
       // printf("%04hx - %d [%g] ", characters[i], glyphs[i], advances[i].width);

    // printf("\n");
    

    CFAttributedStringRef attrStr =
        CFAttributedStringCreate(NULL, (__bridge CFStringRef)textContent,
            (CFDictionaryRef)@{(NSString*)kCTFontAttributeName: font});

    CTLineRef line = CTLineCreateWithAttributedString(attrStr);
    CFArrayRef runs = CTLineGetGlyphRuns(line);

    CGPoint* positions = (CGPoint*)malloc(1024*sizeof(CGPoint));
    memset(positions, 0, 1024*sizeof(CGPoint));

    for (int i = 0; i < CFArrayGetCount(runs); i++) {
        CTRunRef run = CFArrayGetValueAtIndex(runs, i);
        CFIndex count = CTRunGetGlyphCount(run);
        CGGlyph glyphs[1024];
        CTRunGetGlyphs(run, CFRangeMake(0, count), glyphs);

        CGSize advances[1024];
        CTRunGetAdvances(run, CFRangeMake(0, count), advances);

        CGRect* boundingRects = (CGRect*)malloc(count * sizeof(CGRect));
        CTFontGetBoundingRectsForGlyphs(ctFont, 0, glyphs, boundingRects, count);

        // for (int j = 0; j < count; j++)
        //    printf("%d [%g] ", glyphs[j], advances[j].width);

        // printf("\n");

        CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceGray();
        CGContextRef context = CGBitmapContextCreate(0, 1000, 1000, 8, 0, colorspace, 1);
        CTFontDrawGlyphs(ctFont, glyphs, positions, count, context);
    }

    return 0;
}
