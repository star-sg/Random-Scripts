After 2 months of sadness because of my lack of results from the CoreGraphics/ImageIO research, Jacob recommended that I reproduce one of the bugs that Peter found in CoreText/libFontParser. It was an OOB read bug. Sounded a good idea to me so I did it, and wrote a [writeup] on the process. Lucky for me, Apple didn't fix the bug completely, and there was another way of triggering the OOB read. I hinted at the bug in the writeup as well. Reported to Apple but they still haven't fixed it.

Moving on, I decided to try to bindiff different versions of CoreText and see if I can find the patched bugs listed in the Apple Security Updates list. In particular, I tried to bindiff CoreText between macOS 11.4 vs 11.5, trying to identify CVE-2021-30789. Because there was no detailed description of the bug in the CVE, I had to look through all the pieces of code that have changed.

#### 1 Oct 2021

Out of all the code that has changed, I felt that the bug most likely appeared in `CTFontShapeGlyphs` where there was an extra length check. All the code in there did not make any sense to me since many internal structures were used. So, I had to use LLDB to see what's happening in there. I discovered that WebKit has calls to `CTFontShapeGlyphs`, so I happily renamed the function arguments based on what WebKit passes to it. I also attached LLDB to Safari, set a breakpoint to this function, and begin my reversing efforts, by clicking around in Google and Wikipedia. Fast forward, I could not identify the bug here, so maybe there was no bug, or I didn't understand enough. Although the change here was an added length check, I could not tell what was wrong without the check.

Among the changes, I also realized that `TCombiningEngine::ResolveCombiningMarks` has an added length check as well. Similarly, to find out what the length check was for, I continued reversing. I also wrote a simple and slow command to collect code coverage in LLDB (`cov`). I found that Tamil text will have more code coverage, so to simplify things, I created a blank website with some short Tamil text, and continued reversing the internal structs. This is a very painful process, and it took me 1-2 weeks to slowly build an understanding of all the data structures involved. For example:

* `TRunGlue`
* `TLine`
* `TShapingEngine`
* `TKerningEngine`
* `TCharStream`
* `TUnicodeEncoder`
* `TCombiningEngine`
* `TGlyphEncoder`
* `TGlyphStorage`

(I also learnt Tamil during this time :P thanks to my Indian friend Akash)

After some time, I still could not see how there was a vulnerability without the newly added length check, and I just gave up, since I was not sure if there was a vulnerability in the first place. Anyways, I just continued reversing the code in this area, slowly building up understanding of the structs, and hoping to find any silly mistakes that Apple devs might make (and of course it wasn't so easy). Did so for some time (maybe 1-2 weeks), although I did manage to rename more fields of the structs, I didn't really have any clear goal, so I decided to stop.

While reversing, there were some interesting strings or names that caught my eye (which eventually were where I found the bug 1 month later):

* `morx` (extended metamorphosis table)
* `AAT` (which stands for Apple Advanced Typography)
* `kerx` (extended kerning table)

During this time, I also read up many articles to get inspiration. In particular, P0's writeups on TTF fuzzing on Windows:

* https://github.com/googleprojectzero/BrokenType
* https://googleprojectzero.blogspot.com/2016/06/a-year-of-windows-kernel-font-fuzzing-1_27.html
* https://googleprojectzero.blogspot.com/2016/07/a-year-of-windows-kernel-font-fuzzing-2.html
* https://googleprojectzero.blogspot.com/2017/04/notes-on-windows-uniscribe-fuzzing.html
* https://j00ru.vexillium.org/talks/44con-reverse-engineering-and-exploiting-font-rasterizers/

#### 20 Oct 2021

At this point, I thought maybe I should try fuzzing instead. So I wrote a harness that loads a font, and some text, then calls as many functions as I can from the `CTFont*` family (check out the harness folder for it). I chose a TTF file that is designed for Tamil text, and set the fuzzer to mutate the text file. I tried AFL_Frida and Jackalope but in the end felt Jackalope was a lot nicer to use due to its stability. I didn't let the fuzzer mutate the font file because a mutator that is not structure-aware is probably not efficient at all.

The fuzzer is most likely not able to find any bugs, and indeed it didn't, but anyways it generated good text test cases that reached as much coverage as possible. These coverage loaded into Lighthouse on IDA also helped a lot with my reversing process.

While I leave the fuzzer to run, I took my time to read about [Apple's font engine](https://developer.apple.com/fonts/TrueType-Reference-Manual/RM02/Chap2.html), and all the [AAT stuff](https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6.html). There are SO MANY special table formats, and so many tables that do different things.

During this time, I alternate around reading docs and reading code based on the coverage generated from fuzzing. I also sometimes go to Wikipedia on Safari, with LLDB attached, and just clicked around different pages in different languages, and try to reach certain functions in CoreText. In particular, the name `morx` sounded very interesting to me, so I set breakpoints to see under what situations can I reach these functions, such as:

* `TAATMorphTable::ShapeGlyphs(SyncState&, bool&, __CFString const*)`
* `TAATMorphSubtableMorx::SetChain(MorxChain const*, void const*, void const*)`
* `TAATMorphSubtableMorx::NextSubtable()`
* `TAATMorphSubtableMorx::Process(TRunGlue&, CFRange)`
* `TAATMorphSubtableMorx::InitLigatureState(TAATMorphSubtableMorx::MorxLigatureState&)`
* `TAATMorphSubtableMorx::FetchInitialClass(TRunGlue&, CFRange, TRunGlue::TGlyph&, long&, TAATMorphSubtable::GlyphState&)`
* `TAATMorphSubtableMorx::InitContextualState(TRunGlue&, TAATMorphSubtableMorx::MorxContextualState&)`
* `TAATMorphSubtableMorx::DoContextualSubstitution(TRunGlue&, unsigned short, TRunGlue::TGlyph, char const*, MorphActionResultCode&)`

Not all text/glyphs will trigger the execution of morx-related code. I found that Lithuanian and Arabic text are ones that will let CoreText enter these functions, so I added them to my fuzzing corpus, and leave Jackalope to continue exploring with coverage that increases over time.

#### 26 Oct 2021

Around this time, I have read most of the stuff in the Apple font documentation, namely about:

* Font Engine
* TrueType Font Program/Instruction Set
* AAT Special Tables Formats
* AAT Tables

I took a step back, to think about which area I want to dive deep into. In the end, I was very attracted by the AAT tables, for a couple of reasons:

* AAT (Apple Advanced Typography) is only present in Apple devices, because of this, I think it is likely not many people would research into this area.
* Maybe because it's not widely used, `fonttools` doesn't support most of the AAT tables, so it is harder to fuzz well (without writing custom tools).
* It actually is very rarely used. I scanned through a corpus of ttfs (can't remember which) and almost none of them have AAT tables (from memory, I can't find so i cannot verify).
* There are so many complex formats for AAT tables, so there might be some room for mistakes.

So, I decided to focus on the AAT tables. Due to the complexity of the table formats, I felt that it is better to manually review code first, because it is hard to write a mutator that can well preserve the expected format. It is not too hard to identify AAT related functions in CoreText, because they all start with `TAAT`, followed by their table name, e.g.:

* `TAATAnkrTable:...`
* `TAATBslnEngine:...`
* `TAATOpbdTable:...`
* `TAATTrakTable:...`
* `TAATMorphSubtableMorx:...` (except for `morx` that has a longer namespace)

In part 2, I write about how I found this vulnerability and share more information about it too.

There are many different table/subtable formats used by AAT tables, here's the official documentation:
https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6Tables.html
