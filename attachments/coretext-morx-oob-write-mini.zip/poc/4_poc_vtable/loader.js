var memory = new WebAssembly.Memory({ initial: 256 })
console.log(memory.buffer)

const importObject = {
    env: {
        draw0: draw0,
        memory: memory,
        memoryBase: 0,
    }
};

WebAssembly.instantiateStreaming(
    fetch('main.wasm'),
    importObject
).then(result => {
    const { Cool } = result.instance.exports
    start(Cool, memory)
});