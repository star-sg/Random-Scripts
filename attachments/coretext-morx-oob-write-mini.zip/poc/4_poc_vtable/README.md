there is hope of overwriting vtable at:

`TRunGlue::SetGlyphID<true>` --> `TStorageRange::ResetAdvance(TStorageRange*, oob offset, TFont*)` --> `TFont::GetUnsummedAdvancesForGlyphs` --> `GetUnscaledAdvances` --> vtable call

idea:
- do many canvas operations on non-poc font first
- then do poc
- see if poc font will be allocated after the canvas

looks promising

```
(lldbinit) p/x $rdx-0x7fc6b3531f50
(unsigned long) $292 = 0x0000000000001920
```

seems like they fall within the 0x500 to 0x1000 range, there must be something that happens in between causing the differences
maybe ideally it is 0x500

order of calls:
1. `TFont`
2. `TStorageRange`
3. `DoLigatureAction`

questions:
1. when is `TFont` called?
2. When is `TStorageRange` called?
3. what `malloc` happens in between `TFont` and `TStorageRange`?

answers in experiments/call_order