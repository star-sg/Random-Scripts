fat = ""

# fat += "<h1>"
for i in range(6000):
    fat += f'function draw{i}() {{draw{i+1}()}}\n'
fat = fat.replace("draw6000()", "pig()")

js = open("draw.js").read()
fat += js

with open("fat.html", "w") as outf:
    outf.write("<!DOCTYPE html>")
    outf.write('<html lang="ar" dir="rtl">')
    outf.write("<head>")
    outf.write('<meta charset="UTF-8"/>')
    # outf.write('<style>* { display: block; }</style>')
    outf.write("</head>")
    outf.write("<body>")
    outf.write('<canvas id="canvas" height="500px" width="500px"></canvas>')
    outf.write(f'<script>{fat}</script>')
    outf.write("</body>")
    outf.write("</html>")