var buffer = new ArrayBuffer(3000);
function wrapper(arg) {
    var a, b, c, d, e, f, g, h, i, j, k, bbb
    a = arg[0]
    b = arg[1]
    c = arg[2]
    d = arg[3]
    e = arg[4]
    f = arg[5]
    g = arg[6]
    h = arg[7]
    i = arg[8]
    j = arg[9]
    k = arg[10]
    bbb = arg[11]

    a = b + c
    d = e * f
    g = h - i
    j |= k

    return a + b + c + d + e + f + g + h + i + j + k
}

for (var i = 0; i < 150000; ++i) wrapper([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, buffer])