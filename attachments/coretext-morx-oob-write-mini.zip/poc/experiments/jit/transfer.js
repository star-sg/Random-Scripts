onmessage = function(e) {
    if (e.data == 0)
    {
        console.log(buf)
    }
    else {
        console.log('Message 0 received from main script');
        console.log(e.data)
        buf = e.data
        // e.data.buf[0] = 0xbeef
        // e.data.buf[1] = 0x1337
        console.log(e.data)
        console.log(buf)
    }
}