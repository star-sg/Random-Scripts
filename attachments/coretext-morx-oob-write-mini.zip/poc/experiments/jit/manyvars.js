function wrapper(arg) {
    var a, b, c, d, e, f, g, h, i, j, k
    a = arg + 1
    b = arg + 2
    c = arg + 3
    d = arg + 4
    e = arg + 5
    f = arg + 6
    g = arg + 7
    h = arg + 8
    i = arg + 9
    j = arg + 10
    k = arg + 11

    a = b + c
    d = e * f
    g = h - i
    j |= k

    return a + b + c + d + e + f + g + h + i + j + k
}

for (var i = 0; i < 150000; ++i) wrapper(i)