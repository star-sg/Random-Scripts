var buffer = new ArrayBuffer(3000);
function wrapper(arg, yes) {
    var a = [
        arg[11],
        arg[10],
        arg[9],
        arg[8],
        arg[7],
        arg[6],
        arg[5],
        arg[4],
        arg[3],
        arg[2],
        arg[1],
        arg[0],
    ]

    // a = b + c
    // d = e * f
    // g = h - i
    // j |= k

    if (!yes)
        return arg[0] + arg[1] + arg[2] + arg[3] + arg[4] + arg[5] + arg[6] + arg[7] + arg[8] + arg[9] + arg[10] + arg[11]
    
    var ctx = document.getElementById('canvas').getContext('2d');
    draw(ctx)
    return arg[0] + arg[1] + arg[2] + arg[3] + arg[4] + arg[5] + arg[6] + arg[7] + arg[8] + arg[9] + arg[10] + arg[11]
}

for (var i = 0; i < 150000; ++i) wrapper([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, buffer], false)