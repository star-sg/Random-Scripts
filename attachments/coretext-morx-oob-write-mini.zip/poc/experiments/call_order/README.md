

order of calls:
1. `TFont`
2. `TStorageRange`
3. `DoLigatureAction`

questions:
1. when is `TFont` called?
2. When is `TStorageRange` called?
3. what `malloc` happens in between `TFont` and `TStorageRange`?

```
-----------------------------------------------------------------------------------------------------------------------[code]
TFont::TFont(__CTFontDescriptor const*, double, CGAffineTransform const*, __CTFontDescriptor const*) @ /System/Library/Frameworks/CoreText.framework/Versions/A/CoreText:
->  0x7fff21a61d76 (0x7fff2192cd76): 55              push   rbp
    0x7fff21a61d77 (0x7fff2192cd77): 48 89 e5        mov    rbp, rsp
    0x7fff21a61d7a (0x7fff2192cd7a): 5d              pop    rbp
    0x7fff21a61d7b (0x7fff2192cd7b): e9 02 00 00 00  jmp    0x7fff21a61d82 ; TFont::TFont(__CTFontDescriptor const*, double, CGAffineTransform const*, __CTFontDescriptor const*)
    0x7fff21a61d80 (0x7fff2192cd80): 90              nop
    0x7fff21a61d81 (0x7fff2192cd81): 90              nop
TFont::TFont(__CTFontDescriptor const*, double, CGAffineTransform const*, __CTFontDescriptor const*) @ /System/Library/Frameworks/CoreText.framework/Versions/A/CoreText:
    0x7fff21a61d82 (0x7fff2192cd82): 55              push   rbp
    0x7fff21a61d83 (0x7fff2192cd83): 48 89 e5        mov    rbp, rsp
-----------------------------------------------------------------------------------------------------------------------------

Process 92782 stopped
* thread #1, queue = 'com.apple.main-thread', stop reason = breakpoint 4.1
    frame #0: 0x00007fff21a61d76 CoreText`TFont::TFont(__CTFontDescriptor const*, double, CGAffineTransform const*, __CTFontDescriptor const*)
Target 0: (com.apple.WebKit.WebContent) stopped.
(lldbinit) bt
* thread #1, queue = 'com.apple.main-thread', stop reason = breakpoint 4.1
  * frame #0: 0x00007fff21a61d76 CoreText`TFont::TFont(__CTFontDescriptor const*, double, CGAffineTransform const*, __CTFontDescriptor const*)
    frame #1: 0x00007fff21a61c9a CoreText`TCFRef<CTFont*> TCFBase_NEW<CTFont, __CTFontDescriptor const*, double&, CGAffineTransform const*&, __CTFontDescriptor const*&>(__CTFontDescriptor const*&&, double&, CGAffineTransform const*&, __CTFontDescriptor const*&) + 109
    frame #2: 0x00007fff21a61b2a CoreText`CTFontCreateWithFontDescriptor + 108
    frame #3: 0x000000010af68562 WebCore`WebCore::fontWithFamily(WTF::AtomString const&, WebCore::FontDescription const&, WebCore::FontTaggedSettings<int> const*, WebCore::FontSelectionSpecifiedCapabilities, float) + 3138
    frame #4: 0x000000010af6741a WebCore`WebCore::FontCache::createFontPlatformData(WebCore::FontDescription const&, WTF::AtomString const&, WebCore::FontTaggedSettings<int> const*, WebCore::FontSelectionSpecifiedCapabilities) + 122
    frame #5: 0x000000010aec21ad WebCore`WebCore::FontCache::cachedFontPlatformData(WebCore::FontDescription const&, WTF::String const&, WebCore::FontTaggedSettings<int> const*, WebCore::FontSelectionSpecifiedCapabilities, bool) + 1245
    frame #6: 0x000000010aec2d6e WebCore`WebCore::FontCache::fontForFamily(WebCore::FontDescription const&, WTF::String const&, WebCore::FontTaggedSettings<int> const*, WebCore::FontSelectionSpecifiedCapabilities, bool) + 158
    frame #7: 0x000000010a589b15 WebCore`WebCore::CSSFontSelector::fontRangesForFamily(WebCore::FontDescription const&, WTF::AtomString const&) + 645
    frame #8: 0x000000010aecf2c2 WebCore`WebCore::realizeNextFallback(WebCore::FontCascadeDescription const&, unsigned int&, WebCore::FontSelector*) + 306
    frame #9: 0x000000010aeceb72 WebCore`WebCore::FontCascadeFonts::realizeFallbackRangesAt(WebCore::FontCascadeDescription const&, unsigned int) + 674
    frame #10: 0x00000001096a64d0 WebCore`WebCore::FontCascadeFonts::primaryFont(WebCore::FontCascadeDescription const&) + 48
    frame #11: 0x000000010b2f8e70 WebCore`WebCore::Style::resolveForFontRaw(WebCore::CSSPropertyParserHelpers::FontRaw const&, WebCore::FontCascadeDescription&&, WebCore::ScriptExecutionContext&) + 2480
    frame #12: 0x000000010aa3ebce WebCore`WebCore::CanvasRenderingContext2D::setFontWithoutUpdatingStyle(WTF::String const&) + 1294
    frame #13: 0x0000000109813d7e WebCore`WebCore::setJSCanvasRenderingContext2D_font(JSC::JSGlobalObject*, long long, long long, JSC::PropertyName) + 270
    frame #14: 0x000000010e2873fa JavaScriptCore`JSC::JSObject::putInlineSlow(JSC::JSGlobalObject*, JSC::PropertyName, JSC::JSValue, JSC::PutPropertySlot&) + 1002
    frame #15: 0x000000010d5d26aa JavaScriptCore`llint_slow_path_put_by_id + 1370
    frame #16: 0x000000010d83c64d JavaScriptCore`llint_entry + 40902
    frame #17: 0x000000010d84dc4e JavaScriptCore`llint_entry + 112071
    frame #18: 0x000000010d84dc4e JavaScriptCore`llint_entry + 112071
    frame #19: 0x000000010d832486 JavaScriptCore`vmEntryToJavaScript + 216
    frame #20: 0x000000010df0db9b JavaScriptCore`JSC::Interpreter::executeCall(JSC::JSGlobalObject*, JSC::JSObject*, JSC::CallData const&, JSC::JSValue, JSC::ArgList const&) + 555
    frame #21: 0x000000010e16ca54 JavaScriptCore`JSC::profiledCall(JSC::JSGlobalObject*, JSC::ProfilingReason, JSC::JSValue, JSC::CallData const&, JSC::JSValue, JSC::ArgList const&) + 164
    frame #22: 0x000000010e27354d JavaScriptCore`JSC::JSMicrotask::run(JSC::JSGlobalObject*) + 445
    frame #23: 0x000000010a431778 WebCore`WebCore::JSMicrotaskCallback::call() + 104
    frame #24: 0x000000010a4316dc WebCore`WTF::Detail::CallableWrapper<WebCore::JSDOMWindowBase::queueMicrotaskToEventLoop(JSC::JSGlobalObject&, WTF::Ref<JSC::Microtask, WTF::RawPtrTraits<JSC::Microtask> >&&)::$_40, void>::call() + 76
    frame #25: 0x000000010a77dbf5 WebCore`WebCore::MicrotaskQueue::performMicrotaskCheckpoint() + 149
    frame #26: 0x000000010a765ae6 WebCore`WebCore::EventLoop::run() + 886
    frame #27: 0x000000010a7e11a1 WebCore`WebCore::WindowEventLoop::didReachTimeToRun() + 17
    frame #28: 0x000000010ae5de26 WebCore`WTF::Detail::CallableWrapper<WebCore::ThreadTimers::setSharedTimer(WebCore::SharedTimer*)::$_0, void>::call() + 198
    frame #29: 0x00000001093b3f1f WebCore`WebCore::timerFired(__CFRunLoopTimer*, void*) + 31
```

because of `WebCore::JSMicrotaskCallback` this should be due to the promise
`WebCore::Style::resolveForFontRaw(WebCore::CSSPropertyParserHelpers::FontRaw` hints that it is from setting the font through css

rdi is:
- 0x00007F8BBCA310A0
- 0x00007F8BBC932240
- 0x00007F8BBAD42260
- 0x00007F8BBC8419A0
- 0x00007F8BBC841BC0
- 0x00007F8BBCA64AA0
- 0x00007F8BBCA654E0
- 0x00007F8BBC938E88
- 0x00007F8BBC847690
- 0x00007F8BBCA65708
- 0x00007F8BBC847AB0

7 times

6 of them are due to the `fillText`