var memory = new WebAssembly.Memory({ initial: 256 })
console.log(memory.buffer)

const importObject = {
    env: {
        draw0: draw0,
        memory: memory,
        memoryBase: 0,
    }
};

WebAssembly.instantiateStreaming(
    fetch('main.wasm'),
    importObject
).then(result => {
    const { Cool } = result.instance.exports
    const array = new Int32Array(memory.buffer, 0, 24)
    array.set([
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xdeadbeef, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23
    ])
    Cool(array.byteOffset)
});