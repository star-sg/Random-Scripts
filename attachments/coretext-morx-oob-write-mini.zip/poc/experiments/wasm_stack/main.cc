typedef unsigned long long ull;

extern "C"
{
  // Wrapper for our JavaScript function
  extern void draw0();

  int Cool3(int a, int b)
  {
    draw0();
    return a + b;
  }

  int Cool2(int a, int b)
  {
    return Cool3(a, b);
  }

  int Cool(int *args)
  {
    ull v0 = args[0];
    ull v1 = args[1];

    ull v2 = args[2];
    ull v3 = args[3];
    ull v4 = args[4];
    ull v5 = args[5];
    ull v6 = args[6];
    ull v7 = args[7];
    ull v8 = args[8];
    ull v9 = args[9];
    ull v10 = args[10];
    ull v11 = args[11];
    ull v12 = args[12];
    ull v13 = args[13];
    ull v14 = args[14];
    ull v15 = args[15];
    ull v16 = args[16];
    ull v17 = args[17];
    ull v18 = args[18];
    ull v19 = args[19];
    ull v20 = args[20];
    ull v21 = args[21];
    ull v22 = args[22];
    ull v23 = args[23];

    Cool2(v0, v1);
    return v0 + v1 + v2 + v3 + v4 + v5 + v6 + v7 + v8 + v9 + v10 +
            v11 + v12 + v13 + v14 + v15 + v16 + v17 + v18 + v19 + v20 +
            v21 + v22 + v23;
  }

  // testing uninit variable see if get any old values from the stack
  // doesnt work, stack layout changed by a lot
  //
  // int Cool(int *args)
  // {
  //   ull v0 = args[0];
  //   ull v1 = args[1];

  //   ull v2 = args[2];
  //   ull v3 = args[3];
  //   ull v4 = args[4];
  //   ull v5 = args[5];
  //   ull v6 = args[6];
  //   ull v7 = args[7];
  //   ull v8 = args[8];
  //   ull v9 = args[9];
  //   ull v10 = args[10];
  //   ull v11 = args[11];
  //   ull v12 = args[12];
  //   ull v13 = args[13];
  //   ull v14 = args[14];
  //   ull v15 = args[15];
  //   ull v16;
  //   ull v17 = args[17];
  //   ull v18 = args[18];
  //   ull v19 = args[19];
  //   ull v20 = args[20];
  //   ull v21 = args[21];
  //   ull v22 = args[22];
  //   ull v23 = args[23];
  //   ull sum = v0 + v1 + v2 + v3 + v4 + v5 + v6 + v7 + v8 + v9 + v10 +
  //           v11 + v12 + v13 + v14 + v15 + v16 + v17 + v18 + v19 + v20 +
  //           v21 + v22 + v23;

  //   v16 = args[16];

  //   Cool2(v0, v1);
  //   return sum * args[15];
  // }
}