print("class X {")
print("    constructor() {")

for i in range(0x200):
    if i == 0:
        print(f"        this.a{i} = 0x1337beef")
    else:
        print(f"        this.a{i} = 0x1337cafe{i&0xff:02x}")

print("    }")
print("}")