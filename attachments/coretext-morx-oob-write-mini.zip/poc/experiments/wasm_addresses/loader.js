var memory = new WebAssembly.Memory({ initial: 256 })
console.log(memory.buffer)

/**
 * Utils
 */
let conversion_buffer = new ArrayBuffer(8);
let float_view = new Float64Array(conversion_buffer);
let int_view = new BigUint64Array(conversion_buffer);
BigInt.prototype.hex = function () {
    return '0x' + this.toString(16);
};
BigInt.prototype.i2f = function () {
    int_view[0] = this;
    return float_view[0];
}
Number.prototype.f2i = function () {
    float_view[0] = this;
    return int_view[0];
}

const importObject = {
    env: {
        draw0: draw0,
        memory: memory,
        memoryBase: 0,
    }
};

WebAssembly.instantiateStreaming(
    fetch('main.wasm'),
    importObject
).then(result => {
    const { Cool } = result.instance.exports
    const array = new Float64Array(memory.buffer, 0, 100)
    array.set([
        BigInt("0").i2f(),
        BigInt("1").i2f(),
        BigInt("2").i2f(),
        BigInt("3").i2f(),
        BigInt("4").i2f(),
        BigInt("5").i2f(),
        BigInt("6").i2f(),
        BigInt("7").i2f(),
        BigInt("8").i2f(),
        BigInt("9").i2f(),
        BigInt("10").i2f(),
        BigInt("500").i2f(),
        BigInt("12").i2f(),
        BigInt("0x00007FFF8E200000").i2f(),
        BigInt("14").i2f(),
        BigInt("15").i2f(),
        BigInt("16").i2f(),
        BigInt("17").i2f(),
        BigInt("18").i2f(),
        BigInt("19").i2f(),
        BigInt("20").i2f(),
        BigInt("21").i2f(),
        BigInt("22").i2f(),
        BigInt("23").i2f(),
        BigInt("24").i2f(),
        BigInt("25").i2f(),
        BigInt("500").i2f(),                    // location 1
        BigInt("0x00007FFF8E200000").i2f(),     // trunglue 1
        BigInt("500").i2f(),                    // location 2
        BigInt("0x00007FFF8E200000").i2f(),     // trunglue 2
        BigInt("30").i2f(),
    ])
    Cool(array.byteOffset)
});