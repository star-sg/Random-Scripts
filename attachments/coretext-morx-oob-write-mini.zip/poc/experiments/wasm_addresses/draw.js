function pig() {
    var ctx = document.getElementById('canvas').getContext('2d');
    ctx.font = '24px serif';
    ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
}