fat = ""

# fat += "<h1>"
for i in range(510):
    fat += f'<div>'
fat += "من ويكيبيديا، الموسوعة الحرة"
# fat += "aaa"
for i in range(510):
    fat += f"</div>"
# fat += "</h1>"

js = open("js.js").read()

with open("fat.html", "w") as outf:
    outf.write("<!DOCTYPE html>")
    outf.write('<html lang="ar" dir="rtl">')
    outf.write("<head>")
    outf.write('<meta charset="UTF-8"/>')
    # outf.write('<style>* { display: block; }</style>')
    outf.write("</head>")
    outf.write("<body>")
    outf.write(fat)
    outf.write(f'<script>setTimeout(function() {{console.log("called");document.getElementsByTagName("body")[0].style.fontSize="32px";{js} }}, 200)</script>')
    # outf.write(f'<script>setTimeout(function() {{console.log("called");{js}}}, 2000)</script>')
    outf.write("</body>")
    outf.write("</html>")