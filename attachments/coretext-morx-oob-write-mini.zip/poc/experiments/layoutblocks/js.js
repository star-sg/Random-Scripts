var body = document.getElementsByTagName('body')[0];
body.innerHTML = '<p style="display:block"><span style="display:block"><p style="display:block">' + body.innerHTML + "</p></span></p>"