onmessage = function(e) {
	var canvas = new HTMLCanvasElement();
    var ctx = canvas.getContext('2d');
    ctx.font = '24px serif';
    ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
}