onmessage = function(e) {
    console.log('Message received from main script');
    console.log(e.data[0])
    e.data[0][0] = 0xbeef
    e.data[0][1] = 0x1337
    postMessage([e.data[0]]);
}