n = 512
for i in range(n):
    print(f"{i}: {i},", end=" ")
print(f"{n}: i")