fat = ""

# fat += "<h1>"
n = 4557
for i in range(n):
    fat += f'function draw{i}() {{draw{i+1}()}}\n'
fat = fat.replace(f"draw{n}()", "pig()")

js = open("draw.js").read()
fat += js
loader = open("loader.js").read()

with open("fat.html", "w") as outf:
    outf.write("<!DOCTYPE html>")
    outf.write('<html lang="ar" dir="rtl">')
    outf.write("<head>")
    outf.write('<meta charset="UTF-8"/>')
    # outf.write('<style>* { display: block; }</style>')
    outf.write("</head>")
    outf.write("<body>")
    outf.write('<canvas id="canvas" height="500px" width="500px"></canvas>')
    outf.write(f'<script>{fat}</script>')
    outf.write(f'<script>{loader}</script>')
    outf.write("</body>")
    outf.write("</html>")