#include <stdio.h>

int main()
{
    unsigned long long ull = 0x4000000000000002 + 0x0000000a3fb26400 - 0x2000000000000;
    double d = *(double*)&ull;
    printf("lf: %.512lf\n", d);
    printf("f:  %.512f\n", d);
    printf("a:  %a\n", d);
    return 0;
}