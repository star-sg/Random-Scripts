import sys
from struct import pack, unpack

a1 = sys.argv[1]
val = int(a1, 16) if a1[:2] == "0x" else int(a1, 10)

# 12 0's
if val < 0x2_0000_0000_0000:
    val += 0x8000_0000_0000_0000

#  * The top 15-bits denote the type of the encoded JSValue:
#  *
#  *     Pointer {  0000:PPPP:PPPP:PPPP
#  *              / 0002:****:****:****
#  *     Double  {         ...
#  *              \ FFFC:****:****:****
#  *     Integer {  FFFE:0000:IIII:IIII
#  *
#  * The scheme we have implemented encodes double precision values by performing a
#  * 64-bit integer addition of the value 2^49 to the number. After this manipulation
#  * no encoded double-precision value will begin with the pattern 0x0000 or 0xFFFE.
#  * Values must be decoded by reversing this operation before subsequent floating point
#  * operations may be peformed.

# get rid of the 2**49 offset
print(val, hex(val))
val = (val - 2**49) % 2**64
print(hex(val))
print(pack('Q', val))
f = unpack('d', pack('Q', val))
print(f)