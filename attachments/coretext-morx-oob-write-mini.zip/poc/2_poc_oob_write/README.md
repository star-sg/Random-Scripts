achieve oob write at `[_CTNativeGlyphStorage setGlyph:atIndex:]`

by setting the right value for `v4`, `v8`, `v11`, `v13` in draw.

3 more things to settle:
- put any value i want on the stack. how to do this? **(settled with wasm)**
    - find out whether dfg jit will write raw values (not nan-boxed) onto the stack
    - if not, can ftl do it?
- deterministic order of variables on the stack **(settled with wasm)**
    - confirmed that the order is the same random order even after restarting the process many times and testing on safari technology preview
    - havent tried restarting the machine yet
- spray memory so that dont crash on unmapped memory access
    - experiment with just vomitting many many many objects in setup function
    - see if there is any deterministic behaviour

0x0000000a3fb26400 away from the stack

time to change to wasm