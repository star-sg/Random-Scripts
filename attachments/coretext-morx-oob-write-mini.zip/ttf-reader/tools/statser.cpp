/////////////////////////////////////////////////////////////////////////
//
// Author: Mateusz Jurczyk (mjurczyk@google.com)
//
// Copyright 2018 Google LLC
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// https://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#if defined(_MSC_VER)
#define _CRT_SECURE_NO_WARNINGS
#endif  // defined(_MSC_VER)

#include <map>
#include <string>
#include <cstring>
#include <vector>
#include <iostream>

#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <sfnt/common.h>
#include <sfnt/sfnt_font.h>
#include <sfnt/name_table.h>


static bool WriteStringToFile(const char *filename, const std::string& data) {
  FILE *f = fopen(filename, "w+b");
  if (f == NULL) {
    return false;
  }

  if (fwrite(data.data(), sizeof(uint8_t), data.size(), f) != data.size()) {
    fclose(f);
    return false;
  }

  fclose(f);
  return true;
}

int main(int argc, char **argv) {
  if (argc != 2) {
    fprintf(stderr, "Usage: %s <fonts directory>\n", argv[0]);
    return 1;
  }

  const char *FONTS_DIR = argv[1];

  struct dirent *dp;
  DIR *dfd;
  if ((dfd = opendir(FONTS_DIR)) == NULL)
  {
    fprintf(stderr, "Can't open %s\n", FONTS_DIR);
    return 0;
  }

  std::map<uint32_t, uint32_t> tables_count;
  while ((dp = readdir(dfd)) != NULL)
  {
    if (dp->d_name[0] == '.') continue;

    struct stat stbuf;
    std::string font_path("fonts/");
    font_path += dp->d_name;

    // std::cout << font_path << std::endl;

    SfntFont font;
    if (!font.LoadFromFile(font_path.c_str())) {
      fprintf(stderr, "[-] Unable to load the \"%s\" file as a TTF/OTF font.\n", font_path.c_str());
      return 1;
    }

    // printf("Loaded %s\n", font_path.c_str());
    // printf("[+] %lu tables loaded\n", font.sfnt_tables_.size());
    for (const auto &table : font.sfnt_tables_)
    {
      tables_count[table.tag]++;
    }

    // printf("\n");
  }

  for (auto const& item : tables_count)
  {
    uint32_t tag = item.first;
    for (int i = 0; i < 4; ++i, tag <<= 8)
    {
      printf("%c", tag >> 24);
    }
    printf(" - %d\n", item.second);
  }

  return 0;
}
