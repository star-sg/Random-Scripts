/////////////////////////////////////////////////////////////////////////
//
// Author: Mateusz Jurczyk (mjurczyk@google.com)
//
// Copyright 2018 Google LLC
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// https://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#if defined(_MSC_VER)
#define _CRT_SECURE_NO_WARNINGS
#endif  // defined(_MSC_VER)

#include <map>
#include <string>
#include <cstring>
#include <vector>
#include <iostream>

#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <sfnt/common.h>
#include <sfnt/sfnt_font.h>
#include <sfnt/aat/morx_table.h>


static bool WriteStringToFile(const char *filename, const std::string& data) {
  FILE *f = fopen(filename, "w+b");
  if (f == NULL) {
    return false;
  }

  if (fwrite(data.data(), sizeof(uint8_t), data.size(), f) != data.size()) {
    fclose(f);
    return false;
  }

  fclose(f);
  return true;
}

int main(int argc, char **argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: %s <ttf file> <out ttf file>\n", argv[0]);
    return 1;
  }

  const char *FONT_PATH = argv[1];
  const char *output_file_path = argv[2];

  // std::cout << font_path << std::endl;

  SfntFont font;
  if (!font.LoadFromFile(FONT_PATH)) {
    fprintf(stderr, "[-] Unable to load the \"%s\" file as a TTF/OTF font.\n", FONT_PATH);
    return 1;
  }

  // printf("Loaded %s\n", font_path.c_str());
  // printf("[+] %lu tables loaded\n", font.sfnt_tables_.size());
  for (auto &table : font.sfnt_tables_)
  {
    char tag[4];
    char tagr[4]; // reversed because endian
    memcpy(tag, &table.tag, 4);
    for (int i = 3; i >= 0; --i) tagr[3 - i] = tag[i];

    if (!memcmp(tagr, "morx", 4))
    {
      printf("[+] Found morx\n");
      printf("[+] Expanding morx\n");
      for (int i = 0; i < 0x400; ++i)
        table.data.append("\x01");
    }
  }

  std::string output_data;
  if (!font.SaveToString(&output_data)) {
    fprintf(stderr, "[-] Unable to save a SFNT font to a string.\n");
    return 1;
  }

  if (!WriteStringToFile(output_file_path, output_data)) {
    fprintf(stderr, "[-] Unable to save the output font to \"%s\".\n", output_file_path);
    return 1;
  }

  printf("[+] Font successfully mutated and saved in \"%s\".\n", output_file_path);

  return 0;
}
