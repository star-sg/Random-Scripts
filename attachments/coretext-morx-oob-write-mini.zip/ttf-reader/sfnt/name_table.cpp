#include "name_table.h"
#include "common.h"

#include <stdlib.h>
#include <wchar.h>

NameTable::NameTable(const std::string& data)
{
    memcpy(&header, data.data(), sizeof(header));
    uint16_t count = SWAP16(header.count);
    uint16_t string_offset = SWAP16(header.string_offset);
    printf("Format: %hu\n", header.format);
    printf("Count: %hu\n", count);
    printf("String offset: %hu\n", string_offset);

    // possible integer overflow?
    size_t records_size = sizeof(struct NameRecord) * count;
    name_records = (struct NameRecord*) malloc(records_size);
    memcpy(name_records, data.data() + sizeof(header), records_size);

    const char* name_strings = data.data() + sizeof(header) + records_size;

    for (int i = 0; i < count; ++i)
    {
        struct NameRecord& name_record = name_records[i];
        uint16_t platformID = SWAP16(name_record.platformID);
        uint16_t platformSpecificID = SWAP16(name_record.platformSpecificID);
        uint16_t languageID = SWAP16(name_record.languageID);
        uint16_t nameID = SWAP16(name_record.nameID);
        uint16_t length = SWAP16(name_record.length);
        uint16_t offset = SWAP16(name_record.offset);
        printf("-- platformID: %hu\n", platformID);
        printf("-- platformSpecificID: %hu\n", platformSpecificID);
        printf("-- languageID: %hu\n", languageID);
        printf("-- nameID: %hu\n", nameID);
        printf("-- length: %hu\n", length);
        printf("-- offset: %hu\n", offset);

        char16_t* name_string = (char16_t*) malloc(length);
        memcpy(name_string, name_strings + offset, length);
        for (int i = 0; i < length / 2; ++i) wprintf(L"%lc", SWAP16(name_string[i]));
        printf("\n");
        free(name_string);

        printf("\n");
    }
}