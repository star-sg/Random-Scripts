#pragma once

#include <stdint.h>
#include <vector>

struct STXHeader
{
    uint32_t nClasses;
    uint32_t classTableOffset;
    uint32_t stateArrayOffset;
    uint32_t entryTableOffset;
};

struct StateClassSubtable
{
    uint16_t firstGlyph;
    uint16_t nGlyphs;
    uint8_t* classArray;
};

typedef uint8_t* StateArray;

struct StateEntrySubtable
{
    uint16_t newState;
    uint16_t flags;
    void* glyphOffsets;
};