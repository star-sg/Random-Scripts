#include "morx_table.h"
#include "../common.h"

#include <stdio.h>
#include <iostream>


std::ostream& operator<<(std::ostream& os, const struct MorxHeader* morx_header)
{
    os << "Morx Table Header" << std::endl;
    os << "=================" << std::endl;
    os << "| Version: " << SWAP16(morx_header->version) << std::endl;
    os << "| Number of chains: " << SWAP32(morx_header->nChains) << std::endl;
    os << std::endl;
    return os;
}


std::ostream& operator<<(std::ostream& os, MyMorxLigatureTable& ligature_subtable)
{
    os << "| Ligature Subtable Header" << std::endl;
    os << "==========================" << std::endl;
    os << "| Number of classes: " << SWAP32(ligature_subtable.header->stateHeader.nClasses) << std::endl;
    os << "| Class lookup table offset: " << SWAP32(ligature_subtable.header->stateHeader.classTableOffset) << std::endl;
    os << "| State array offset: " << SWAP32(ligature_subtable.header->stateHeader.stateArrayOffset) << std::endl;
    os << "| Entry table offset: " << SWAP32(ligature_subtable.header->stateHeader.entryTableOffset) << std::endl;
    os << "| Ligature actions offset: " << SWAP32(ligature_subtable.header->ligActionOffset) << std::endl;
    os << "| Components offset: " << SWAP32(ligature_subtable.header->componentOffset) << std::endl;
    os << "| Ligature list offset: " << SWAP32(ligature_subtable.header->ligatureListOffset) << std::endl;
    os << "==========================" << std::endl;
    os << "| Class Table" << std::endl;
    os << "| (idw to implement)" << std::endl;
    os << "=====================" << std::endl;
    os << "| State Array" << std::endl;
    os << "| (idw to implement)" << std::endl;
    os << "=====================" << std::endl;
    os << "| Entry Table" << std::endl;
    os << "| (idw to implement)" << std::endl;
    os << "=====================" << std::endl;

    os << "| Ligature Actions" << std::endl;
    os << "|--" << std::endl;
    MorxLigatureAction* p_ligature_action = ligature_subtable.actions_table;
    MorxLigatureAction action;
    int count = 0;
    do
    {
        action = SWAP32(*p_ligature_action++);
        os << "| " << std::hex << action << std::dec << std::endl;
        os << "| " << "Last: " << !!(action & 0x80000000) << std::endl;
        os << "| " << "Store: " << !!(action & 0x40000000) << std::endl;

        // do sign extension from 30-bit to 32-bit
        uint32_t extension = !!(action & 0x20000000) * 0xc0000000;
        uint32_t offset = (action & 0x3FFFFFFF) | extension;
        os << "| " << "Offset: " << std::hex << offset << std::dec << std::endl;
        os << "|--" << std::endl;
    } while (!(action & 0x80000000) && count++ < 24);
    
    os << "=====================" << std::endl;

    os << "| Components" << std::endl;
    os << "| (idw to implement)" << std::endl;
    os << "=====================" << std::endl;
    os << "| Ligature List" << std::endl;
    os << "| (idw to implement)" << std::endl;
    os << "=====================" << std::endl;
    return os;
}


std::ostream& operator<<(std::ostream& os, MyMorxMetamorphosisSubtable& morph_subtable)
{
    MorxSubtableType subtable_type = static_cast<MorxSubtableType>(SWAP32(morph_subtable.header->coverage) & 0xff);

    switch(subtable_type)
    {
        case REARRANGEMENT_SUBTABLE:
            // not implemented
            os << "// Rearrangement Subtable (Not Implemented)" << std::endl;
            break;
        case CONTEXTUAL_SUBTABLE:
            // not implemented
            os << "// Contextual Subtable (Not Implemented)" << std::endl;
            break;
        case LIGATURE_SUBTABLE:
            os << "// Ligature Subtable" << std::endl;
            break;
        case RESERVED:
            // not implemented
            os << "// Reserved Subtable (whatever this is)" << std::endl;
            break;
        case SWASH_SUBTABLE:
            // not implemented
            os << "// Swash Subtable (Not Implemented)" << std::endl;
            break;
        case INSERTION_SUBTABLE:
            // not implemented
            os << "// Insertion Subtable (Not Implemented)" << std::endl;
            break;
        default:
            // invalid? maybe it's the coverage table
            // assert(false);
            os << "// Coverage Subtable? (Not Implemented)" << std::endl;
            break;
    }
    os << "------------------------" << std::endl;

    os << "| Metamorphosis Subtable Header" << std::endl;
    os << "===============================" << std::endl;
    os << "| Length: " << SWAP32(morph_subtable.header->length) << std::endl;
    os << "| Coverage: " << std::hex << SWAP32(morph_subtable.header->coverage) << std::dec << std::endl;
    os << "| Flags: " << std::hex << SWAP32(morph_subtable.header->subFeatureFlags) << std::dec << std::endl;
    os << "===============================" << std::endl;

    switch(subtable_type)
    {
        case REARRANGEMENT_SUBTABLE:
            // not implemented
            break;
        case CONTEXTUAL_SUBTABLE:
            // not implemented
            break;
        case LIGATURE_SUBTABLE:
            os << morph_subtable.ligature_subtable;
            break;
        case RESERVED:
            // not implemented
            break;
        case SWASH_SUBTABLE:
            // not implemented
            break;
        case INSERTION_SUBTABLE:
            // not implemented
            break;
        default:
            // invalid? maybe it's the coverage table
            // assert(false);
            break;
    }
    
    return os;
}


std::ostream& operator<<(std::ostream& os, MyMorxChain& morx_chain)
{
    os << "[[ Morx Chain ]]" << std::endl;

    os << "Morx Chain Header" << std::endl;
    os << "=================" << std::endl;
    os << "| Default Flags: " << SWAP32(morx_chain.chain_header->defaultFlags) << std::endl;
    os << "| Chain Length: " << SWAP32(morx_chain.chain_header->chainLength) << std::endl;
    os << "| Number of Feature Subtable Entries: " << SWAP32(morx_chain.chain_header->nFeatureEntries) << std::endl;
    os << "| Number of Subtables: " << SWAP32(morx_chain.chain_header->nSubtables) << std::endl;
    os << std::endl;

    os << "Morx Chain Feature Table" << std::endl;
    os << "========================" << std::endl;
    for (int i = 0; i < SWAP32(morx_chain.chain_header->nFeatureEntries); ++i)
    {
        os << "| Feature Type: " << SWAP16(morx_chain.feature_table[i].featureType) << std::endl;
        os << "| Feature Setting: " << SWAP16(morx_chain.feature_table[i].featureSetting) << std::endl;
        os << "| Enable Flags: " << std::hex << SWAP32(morx_chain.feature_table[i].enableFlags) << std::dec << std::endl;
        os << "| Disable Flags: " << std::hex << SWAP32(morx_chain.feature_table[i].disableFlags) << std::dec << std::endl;
        os << "--" << std::endl;
    }
    os << std::endl;

    os << "Morx Chain Subtables" << std::endl;
    os << "====================" << std::endl;
    for (int i = 0; i < SWAP32(morx_chain.chain_header->nSubtables); ++i)
    {
        os << morx_chain.morph_subtables[i];
        os << "--" << std::endl << std::endl;
    }
    return os;
}


MyMorxMetamorphosisSubtable::MyMorxMetamorphosisSubtable(const uint8_t* morx_morph_subtable_buffer)
{
    this->header = (struct MorxMetamorphosisHeader*) morx_morph_subtable_buffer;
    morx_morph_subtable_buffer += sizeof(struct MorxMetamorphosisHeader);

    MorxSubtableType subtable_type = static_cast<MorxSubtableType>(SWAP32(this->header->coverage) & 0xff);

    switch(subtable_type)
    {
        case REARRANGEMENT_SUBTABLE:
            // not implemented
            break;
        case CONTEXTUAL_SUBTABLE:
            // not implemented
            break;
        case LIGATURE_SUBTABLE:
            this->ligature_subtable = MyMorxLigatureTable(morx_morph_subtable_buffer);
            break;
        case RESERVED:
            // not implemented
            break;
        case SWASH_SUBTABLE:
            // not implemented
            break;
        case INSERTION_SUBTABLE:
            // not implemented
            break;
        default:
            // invalid? maybe it's the coverage table
            // assert(false);
            break;
    }
}


MyMorxChain::MyMorxChain(const uint8_t* morx_chain_buffer)
{
    this->chain_header = (struct MorxChainHeader*) morx_chain_buffer;
    morx_chain_buffer += sizeof(struct MorxChainHeader);

    this->feature_table = (struct MorxFeatureTable*) morx_chain_buffer;
    morx_chain_buffer += sizeof(struct MorxFeatureTable) * SWAP32(this->chain_header->nFeatureEntries);

    const uint8_t* curr_ptr = morx_chain_buffer;
    for (int i = 0; i < SWAP32(this->chain_header->nSubtables); ++i)
    {
        // std::cout << "[+] Parsing subtable " << i << std::endl;
        MyMorxMetamorphosisSubtable morph_subtable(curr_ptr);
        this->morph_subtables.push_back(morph_subtable);
        curr_ptr += SWAP32(morph_subtable.header->length);
    }
}


MyMorxTable::MyMorxTable(const uint8_t* morx_table_buffer)
{
    // printf("[+] Parsing morx table\n\n");
    this->header = (struct MorxHeader*) morx_table_buffer;
    std::cout << this->header;

    const uint8_t* curr_ptr = morx_table_buffer + sizeof(struct MorxHeader);
    for (int i = 0; i < SWAP32(this->header->nChains); ++i)
    {
        // std::cout << "[+] Parsing chain " << i << std::endl;
        MyMorxChain morx_chain(curr_ptr);
        this->morx_chains.push_back(morx_chain);
        curr_ptr += morx_chain.chain_header->chainLength;
        std::cout << morx_chain;
    }
}


MyMorxLigatureTable::MyMorxLigatureTable(const uint8_t* ligature_subtable_buffer)
{
    // printf("[+] Parsing ligature subtable\n");
    this->header = (struct MorxLigatureHeader*) ligature_subtable_buffer;

    this->actions_table = (MorxLigatureAction*) (ligature_subtable_buffer + SWAP32(this->header->ligActionOffset));
}
