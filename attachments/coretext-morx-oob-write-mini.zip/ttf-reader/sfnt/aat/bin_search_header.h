#pragma once

#include <stdint.h>

struct BinSearchHeader
{
    uint16_t unitSize;
    uint16_t nUnits;
    uint16_t searchRange;
    uint16_t entrySelector;
    uint16_t rangeShift;
};