#pragma once

#include <stdint.h>
#include <vector>

#include "state_table.h"
#include "lookup_table.h"

struct MorxHeader
{
    uint16_t version;
    uint16_t unused;
    uint32_t nChains;
};

struct MorxChainHeader
{
    uint32_t defaultFlags;
    uint32_t chainLength;
    uint32_t nFeatureEntries;
    uint32_t nSubtables;
};

struct MorxFeatureTable
{
    uint16_t featureType;
    uint16_t featureSetting;
    uint32_t enableFlags;
    uint32_t disableFlags;
};

struct MorxCoverageTable
{
    uint32_t* subtableOffsets;
    uint16_t* coverageBitfields;
};

struct MorxMetamorphosisHeader
{
    uint32_t length;
    uint32_t coverage;
    uint32_t subFeatureFlags;
};

enum MorxSubtableType
{
    REARRANGEMENT_SUBTABLE,
    CONTEXTUAL_SUBTABLE,
    LIGATURE_SUBTABLE,
    RESERVED,
    SWASH_SUBTABLE,
    INSERTION_SUBTABLE
};

struct MorxLigatureHeader
{
    struct STXHeader stateHeader;
    uint32_t ligActionOffset;
    uint32_t componentOffset;
    uint32_t ligatureListOffset;
};

struct MorxLigatureEntry
{
    uint16_t nextStateIndex;
    uint16_t entryFlags;
    uint16_t ligActionIndex;
};

typedef uint32_t MorxLigatureAction;
typedef uint16_t MorxLigatureComponent;
typedef uint16_t MorxLigatureLigature;

class MyMorxLigatureTable
{
public:
    struct MorxLigatureHeader* header;
    struct LookupTable* class_table;
    StateArray state_array;
    struct MorxLigatureEntry* entry_table;
    MorxLigatureAction* actions_table;
    MorxLigatureComponent* components_table;
    MorxLigatureLigature* ligatures_table;

    MyMorxLigatureTable(const uint8_t* ligature_subtable_buffer);
};

class MyMorxMetamorphosisSubtable
{
public:
    struct MorxMetamorphosisHeader* header;
    union
    {
        MyMorxLigatureTable ligature_subtable;
    };

    MyMorxMetamorphosisSubtable(const uint8_t* morx_morph_subtable_buffer);
};

class MyMorxChain
{
public:
    struct MorxChainHeader* chain_header;
    struct MorxFeatureTable* feature_table;
    std::vector<MyMorxMetamorphosisSubtable> morph_subtables;

    MyMorxChain(const uint8_t* morx_chain_buffer);
};

class MyMorxTable
{
public:
    struct MorxHeader* header;
    std::vector<MyMorxChain> morx_chains;

    MyMorxTable(const uint8_t* morx_table_buffer);
};
