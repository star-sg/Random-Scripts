#pragma once

#include <stdint.h>
#include <vector>

struct LookupSimpleArrayTable
{
};

struct LookupSegmentSingleTable
{
};

struct LookupSegmentArrayTable
{
};

struct LookupSingleTable
{
};

struct LookupTrimmedArrayTable
{
};

struct LookupExtendedTrimmedArrayTable
{
};

union LookupFSHeader
{
    struct LookupSimpleArrayTable simple_array_table;
    struct LookupSegmentSingleTable segment_single_table;
    struct LookupSegmentArrayTable segment_array_table;
    struct LookupSingleTable single_table;
    struct LookupTrimmedArrayTable trimmed_array_table;
    struct LookupExtendedTrimmedArrayTable extended_trimmed_array_table;
};

struct LookupTable
{
    uint16_t format;
    LookupFSHeader fsHeader;
};