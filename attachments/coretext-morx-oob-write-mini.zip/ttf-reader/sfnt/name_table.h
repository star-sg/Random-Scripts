#include <string>

struct NameTableHeader
{
    uint16_t format;
    uint16_t count;
    uint16_t string_offset;
};

struct NameRecord
{
    uint16_t platformID;
    uint16_t platformSpecificID;
    uint16_t languageID;
    uint16_t nameID;
    uint16_t length;
    uint16_t offset;
};

class NameTable
{
public:
    struct NameTableHeader header;
    struct NameRecord* name_records;

    ~NameTable() { free(name_records); };
    NameTable(const std::string& data);
};